#!/usr/bin/env bash
# Reverse a restore that died half-way (storage shortage) and reclaim disk BEFORE
# retrying. Idempotent. Nothing is dropped without an explicit CONFIRM=yes.
set -euo pipefail
source ./migrate.env
TGT="mysql -h ${TGT_HOST} -P ${TGT_PORT} -u ${TGT_USER} -p${TGT_PASS}"

echo "== [0] Current free space and InnoDB footprint =="
df -h "${WORK}" 2>/dev/null || true
$TGT -N -B -e "SELECT 'binlog_gb', ROUND(SUM(file_size)/1024/1024/1024,2) \
  FROM performance_schema.binary_log_transaction_compression_stats;" 2>/dev/null || true

echo; echo "== [1] Databases that were partially loaded (drop + recreate = full reclaim) =="
for db in ${DBS}; do
  echo "  target db: ${db}"
done
if [ "${CONFIRM:-no}" != "yes" ]; then
  echo ">> DRY RUN. Re-run with CONFIRM=yes to actually DROP the partial databases."
else
  for db in ${DBS}; do
    echo "  DROP DATABASE IF EXISTS \`${db}\` ..."
    $TGT -e "DROP DATABASE IF EXISTS \`${db}\`;"
  done
  echo "  file-per-table .ibd files for those tables are removed on DROP -> space returned."
fi

echo; echo "== [2] Reclaim binary-log space (biggest hidden consumer during a restore) =="
echo "   If binlog was ON during the failed load it may have written GBs of events."
echo "   8.4 syntax (RESET MASTER was removed):"
if [ "${CONFIRM:-no}" = "yes" ]; then
  $TGT -e "RESET BINARY LOGS AND GTIDS;" && echo "   binlogs purged."
else
  echo "   (dry run) would run: RESET BINARY LOGS AND GTIDS;"
fi

echo; echo "== [3] Undo tablespace bloat (a single huge txn can inflate undo) =="
$TGT -N -B -e "SELECT NAME, ROUND(FILE_SIZE/1024/1024,1) mb \
  FROM information_schema.INNODB_TABLESPACES \
  WHERE NAME LIKE '%undo%';" 2>/dev/null || true
echo "   Ensure innodb_undo_log_truncate=ON (default). A clean restart truncates undo:"
echo "     sudo systemctl restart mysqld"

echo; echo "== [4] Confirm free space is now >= 3x the dump size before retrying =="
df -h "${WORK}" 2>/dev/null || true
