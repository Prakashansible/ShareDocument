#!/usr/bin/env bash
# Pre-migration compatibility scan of the 5.7 source. Read-only. No changes made.
set -euo pipefail
source ./migrate.env

echo "== [1] MySQL Shell upgrade checker (the single most important check) =="
# Requires mysql-shell installed. Points at the 5.7 source; targets 8.4.
mysqlsh --uri "${SRC_USER}@${SRC_HOST}:${SRC_PORT}" --password="${SRC_PASS}" \
  -- util check-for-server-upgrade --target-version=8.4.0 \
  --output-format=TEXT | tee "${LOG_DIR}/upgrade_checker.txt" || {
    echo "!! mysqlsh not found or check failed. Install mysql-shell 8.x and re-run."; }

SRC="mysql -h ${SRC_HOST} -P ${SRC_PORT} -u ${SRC_USER} -p${SRC_PASS} -N -B"

echo; echo "== [2] lower_case_table_names (MUST match on 8.4 at init_() time) =="
$SRC -e "SHOW VARIABLES LIKE 'lower_case_table_names';"

echo; echo "== [3] Storage engines in scope (convert MyISAM -> InnoDB before migrating) =="
$SRC -e "SELECT table_schema, engine, COUNT(*) tables, \
  ROUND(SUM(data_length+index_length)/1024/1024,1) size_mb \
  FROM information_schema.tables \
  WHERE table_schema IN ($(echo \"$DBS\" | sed \"s/ /','/g;s/^/'/;s/$/'/\")) \
  GROUP BY table_schema, engine ORDER BY size_mb DESC;"

echo; echo "== [4] Default character set / non-utf8mb4 columns =="
$SRC -e "SELECT table_schema, character_set_name, COUNT(*) \
  FROM information_schema.columns \
  WHERE table_schema IN ($(echo \"$DBS\" | sed \"s/ /','/g;s/^/'/;s/$/'/\")) \
    AND character_set_name IS NOT NULL AND character_set_name <> 'utf8mb4' \
  GROUP BY table_schema, character_set_name;"

echo; echo "== [5] Auth plugins in use (native accounts need special handling on 8.4) =="
$SRC -e "SELECT plugin, COUNT(*) FROM mysql.user GROUP BY plugin;"

echo; echo "== [6] Total data size to migrate (plan target free space >= 2-3x this) =="
$SRC -e "SELECT ROUND(SUM(data_length+index_length)/1024/1024/1024,2) total_gb \
  FROM information_schema.tables \
  WHERE table_schema IN ($(echo \"$DBS\" | sed \"s/ /','/g;s/^/'/;s/$/'/\"));"

echo; echo ">>> Review ${LOG_DIR}/upgrade_checker.txt before proceeding."
