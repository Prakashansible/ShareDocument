#!/usr/bin/env bash
# Dump the in-scope databases from 5.7. Two options:
#  (A) MySQL Shell util.dumpInstance  -> RESUMABLE, parallel, compressed (recommended)
#  (B) classic mysqldump              -> single .sql, simple but not resumable
set -euo pipefail
source ./migrate.env

MODE="${1:-shell}"   # "shell" (default) or "mysqldump"

if [ "${MODE}" = "shell" ]; then
  echo "== MySQL Shell dumpInstance (resumable, parallel) =="
  SHELL_DUMP="${DUMP_DIR}/shelldump"
  rm -rf "${SHELL_DUMP}"
  # includeSchemas limits to your DBs; compatibility strips 5.7-isms and DEFINERs.
  INCL=$(printf '"%s",' ${DBS}); INCL="[${INCL%,}]"
  mysqlsh --uri "${SRC_USER}@${SRC_HOST}:${SRC_PORT}" --password="${SRC_PASS}" -- \
    util dump-instance "${SHELL_DUMP}" \
      --includeSchemas="${INCL}" \
      --threads=4 \
      --compatibility='["strip_definers","force_innodb","skip_invalid_accounts"]' \
      --consistent=true 2>&1 | tee "${LOG_DIR}/dump_shell.log"
  echo "Dump dir: ${SHELL_DUMP}"
else
  echo "== classic mysqldump =="
  # --column-statistics=0 is REQUIRED when an 8.x mysqldump client reads a 5.7 server
  #   (5.7 has no information_schema.COLUMN_STATISTICS, so the default query fails).
  # --set-gtid-purged=OFF keeps GTID state out of the dump (fresh target).
  mysqldump -h "${SRC_HOST}" -P "${SRC_PORT}" -u "${SRC_USER}" -p"${SRC_PASS}" \
    --single-transaction --quick --routines --triggers --events \
    --set-gtid-purged=OFF --column-statistics=0 \
    --default-character-set=utf8mb4 \
    --databases ${DBS} \
    | gzip > "${DUMP_DIR}/dump_5.7.sql.gz"
  echo "Wrote ${DUMP_DIR}/dump_5.7.sql.gz"
fi
