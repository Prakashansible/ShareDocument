#!/usr/bin/env bash
# Restore into 8.4. Matches the dump mode from 03.
#  - Shell loadDump is RESUMABLE: if it dies again it continues where it stopped.
#  - Binary logging is disabled for the session/instance during load.
set -euo pipefail
source ./migrate.env
MODE="${1:-shell}"

echo "== Pre-flight: free space check =="
df -h "${WORK}"

if [ "${MODE}" = "shell" ]; then
  echo "== MySQL Shell loadDump (resumable, parallel) =="
  SHELL_DUMP="${DUMP_DIR}/shelldump"
  # resetProgress=false lets a re-run CONTINUE a partially completed load.
  mysqlsh --uri "${TGT_USER}@${TGT_HOST}:${TGT_PORT}" --password="${TGT_PASS}" -- \
    util load-dump "${SHELL_DUMP}" \
      --threads=4 \
      --skipBinlog=true \
      --resetProgress=false \
      --loadUsers=false 2>&1 | tee "${LOG_DIR}/restore_shell.log"
else
  echo "== classic restore from mysqldump (binlog off, FK checks off for speed) =="
  ( echo "SET sql_log_bin=0;"
    echo "SET foreign_key_checks=0;"
    echo "SET unique_checks=0;"
    zcat "${DUMP_DIR}/dump_5.7.sql.gz"
    echo "SET foreign_key_checks=1;"
    echo "SET unique_checks=1;"
  ) | mysql -h "${TGT_HOST}" -P "${TGT_PORT}" -u "${TGT_USER}" -p"${TGT_PASS}" \
      2>&1 | tee "${LOG_DIR}/restore_classic.log"
fi

echo "== Load users/grants (native hashes preserved) =="
mysql -h "${TGT_HOST}" -P "${TGT_PORT}" -u "${TGT_USER}" -p"${TGT_PASS}" \
  < "${DUMP_DIR}/users_grants.sql"
mysql -h "${TGT_HOST}" -P "${TGT_PORT}" -u "${TGT_USER}" -p"${TGT_PASS}" \
  -e "FLUSH PRIVILEGES;"
echo "Restore complete."
