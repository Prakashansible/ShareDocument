#!/usr/bin/env bash
# Extract CREATE USER + GRANTS from 5.7, preserving mysql_native_password hashes
# EXACTLY (no password reset). Output is a replayable .sql file for 8.4.
set -euo pipefail
source ./migrate.env
OUT="${DUMP_DIR}/users_grants.sql"
SRC="mysql -h ${SRC_HOST} -P ${SRC_PORT} -u ${SRC_USER} -p${SRC_PASS} -N -B"

{
  echo "-- Users + grants exported from 5.7 $(date -u +%FT%TZ)"
  echo "SET sql_log_bin=0;"
  # Real accounts only: skip system/internal accounts and anonymous users.
  $SRC -e "SELECT CONCAT(user,'@',host) FROM mysql.user \
     WHERE user NOT IN ('mysql.session','mysql.sys','mysql.infoschema','root') \
       AND user <> '' ORDER BY user,host;" \
  | while IFS= read -r acct; do
      u="${acct%@*}"; hh="${acct#*@}"
      # Pull plugin + hash straight from mysql.user to rebuild an exact CREATE USER.
      read -r plugin auth < <($SRC -e \
        "SELECT plugin, authentication_string FROM mysql.user \
         WHERE user='${u}' AND host='${hh}';")
      if [ "${plugin}" = "mysql_native_password" ] && [ -n "${auth}" ]; then
        echo "CREATE USER IF NOT EXISTS '${u}'@'${hh}' IDENTIFIED WITH mysql_native_password AS '${auth}';"
      elif [ "${plugin}" = "caching_sha2_password" ] && [ -n "${auth}" ]; then
        echo "-- ${u}@${hh}: already caching_sha2_password (hash carried as-is)"
        echo "CREATE USER IF NOT EXISTS '${u}'@'${hh}' IDENTIFIED WITH caching_sha2_password AS '${auth}';"
      else
        echo "-- REVIEW ${u}@${hh}: plugin='${plugin}' (socket/LDAP/empty) - handle manually"
      fi
      # Grants for the account.
      $SRC -e "SHOW GRANTS FOR '${u}'@'${hh}';" | sed 's/$/;/'
      echo
  done
} > "${OUT}"

echo "Wrote ${OUT}"
echo "Native-password hashes are portable to 8.4 verbatim (same algorithm)."
echo "Remember: on 8.4 the native plugin must be ENABLED for these to authenticate."
