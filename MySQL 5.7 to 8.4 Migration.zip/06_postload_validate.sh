#!/usr/bin/env bash
# Post-load sanity checks: row counts, object counts, auth verification, stats rebuild.
set -euo pipefail
source ./migrate.env
SRC="mysql -h ${SRC_HOST} -P ${SRC_PORT} -u ${SRC_USER} -p${SRC_PASS} -N -B"
TGT="mysql -h ${TGT_HOST} -P ${TGT_PORT} -u ${TGT_USER} -p${TGT_PASS} -N -B"
IN="($(echo \"$DBS\" | sed \"s/ /','/g;s/^/'/;s/$/'/\"))"

echo "== Table counts per schema (source vs target) =="
for db in ${DBS}; do
  s=$($SRC -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${db}';")
  t=$($TGT -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${db}';")
  printf "  %-20s source=%s target=%s %s\n" "$db" "$s" "$t" \
    "$( [ "$s" = "$t" ] && echo OK || echo '*** MISMATCH ***')"
done

echo; echo "== Routines / triggers / events on target =="
$TGT -e "SELECT routine_schema, COUNT(*) FROM information_schema.routines \
  WHERE routine_schema IN $IN GROUP BY routine_schema;"

echo; echo "== Auth check: migrated accounts and their plugins =="
$TGT -e "SELECT user, host, plugin FROM mysql.user \
  WHERE user NOT IN ('mysql.session','mysql.sys','mysql.infoschema','root') ORDER BY user;"
echo "  (native accounts require mysql_native_password=ON in my.cnf; verify below)"
$TGT -e "SHOW VARIABLES LIKE 'mysql_native_password';"

echo; echo "== Rebuild optimizer stats (5.7 stats do not carry over) =="
for db in ${DBS}; do
  $TGT -N -B -e "SELECT CONCAT('ANALYZE TABLE \`',table_schema,'\`.\`',table_name,'\`;') \
    FROM information_schema.tables WHERE table_schema='${db}' AND table_type='BASE TABLE';" \
  | mysql -h "${TGT_HOST}" -P "${TGT_PORT}" -u "${TGT_USER}" -p"${TGT_PASS}"
done
echo "Validation done."
