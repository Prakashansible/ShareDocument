#!/usr/bin/env bash
# =============================================================================
# pgo-ops.sh - day-to-day helper for Percona Operator for PostgreSQL (v2.x)
# A thin, auditable wrapper around kubectl / patronictl / pgbackrest. Every
# destructive action prints what it will do and asks for confirmation.
#
#   export NS=postgres-operator CL=cluster1
#   ./pgo-ops.sh status | primary | backup [full|diff|incr] |
#                switchover <instance> | failback <instance> |
#                reinit <member> | wal-check | slots
# =============================================================================
set -euo pipefail
NS="${NS:-postgres-operator}"
CL="${CL:-cluster1}"
ROLE_LABEL="postgres-operator.crunchydata.com/role"
CLUSTER_LABEL="postgres-operator.crunchydata.com/cluster=$CL"
CONTAINER="database"

primary_pod() {
  kubectl -n "$NS" get pods -l "$ROLE_LABEL=master" -l "$CLUSTER_LABEL" \
    -o jsonpath='{.items[0].metadata.name}'
}
confirm() { read -rp "Proceed with: $1 ? [y/N] " a; [[ "$a" == "y" || "$a" == "Y" ]]; }

cmd="${1:-status}"
case "$cmd" in
  status)
    echo "== CR =="; kubectl -n "$NS" get pg "$CL"
    echo "== Pods (role) =="
    kubectl -n "$NS" get pods -L "$ROLE_LABEL" -l "$CLUSTER_LABEL"
    echo "== Patroni =="
    kubectl -n "$NS" exec -it "$(primary_pod)" -c "$CONTAINER" -- patronictl list
    ;;
  primary) primary_pod; echo ;;
  backup)
    typ="${2:-full}"
    name="adhoc-${typ}-$(date +%Y%m%d-%H%M%S)"
    echo "Creating PerconaPGBackup $name (--type=$typ) on repo1..."
    cat <<Y | kubectl -n "$NS" apply -f -
apiVersion: pgv2.percona.com/v2
kind: PerconaPGBackup
metadata: { name: $name }
spec: { pgCluster: $CL, repoName: repo1, options: [ "--type=$typ" ] }
Y
    kubectl -n "$NS" get pg-backup
    ;;
  switchover|failback)
    target="${2:?usage: $cmd <targetInstance e.g. cluster1-instance1-cd>}"
    confirm "$cmd -> promote instance $target" || { echo aborted; exit 1; }
    kubectl -n "$NS" patch pg "$CL" --type=merge \
      -p "{\"spec\":{\"patroni\":{\"switchover\":{\"enabled\":true,\"targetInstance\":\"$target\"}}}}"
    kubectl -n "$NS" annotate --overwrite pg "$CL" \
      postgres-operator.crunchydata.com/trigger-switchover="$(date)"
    echo "Triggered. Watch: ./pgo-ops.sh status"
    ;;
  reinit)
    member="${2:?usage: reinit <member pod e.g. cluster1-instance1-cd-0>}"
    confirm "REINIT (rebuild) standby member $member - destroys its data dir" || { echo aborted; exit 1; }
    kubectl -n "$NS" exec -it "$(primary_pod)" -c "$CONTAINER" -- \
      patronictl reinit "$CL" "$member" --force
    ;;
  wal-check)
    p="$(primary_pod)"
    kubectl -n "$NS" exec -it "$p" -c "$CONTAINER" -- pgbackrest info
    kubectl -n "$NS" exec -it "$p" -c "$CONTAINER" -- psql -c \
      "SELECT archived_count, failed_count, last_failed_wal, last_failed_time FROM pg_stat_archiver;"
    kubectl -n "$NS" exec -it "$p" -c "$CONTAINER" -- pgbackrest check --stanza=db
    ;;
  slots)
    kubectl -n "$NS" exec -it "$(primary_pod)" -c "$CONTAINER" -- psql -c \
      "SELECT slot_name, active, wal_status, safe_wal_size FROM pg_replication_slots;"
    kubectl -n "$NS" exec -it "$(primary_pod)" -c "$CONTAINER" -- psql -c \
      "SELECT client_addr, state, sync_state, replay_lag FROM pg_stat_replication;"
    ;;
  *) echo "unknown command: $cmd"; sed -n '3,16p' "$0"; exit 1 ;;
esac
