# PostgreSQL Administration on Kubernetes — Percona Operator Workbook

Reference PDF + working files for a dual-node (Primary/Secondary) streaming-
replication cluster under **Percona Operator for PostgreSQL v2.x** (Patroni +
pgBackRest). Every routine activity is mapped against the traditional VM way.

## Read
- `PostgreSQL-Admin-on-Kubernetes-Percona-Operator-Workbook.pdf` — 22-page workbook,
  Sections 0–7 + appendices. Start with Section 0 (the operator mental model).

## Working files (`manifests/`)
| File | Covers | Workbook §|
|------|--------|-----------|
| `01-cr-backups-config-switchover.yaml` | CR fragments: repos, retention, schedules, dynamicConfiguration, pg_hba, switchover | 1,2,3,5 |
| `02-perconapgbackup-ondemand.yaml` | On-demand backup object | 1.3, 2.2 |
| `03-perconapgrestore-inplace.yaml` | Destructive in-place restore + PITR | 1.4a/b |
| `04-restore-to-new-cluster.yaml` | Safe restore into a clone via dataSource | 1.4c |
| `05-maintenance-vacuum-cronjob.yaml` | VACUUM/ANALYZE CronJob (targets primary) | 4.2 |
| `06-pgcron-jobs.sql` | In-database maintenance via pg_cron | 4.3 |

## Script (`scripts/`)
- `pgo-ops.sh` — audited wrapper: `status | primary | backup | switchover | failback | reinit | wal-check | slots`.
  ```bash
  export NS=postgres-operator CL=cluster1
  ./pgo-ops.sh status
  ./pgo-ops.sh backup diff
  ./pgo-ops.sh switchover cluster1-instance1-cd
  ```

## Before production use
Field names shift between operator minor versions. After any upgrade, confirm the
live schema: `kubectl explain pg.spec.backups.pgbackrest`, `kubectl explain pg-restore.spec`,
`kubectl explain pg.spec.patroni.switchover`. The workbook targets v2.x; see Appendix B
for v3.0 differences.
