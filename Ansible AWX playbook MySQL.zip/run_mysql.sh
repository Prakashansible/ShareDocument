#!/usr/bin/env bash
#===============================================================================
# run_mysql.sh — Run your MySQL/MariaDB Ansible roles straight from GitHub,
#                without AWX / Ansible Tower.
#
# What it replaces: AWX used to clone your repo, install Galaxy dependencies,
# inject an inventory + credentials + vault password + extra_vars, then run
# ansible-playbook. This script does the same steps by hand, on the target VM,
# against localhost (local connection — no SSH round-trip needed).
#
# Usage examples
#   ./run_mysql.sh --check                 # dry run (no changes made)
#   ./run_mysql.sh                         # real run
#   ./run_mysql.sh -e @vars/prod.yml       # pass extra-vars file (survey values)
#   ./run_mysql.sh --tags install          # limit to specific tags
#   ./run_mysql.sh --ssh 10.20.30.40       # run over SSH to a remote VM instead
#
# Author: Cash  |  Safe to re-run (idempotent, as long as your roles are).
#===============================================================================

set -euo pipefail

#------------------------------------------------------------------------------#
# 1. CONFIG — edit these once for your environment, or override via env vars.
#------------------------------------------------------------------------------#
REPO_URL="${REPO_URL:-https://github.com/<ORG>/<REPO>.git}"   # your repo
REPO_BRANCH="${REPO_BRANCH:-main}"
CLONE_DIR="${CLONE_DIR:-/opt/ansible-mysql}"                  # where to clone
PLAYBOOK="${PLAYBOOK:-site.yml}"                              # entry playbook
INV_GROUP="${INV_GROUP:-mysql_servers}"                       # must match hosts: in playbook
REQ_FILES=("requirements.yml" "collections/requirements.yml") # tried in order, if present

# Auth to GitHub: set ONE of these before running (do NOT hardcode secrets here).
#   export GIT_PAT="ghp_xxx"                 # HTTPS + Personal Access Token
#   (or) use an SSH deploy key and set REPO_URL to git@github.com:ORG/REPO.git
GIT_USER="${GIT_USER:-git}"
GIT_PAT="${GIT_PAT:-}"

# Vault: if your role stores the MySQL root password vault-encrypted, point to
# a vault password file, OR leave empty to be prompted interactively.
VAULT_PASS_FILE="${VAULT_PASS_FILE:-}"

#------------------------------------------------------------------------------#
# 2. FLAG PARSING — anything unknown is passed through to ansible-playbook.
#------------------------------------------------------------------------------#
CHECK=""
SSH_HOST=""
PASSTHRU=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --check)        CHECK="--check --diff"; shift ;;
    --ssh)          SSH_HOST="$2"; shift 2 ;;
    -h|--help)      grep '^#' "$0" | sed 's/^# \{0,1\}//' | head -n 30; exit 0 ;;
    *)              PASSTHRU+=("$1"); shift ;;
  esac
done

log()  { printf '\033[1;34m[*]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

#------------------------------------------------------------------------------#
# 3. PREREQUISITES
#------------------------------------------------------------------------------#
log "Checking prerequisites..."
command -v git >/dev/null            || die "git not found. Install: sudo dnf install -y git"
command -v ansible-playbook >/dev/null || die "ansible not found. Install: sudo dnf install -y ansible-core"
# PyMySQL is required by community.mysql modules
python3 -c "import pymysql" 2>/dev/null || {
  warn "PyMySQL missing — installing (community.mysql modules need it)."
  pip3 install --quiet PyMySQL || die "pip3 install PyMySQL failed."
}
ok "ansible: $(ansible --version | head -1)"

#------------------------------------------------------------------------------#
# 4. CLONE / UPDATE REPO
#------------------------------------------------------------------------------#
CLONE_AUTH_URL="$REPO_URL"
if [[ "$REPO_URL" == https://* && -n "$GIT_PAT" ]]; then
  # Inject token only into the in-memory URL, never written to git config/history.
  CLONE_AUTH_URL="https://${GIT_USER}:${GIT_PAT}@${REPO_URL#https://}"
fi

if [[ -d "$CLONE_DIR/.git" ]]; then
  log "Repo exists — fetching latest ($REPO_BRANCH)..."
  git -C "$CLONE_DIR" fetch --quiet origin "$REPO_BRANCH"
  git -C "$CLONE_DIR" checkout --quiet "$REPO_BRANCH"
  git -C "$CLONE_DIR" reset --hard --quiet "origin/$REPO_BRANCH"
else
  log "Cloning $REPO_URL ($REPO_BRANCH) -> $CLONE_DIR"
  git clone --quiet --branch "$REPO_BRANCH" "$CLONE_AUTH_URL" "$CLONE_DIR"
  # Scrub any embedded token from the stored remote URL.
  git -C "$CLONE_DIR" remote set-url origin "$REPO_URL"
fi
ok "Repo ready at $CLONE_DIR (commit $(git -C "$CLONE_DIR" rev-parse --short HEAD))"
cd "$CLONE_DIR"

#------------------------------------------------------------------------------#
# 5. GALAXY DEPENDENCIES  (the step AWX did silently)
#------------------------------------------------------------------------------#
INSTALLED_REQ=0
for rf in "${REQ_FILES[@]}"; do
  if [[ -f "$rf" ]]; then
    log "Installing Galaxy collections/roles from $rf"
    ansible-galaxy collection install -r "$rf" 2>/dev/null || true
    ansible-galaxy role install       -r "$rf" 2>/dev/null || true
    INSTALLED_REQ=1
  fi
done
if [[ "$INSTALLED_REQ" -eq 0 ]]; then
  warn "No requirements.yml found — installing community.mysql explicitly."
  ansible-galaxy collection install community.mysql >/dev/null
fi
ok "Dependencies installed."

#------------------------------------------------------------------------------#
# 6. INVENTORY  (generated on the fly)
#------------------------------------------------------------------------------#
INV_FILE="$(mktemp /tmp/mysql_inv.XXXXXX.ini)"
trap 'rm -f "$INV_FILE"' EXIT
if [[ -n "$SSH_HOST" ]]; then
  # Remote mode — behaves like AWX pushing over SSH.
  printf '[%s]\n%s\n' "$INV_GROUP" "$SSH_HOST" > "$INV_FILE"
  CONN_NOTE="SSH -> $SSH_HOST"
else
  # Local mode — run against this VM directly, no SSH.
  printf '[%s]\nlocalhost ansible_connection=local\n' "$INV_GROUP" > "$INV_FILE"
  CONN_NOTE="local connection (this VM)"
fi
ok "Inventory built: group [$INV_GROUP], $CONN_NOTE"

#------------------------------------------------------------------------------#
# 7. VAULT HANDLING
#------------------------------------------------------------------------------#
VAULT_ARGS=()
if [[ -n "$VAULT_PASS_FILE" ]]; then
  [[ -f "$VAULT_PASS_FILE" ]] || die "VAULT_PASS_FILE not found: $VAULT_PASS_FILE"
  VAULT_ARGS=(--vault-password-file "$VAULT_PASS_FILE")
elif grep -rqs '\$ANSIBLE_VAULT' . 2>/dev/null; then
  warn "Vault-encrypted content detected — you will be prompted for the vault password."
  VAULT_ARGS=(--ask-vault-pass)
fi

#------------------------------------------------------------------------------#
# 8. RUN
#------------------------------------------------------------------------------#
[[ -f "$PLAYBOOK" ]] || die "Playbook '$PLAYBOOK' not found in repo. Set PLAYBOOK=..."

log "Running ansible-playbook..."
set -x
ansible-playbook -i "$INV_FILE" "$PLAYBOOK" \
  --become \
  ${CHECK} \
  "${VAULT_ARGS[@]}" \
  "${PASSTHRU[@]}"
set +x

ok "Done. Review the PLAY RECAP above — failed=0 means a clean run."
