# ══════════════════════════════════════════════════════════════════
# provider.tf - SSNC Private Cloud Provider Configuration
# ══════════════════════════════════════════════════════════════════
# Authentication via API Key.
# NEVER hardcode the API key here. Use environment variable:
#   export TF_VAR_ssccloud_api_key="your-api-key"
# ══════════════════════════════════════════════════════════════════

provider "ssccloud" {
  api_key = var.ssccloud_api_key
}
