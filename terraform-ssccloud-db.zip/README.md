# Terraform SSNC Cloud - Database VM Provisioning + AWX

Automated end-to-end workflow for provisioning database VMs in SSNC Private Cloud
and deploying MySQL/MariaDB via AWX Job Templates — all within a single `terraform apply`.

## Architecture

```
terraform apply
  │
  ├─ Phase 1: ssccloud_instance    → Provision VM (image, cpu, memory, disk, zone, etc.)
  ├─ Phase 2: ssccloud_access      → Open port 3306/tcp from enterprise (Database SG)
  ├─ Phase 3: null_resource         → SSH health checks (OS, CPU, memory, disk, LVM tools)
  ├─ Phase 4: null_resource         → LVM setup: PV → VG → LV → XFS → mount /apps
  └─ Phase 5: null_resource         → Trigger AWX Job Template → poll until complete
```

## Prerequisites

- Terraform >= 1.5.0
- SSNC Cloud API Key
- AWX Personal Access Token (PAT) with write scope
- AWX Job Template (pre-configured for MySQL/MariaDB) that accepts `apps_dir` extra var
- SSH key pair that can access the provisioned VM
- `curl` and `jq` installed on the machine running Terraform

## Quick Start

```bash
# 1. Clone
git clone git@git.corp.internal:dba/terraform-ssccloud-db.git
cd terraform-ssccloud-db

# 2. Set secrets (NEVER put these in .tfvars)
export TF_VAR_ssccloud_api_key="your-ssnc-cloud-api-key"
export TF_VAR_awx_token="your-awx-personal-access-token"

# 3. Make script executable
chmod +x scripts/trigger_awx.sh

# 4. Initialize
terraform init

# 5. Plan + Apply
terraform plan -var-file=envs/prod.tfvars
terraform apply -var-file=envs/prod.tfvars
```

## Environment Files

| File | Environment | Patching Window | Typical Sizing |
|------|-------------|-----------------|----------------|
| `envs/dev.tfvars` | Development | `1st-tue-9pm-12am` | 2 CPU, 4 GB, 50 GB disk |
| `envs/uat.tfvars` | UAT/Staging | `2nd-thu-10pm-1am` | 4 CPU, 16 GB, 200 GB disk |
| `envs/prod.tfvars` | Production | `3rd-sun-2am-5am` | 8 CPU, 32 GB, 500 GB disk |

## Standard Cloud Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `image` | Yes | OS image (e.g., `AlmaLinux-8`, `AlmaLinux-9`) |
| `name` | Yes | VM hostname |
| `deployment_zone` | Yes | Region/zone for VM placement |
| `cpu` | Yes | Number of vCPUs |
| `memory` | Yes | Memory in GB |
| `subproject` | Yes | Subproject ID |
| `security_groups` | Yes | Security groups (must include `Database`) |
| `patching_group` | Yes | `self_managed` or `Nth-day-startTime-endTime` |
| `dns_aliases` | No | Optional DNS aliases (list, can be empty) |
| `disk_size_gb` | Yes | Block storage size in GB for LVM /apps |

## Storage Layout (LVM)

```
/dev/sdb  (block storage)
  └── PV: /dev/sdb
       └── VG: vg_apps
            └── LV: lv_apps (100% free)
                 └── XFS → /apps
                      └── (AWX creates all subdirectories)
```

## Security

- **API Key**: Set via `TF_VAR_ssccloud_api_key` env var. Marked `sensitive`.
- **AWX Token**: Set via `TF_VAR_awx_token` env var. Marked `sensitive`.
- **State**: Use encrypted remote backend. See `backend.tf` for options.
- **SSH Keys**: Store in Vault. Rotate after provisioning cycles.
- **Access Rule**: `ssccloud_access` scoped to Database SG, enterprise source only.

## Project Structure

```
terraform-ssccloud-db/
  ├── main.tf               # ssccloud_instance + ssccloud_access
  ├── variables.tf           # All variable declarations
  ├── outputs.tf             # Deployment outputs
  ├── provider.tf            # ssccloud provider config
  ├── versions.tf            # Version constraints
  ├── backend.tf             # Remote state backend (configure per org)
  ├── vm_health_check.tf     # Phase 3: VM readiness checks
  ├── lvm_setup.tf           # Phase 4: PV/VG/LV + /apps mount
  ├── awx_trigger.tf         # Phase 5: AWX job launch + poll
  ├── scripts/
  │   └── trigger_awx.sh     # AWX REST API trigger script
  ├── envs/
  │   ├── dev.tfvars
  │   ├── uat.tfvars
  │   └── prod.tfvars
  ├── .gitignore
  └── README.md
```
