# ══════════════════════════════════════════════════════════════════
# vm_health_check.tf - Phase 3: VM Readiness Verification
# ══════════════════════════════════════════════════════════════════
# SSHs into the newly provisioned VM and runs health checks.
# If any check fails, terraform apply stops immediately and
# does NOT proceed to LVM setup or AWX trigger.
# ══════════════════════════════════════════════════════════════════

resource "null_resource" "vm_health_check" {

  triggers = {
    vm_id = ssccloud_instance.db_vm.id
  }

  # Wait for both VM and access rule to be created
  depends_on = [
    ssccloud_instance.db_vm,
    ssccloud_access.mysql_access
  ]

  provisioner "remote-exec" {
    inline = [
      "#!/bin/bash",
      "set -euo pipefail",
      "",
      "echo '======================================'",
      "echo '  VM HEALTH CHECK - START'",
      "echo '======================================'",
      "",
      "# Check 1: Verify OS image",
      "echo '[CHECK 1] Verifying OS image...'",
      "cat /etc/os-release | grep -E \"^(ID|VERSION_ID)\"",
      "echo '[CHECK 1] PASSED'",
      "",
      "# Check 2: Verify CPU count",
      "echo '[CHECK 2] Verifying CPU...'",
      "ACTUAL_CPU=$(nproc)",
      "echo \"  Detected: $ACTUAL_CPU vCPUs | Expected: ${var.cpu}\"",
      "if [ \"$ACTUAL_CPU\" -lt \"${var.cpu}\" ]; then",
      "  echo '[CHECK 2] FAILED: CPU mismatch' && exit 1",
      "fi",
      "echo '[CHECK 2] PASSED'",
      "",
      "# Check 3: Verify memory (GB)",
      "echo '[CHECK 3] Verifying memory...'",
      "ACTUAL_MEM_GB=$(($(grep MemTotal /proc/meminfo | awk '{print $2}') / 1048576))",
      "echo \"  Detected: $${ACTUAL_MEM_GB} GB | Expected: ~${var.memory} GB\"",
      "echo '[CHECK 3] PASSED'",
      "",
      "# Check 4: Verify block storage disk is attached",
      "echo '[CHECK 4] Verifying block storage ${var.block_device}...'",
      "if [ ! -b \"${var.block_device}\" ]; then",
      "  echo '[CHECK 4] FAILED: ${var.block_device} not found' && exit 1",
      "fi",
      "DISK_SIZE=$(lsblk -b -dn -o SIZE ${var.block_device} | awk '{print int($1/1073741824)}')",
      "echo \"  Detected: ${var.block_device} ($${DISK_SIZE} GB)\"",
      "echo '[CHECK 4] PASSED'",
      "",
      "# Check 5: Verify LVM tools are available",
      "echo '[CHECK 5] Verifying LVM tools...'",
      "which pvcreate vgcreate lvcreate > /dev/null 2>&1 || {",
      "  echo '  LVM tools missing, installing lvm2...'",
      "  sudo yum install -y lvm2 > /dev/null 2>&1",
      "}",
      "echo '[CHECK 5] PASSED'",
      "",
      "# Check 6: Verify network connectivity",
      "echo '[CHECK 6] Verifying network...'",
      "ip addr show | grep \"inet \"",
      "echo '[CHECK 6] PASSED'",
      "",
      "echo '======================================'",
      "echo '  ALL HEALTH CHECKS PASSED'",
      "echo '  VM is ready for LVM setup'",
      "echo '======================================'",
    ]

    connection {
      type        = "ssh"
      host        = ssccloud_instance.db_vm.ip_address
      user        = var.ssh_user
      private_key = file(var.ssh_private_key_path)
      timeout     = "5m"
    }
  }
}
