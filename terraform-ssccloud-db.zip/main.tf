# ══════════════════════════════════════════════════════════════════
# main.tf - VM Instance + Access Rule
# ══════════════════════════════════════════════════════════════════
# Phase 1: Provision VM via ssccloud_instance
# Phase 2: Create access rule via ssccloud_access
# ══════════════════════════════════════════════════════════════════


# ──────────────────────────────────────────────────────────────────
# PHASE 1: Create VM Instance
# ──────────────────────────────────────────────────────────────────

resource "ssccloud_instance" "db_vm" {
  image           = var.image
  name            = var.name
  deployment_zone = var.deployment_zone
  cpu             = var.cpu
  memory          = var.memory
  subproject      = var.subproject
  security_groups = var.security_groups
  patching_group  = var.patching_group

  # Optional DNS aliases (can be empty list)
  dynamic "dns_alias" {
    for_each = var.dns_aliases
    content {
      name = dns_alias.value
    }
  }

  # Block storage disk for LVM -> /apps
  disk {
    size_gb = var.disk_size_gb
    type    = "block"
    label   = "apps-storage"
  }

  tags = {
    role       = "database"
    engine     = var.db_engine
    managed_by = "terraform"
  }
}


# ──────────────────────────────────────────────────────────────────
# PHASE 2: Create Access Rule for MySQL/MariaDB
# ──────────────────────────────────────────────────────────────────
# Opens port 3306 (TCP) from enterprise source through the
# Database security group.
# ──────────────────────────────────────────────────────────────────

resource "ssccloud_access" "mysql_access" {
  instance_id    = ssccloud_instance.db_vm.id

  port           = var.db_port        # 3306
  protocol       = "tcp"

  source         = "enterprise"

  security_group = "Database"

  description    = "Allow MySQL/MariaDB access (port ${var.db_port}/tcp) from enterprise via Database security group"
}
