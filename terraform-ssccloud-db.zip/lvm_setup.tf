# ══════════════════════════════════════════════════════════════════
# lvm_setup.tf - Phase 4: LVM Setup + /apps Mount
# ══════════════════════════════════════════════════════════════════
# Creates the full LVM stack on the block storage disk:
#   PV -> VG (vg_apps) -> LV (lv_apps, 100% free) -> XFS -> /apps
#
# IMPORTANT: No directories are created inside /apps.
# The AWX Job Template is fully responsible for creating all
# subdirectories (datadir, logdir, tmpdir, etc.) inside /apps.
#
# All steps are idempotent - safe to re-run on taint/recreate.
# ══════════════════════════════════════════════════════════════════

resource "null_resource" "lvm_setup" {

  # Only run after VM health checks pass
  depends_on = [null_resource.vm_health_check]

  triggers = {
    vm_id = ssccloud_instance.db_vm.id
  }

  provisioner "remote-exec" {
    inline = [
      "#!/bin/bash",
      "set -euo pipefail",
      "",
      "echo '======================================'",
      "echo '  LVM SETUP + /apps MOUNT - START'",
      "echo '======================================'",
      "",
      "DEVICE=\"${var.block_device}\"",
      "VG_NAME=\"${var.vg_name}\"",
      "LV_NAME=\"${var.lv_name}\"",
      "MOUNT_POINT=\"${var.mount_point}\"",
      "LV_PATH=\"/dev/$VG_NAME/$LV_NAME\"",
      "",
      "# ── Step 1: Create Physical Volume ──",
      "echo '[STEP 1] Creating Physical Volume on $DEVICE...'",
      "if sudo pvs $DEVICE > /dev/null 2>&1; then",
      "  echo '  PV already exists on $DEVICE, skipping'",
      "else",
      "  sudo pvcreate $DEVICE",
      "  echo '  PV created successfully'",
      "fi",
      "sudo pvs $DEVICE",
      "echo '[STEP 1] DONE'",
      "",
      "# ── Step 2: Create Volume Group ──",
      "echo ''",
      "echo '[STEP 2] Creating Volume Group: $VG_NAME...'",
      "if sudo vgs $VG_NAME > /dev/null 2>&1; then",
      "  echo '  VG $VG_NAME already exists, skipping'",
      "else",
      "  sudo vgcreate $VG_NAME $DEVICE",
      "  echo '  VG created successfully'",
      "fi",
      "sudo vgs $VG_NAME",
      "echo '[STEP 2] DONE'",
      "",
      "# ── Step 3: Create Logical Volume (100% of VG free space) ──",
      "echo ''",
      "echo '[STEP 3] Creating Logical Volume: $LV_NAME...'",
      "if sudo lvs $VG_NAME/$LV_NAME > /dev/null 2>&1; then",
      "  echo '  LV $LV_NAME already exists, skipping'",
      "else",
      "  sudo lvcreate -l 100%FREE -n $LV_NAME $VG_NAME",
      "  echo '  LV created successfully'",
      "fi",
      "sudo lvs $VG_NAME/$LV_NAME",
      "echo '[STEP 3] DONE'",
      "",
      "# ── Step 4: Format with XFS filesystem ──",
      "echo ''",
      "echo '[STEP 4] Formatting LV with XFS...'",
      "if sudo blkid $LV_PATH | grep -q xfs; then",
      "  echo '  $LV_PATH already formatted as XFS, skipping'",
      "else",
      "  sudo mkfs.xfs $LV_PATH",
      "  echo '  XFS filesystem created successfully'",
      "fi",
      "echo '[STEP 4] DONE'",
      "",
      "# ── Step 5: Create mount point and mount ──",
      "echo ''",
      "echo '[STEP 5] Mounting at $MOUNT_POINT...'",
      "sudo mkdir -p $MOUNT_POINT",
      "if mountpoint -q $MOUNT_POINT; then",
      "  echo '  $MOUNT_POINT already mounted, skipping'",
      "else",
      "  sudo mount $LV_PATH $MOUNT_POINT",
      "  echo '  Mounted successfully'",
      "fi",
      "echo '[STEP 5] DONE'",
      "",
      "# ── Step 6: Add to /etc/fstab for boot persistence ──",
      "echo ''",
      "echo '[STEP 6] Adding fstab entry...'",
      "FSTAB_ENTRY=\"$LV_PATH  $MOUNT_POINT  xfs  defaults,noatime  0 2\"",
      "if grep -q \"$LV_PATH\" /etc/fstab; then",
      "  echo '  fstab entry already exists, skipping'",
      "else",
      "  echo \"$FSTAB_ENTRY\" | sudo tee -a /etc/fstab > /dev/null",
      "  echo '  fstab entry added'",
      "fi",
      "echo '[STEP 6] DONE'",
      "",
      "# ── Step 7: Set directory permissions ──",
      "echo ''",
      "echo '[STEP 7] Setting permissions on $MOUNT_POINT...'",
      "sudo chmod 755 $MOUNT_POINT",
      "echo '  Permissions set to 755'",
      "echo '[STEP 7] DONE'",
      "",
      "# ── Step 8: Final Verification ──",
      "echo ''",
      "echo '[STEP 8] Final verification...'",
      "echo '  --- PV ---'",
      "sudo pvs $DEVICE",
      "echo '  --- VG ---'",
      "sudo vgs $VG_NAME",
      "echo '  --- LV ---'",
      "sudo lvs $VG_NAME/$LV_NAME",
      "echo '  --- Mount ---'",
      "df -h $MOUNT_POINT",
      "echo '  --- fstab ---'",
      "grep $LV_PATH /etc/fstab",
      "",
      "# Write test to confirm /apps is writable",
      "sudo touch $MOUNT_POINT/.lvm_ready",
      "echo '  Write test: PASSED'",
      "",
      "echo '======================================'",
      "echo '  LVM SETUP COMPLETE'",
      "echo \"  $MOUNT_POINT is ready for AWX\"",
      "echo '  (No subdirectories created -'",
      "echo '   AWX Job Template handles that)'",
      "echo '======================================'",
    ]

    connection {
      type        = "ssh"
      host        = ssccloud_instance.db_vm.ip_address
      user        = var.ssh_user
      private_key = file(var.ssh_private_key_path)
      timeout     = "5m"
    }
  }
}
