# ══════════════════════════════════════════════════════════════════
# variables.tf - All Input Variable Declarations
# ══════════════════════════════════════════════════════════════════


# ──────────────────────────────────────────────────────────────────
# SSNC CLOUD AUTHENTICATION
# ──────────────────────────────────────────────────────────────────

variable "ssccloud_api_key" {
  description = "API Key for SSNC Private Cloud authentication"
  type        = string
  sensitive   = true
}


# ──────────────────────────────────────────────────────────────────
# STANDARD CLOUD VARIABLES (ssccloud_instance)
# ──────────────────────────────────────────────────────────────────

variable "image" {
  description = "OS image for the VM (must be present with a value)"
  type        = string

  validation {
    condition     = length(var.image) > 0
    error_message = "image must be present with a value."
  }
}

variable "name" {
  description = "VM name/hostname"
  type        = string

  validation {
    condition     = length(var.name) > 0
    error_message = "name must be provided."
  }
}

variable "deployment_zone" {
  description = "Region/zone where VM should be deployed"
  type        = string
}

variable "cpu" {
  description = "Number of vCPUs"
  type        = number
}

variable "memory" {
  description = "Memory in GB"
  type        = number
}

variable "subproject" {
  description = "Subproject ID where this VM needs to be created"
  type        = string
}

variable "security_groups" {
  description = "Security groups to attach (must include Database)"
  type        = list(string)
  default     = ["Database"]
}

variable "patching_group" {
  description = "Patching schedule: self_managed or format like 3rd-sun-2am-5am"
  type        = string
  default     = "self_managed"

  validation {
    condition = (
      var.patching_group == "self_managed" ||
      can(regex("^(1st|2nd|3rd|4th|every)-(mon|tue|wed|thu|fri|sat|sun)-[0-9]{1,2}(am|pm)-[0-9]{1,2}(am|pm)$", var.patching_group))
    )
    error_message = "Must be 'self_managed' or format: Nth-day-startTime-endTime (e.g., 3rd-sun-2am-5am)"
  }
}

variable "dns_aliases" {
  description = "Optional DNS alias names for the VM (can be empty)"
  type        = list(string)
  default     = []
}


# ──────────────────────────────────────────────────────────────────
# BLOCK STORAGE
# ──────────────────────────────────────────────────────────────────

variable "disk_size_gb" {
  description = "Block storage disk size in GB (used for LVM /apps)"
  type        = number
  default     = 200
}


# ──────────────────────────────────────────────────────────────────
# LVM CONFIGURATION
# ──────────────────────────────────────────────────────────────────

variable "block_device" {
  description = "Block storage device path on the VM"
  type        = string
  default     = "/dev/sdb"
}

variable "vg_name" {
  description = "LVM Volume Group name"
  type        = string
  default     = "vg_apps"
}

variable "lv_name" {
  description = "LVM Logical Volume name"
  type        = string
  default     = "lv_apps"
}

variable "mount_point" {
  description = "Mount point for the LV (AWX DB template uses this)"
  type        = string
  default     = "/apps"
}


# ──────────────────────────────────────────────────────────────────
# SSH CONFIGURATION
# ──────────────────────────────────────────────────────────────────

variable "ssh_user" {
  description = "SSH user for VM access"
  type        = string
  default     = "almaadmin"
}

variable "ssh_private_key_path" {
  description = "Path to SSH private key"
  type        = string
  default     = "~/.ssh/id_rsa"
}


# ──────────────────────────────────────────────────────────────────
# AWX CONFIGURATION
# ──────────────────────────────────────────────────────────────────

variable "awx_url" {
  description = "AWX/Tower base URL"
  type        = string
}

variable "awx_token" {
  description = "AWX Personal Access Token (PAT)"
  type        = string
  sensitive   = true
}

variable "awx_job_template_id" {
  description = "AWX Job Template ID for MySQL/MariaDB setup"
  type        = number
}


# ──────────────────────────────────────────────────────────────────
# DATABASE CONFIGURATION
# ──────────────────────────────────────────────────────────────────

variable "db_engine" {
  description = "Database engine: mysql or mariadb"
  type        = string
  default     = "mariadb"

  validation {
    condition     = contains(["mysql", "mariadb"], var.db_engine)
    error_message = "Allowed values: mysql, mariadb"
  }
}

variable "db_version" {
  description = "Database version (e.g., 10.11 for MariaDB, 8.0 for MySQL)"
  type        = string
  default     = "10.11"
}

variable "db_port" {
  description = "Database listener port"
  type        = number
  default     = 3306
}
