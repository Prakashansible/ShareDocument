#!/bin/bash
# ══════════════════════════════════════════════════════════════════
# scripts/trigger_awx.sh
# ══════════════════════════════════════════════════════════════════
# Called by Terraform local-exec provisioner (awx_trigger.tf).
# All variables are passed via environment from Terraform.
#
# This script:
#   1. Launches the AWX Job Template via REST API
#   2. Polls the job status every POLL_INTERVAL seconds
#   3. Exits 0 on success, 1 on failure/timeout
#
# If this script exits non-zero, terraform apply fails.
# ══════════════════════════════════════════════════════════════════

set -euo pipefail

echo "============================================"
echo "  AWX JOB TEMPLATE TRIGGER"
echo "============================================"
echo "  AWX URL:         ${AWX_URL}"
echo "  Template ID:     ${JOB_TEMPLATE_ID}"
echo "  Target Host:     ${TARGET_HOST}"
echo "  Target Hostname: ${TARGET_HOSTNAME}"
echo "  DB Engine:       ${DB_ENGINE} ${DB_VERSION}"
echo "  DB Port:         ${DB_PORT}"
echo "  Apps Directory:  ${APPS_DIR}"
echo "============================================"


# ──────────────────────────────────────────────────────────────────
# STEP 1: Launch the AWX Job Template
# ──────────────────────────────────────────────────────────────────

echo ""
echo "[STEP 1] Launching AWX Job Template..."

LAUNCH_RESPONSE=$(curl -s -w "\n%{http_code}" \
  -X POST "${AWX_URL}/api/v2/job_templates/${JOB_TEMPLATE_ID}/launch/" \
  -H "Authorization: Bearer ${AWX_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"extra_vars\": {
      \"target_host\": \"${TARGET_HOST}\",
      \"target_hostname\": \"${TARGET_HOSTNAME}\",
      \"db_engine\": \"${DB_ENGINE}\",
      \"db_version\": \"${DB_VERSION}\",
      \"db_port\": ${DB_PORT},
      \"apps_dir\": \"${APPS_DIR}\"
    }
  }")

HTTP_CODE=$(echo "$LAUNCH_RESPONSE" | tail -1)
BODY=$(echo "$LAUNCH_RESPONSE" | head -n -1)

if [ "$HTTP_CODE" -ne 201 ]; then
  echo "[ERROR] Failed to launch AWX job. HTTP status: $HTTP_CODE"
  echo "$BODY"
  exit 1
fi

JOB_ID=$(echo "$BODY" | jq -r ".id")
echo "[STEP 1] AWX Job launched successfully. Job ID: $JOB_ID"


# ──────────────────────────────────────────────────────────────────
# STEP 2: Poll job status until completion
# ──────────────────────────────────────────────────────────────────

echo ""
echo "[STEP 2] Polling AWX job status..."
echo "  Poll interval: ${POLL_INTERVAL}s"
echo "  Max wait:      ${MAX_WAIT_SECONDS}s"

ELAPSED=0

while true; do
  STATUS=$(curl -s \
    -H "Authorization: Bearer ${AWX_TOKEN}" \
    "${AWX_URL}/api/v2/jobs/${JOB_ID}/" | jq -r ".status")

  echo "  [${ELAPSED}s] Job $JOB_ID status: $STATUS"

  case "$STATUS" in
    successful)
      echo ""
      echo "============================================"
      echo "  AWX JOB COMPLETED SUCCESSFULLY"
      echo "  Job ID:    $JOB_ID"
      echo "  Database:  ${DB_ENGINE} ${DB_VERSION}"
      echo "  Host:      ${TARGET_HOST}"
      echo "  Apps Dir:  ${APPS_DIR}"
      echo "============================================"
      exit 0
      ;;
    failed|error|canceled)
      echo ""
      echo "[FATAL] AWX Job FAILED with status: $STATUS"
      echo "  Review job details in AWX UI:"
      echo "  ${AWX_URL}/#/jobs/$JOB_ID"
      exit 1
      ;;
    pending|waiting|running)
      # Still in progress, continue polling
      ;;
    *)
      echo "  [WARN] Unexpected status: $STATUS"
      ;;
  esac

  # Timeout check
  ELAPSED=$((ELAPSED + POLL_INTERVAL))
  if [ "$ELAPSED" -ge "$MAX_WAIT_SECONDS" ]; then
    echo ""
    echo "[FATAL] AWX job timed out after ${MAX_WAIT_SECONDS}s"
    echo "  Job $JOB_ID may still be running in AWX."
    echo "  Check: ${AWX_URL}/#/jobs/$JOB_ID"
    exit 1
  fi

  sleep "$POLL_INTERVAL"
done
