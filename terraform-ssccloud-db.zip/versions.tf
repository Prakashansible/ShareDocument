# ══════════════════════════════════════════════════════════════════
# versions.tf - Terraform and Provider Version Constraints
# ══════════════════════════════════════════════════════════════════

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    ssccloud = {
      source  = "terraform.ssnc-corp.cloud/ssnc/ssnccloud"
      version = ">= 1.0.0"
    }
  }
}
