# ══════════════════════════════════════════════════════════════════
# outputs.tf - Terraform Root Outputs
# ══════════════════════════════════════════════════════════════════
# Displayed after terraform apply completes successfully.
# Provides full summary of the provisioned VM, LVM, access rule,
# and database deployment status.
# ══════════════════════════════════════════════════════════════════

output "vm_ip_address" {
  description = "IP address of the database VM"
  value       = ssccloud_instance.db_vm.ip_address
}

output "vm_id" {
  description = "SSNC Cloud VM ID"
  value       = ssccloud_instance.db_vm.id
}

output "vm_name" {
  description = "VM name/hostname"
  value       = ssccloud_instance.db_vm.name
}

output "deployment_zone" {
  description = "Deployment zone"
  value       = var.deployment_zone
}

output "subproject" {
  description = "Subproject ID"
  value       = var.subproject
}

output "lvm_info" {
  description = "LVM layout summary"
  value       = "PV=${var.block_device} -> VG=${var.vg_name} -> LV=${var.lv_name} -> ${var.mount_point}"
}

output "access_rule" {
  description = "MySQL access rule summary"
  value       = "Port ${var.db_port}/tcp from enterprise via Database security group"
}

output "db_engine" {
  description = "Database engine deployed"
  value       = "${var.db_engine} ${var.db_version}"
}

output "apps_dir" {
  description = "Apps directory (DB home)"
  value       = var.mount_point
}

output "patching_group" {
  description = "Patching schedule"
  value       = var.patching_group
}

output "deployment_status" {
  description = "Overall deployment status"
  value       = "VM provisioned in ${var.deployment_zone}, LVM ${var.mount_point} mounted, port ${var.db_port} opened, ${var.db_engine} ${var.db_version} configured via AWX"
}
