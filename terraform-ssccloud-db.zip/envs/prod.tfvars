# ══════════════════════════════════════════════════════════════════
# envs/prod.tfvars - Production Environment
# ══════════════════════════════════════════════════════════════════
# Usage:
#   export TF_VAR_ssccloud_api_key="your-api-key"
#   export TF_VAR_awx_token="your-awx-token"
#   terraform apply -var-file=envs/prod.tfvars
# ══════════════════════════════════════════════════════════════════

# ── Standard Cloud Variables ──
image           = "AlmaLinux-9"
name            = "prod-mysql-01"
deployment_zone = "us-east-1a"
cpu             = 8
memory          = 32
subproject      = "PROJ-DB-PROD-001"
security_groups = ["Database"]
patching_group  = "3rd-sun-2am-5am"
dns_aliases     = ["prod-mysql-01.db.corp.internal"]

# ── Block Storage ──
disk_size_gb = 500

# ── LVM (defaults are typically fine) ──
# block_device = "/dev/sdb"
# vg_name      = "vg_apps"
# lv_name      = "lv_apps"
# mount_point  = "/apps"

# ── SSH ──
ssh_user             = "almaadmin"
ssh_private_key_path = "~/.ssh/db_deploy_key"

# ── AWX ──
awx_url             = "https://awx.corp.internal"
awx_job_template_id = 42

# ── Database ──
db_engine  = "mariadb"
db_version = "10.11"
db_port    = 3306
