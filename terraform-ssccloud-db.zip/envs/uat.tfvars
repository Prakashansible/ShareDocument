# ══════════════════════════════════════════════════════════════════
# envs/uat.tfvars - UAT / Staging Environment
# ══════════════════════════════════════════════════════════════════
# Usage:
#   export TF_VAR_ssccloud_api_key="your-api-key"
#   export TF_VAR_awx_token="your-awx-token"
#   terraform apply -var-file=envs/uat.tfvars
# ══════════════════════════════════════════════════════════════════

# ── Standard Cloud Variables ──
image           = "AlmaLinux-9"
name            = "uat-mysql-01"
deployment_zone = "us-east-1b"
cpu             = 4
memory          = 16
subproject      = "PROJ-DB-UAT-001"
security_groups = ["Database"]
patching_group  = "2nd-thu-10pm-1am"
dns_aliases     = ["uat-mysql-01.db.corp.internal"]

# ── Block Storage ──
disk_size_gb = 200

# ── SSH ──
ssh_user             = "almaadmin"
ssh_private_key_path = "~/.ssh/db_deploy_key"

# ── AWX ──
awx_url             = "https://awx.corp.internal"
awx_job_template_id = 42

# ── Database ──
db_engine  = "mariadb"
db_version = "10.11"
db_port    = 3306
