# ══════════════════════════════════════════════════════════════════
# envs/dev.tfvars - Development Environment
# ══════════════════════════════════════════════════════════════════
# Usage:
#   export TF_VAR_ssccloud_api_key="your-api-key"
#   export TF_VAR_awx_token="your-awx-token"
#   terraform apply -var-file=envs/dev.tfvars
# ══════════════════════════════════════════════════════════════════

# ── Standard Cloud Variables ──
image           = "AlmaLinux-8"
name            = "dev-mysql-01"
deployment_zone = "us-east-1b"
cpu             = 2
memory          = 4
subproject      = "PROJ-DB-DEV-001"
security_groups = ["Database"]
patching_group  = "1st-tue-9pm-12am"
dns_aliases     = []

# ── Block Storage ──
disk_size_gb = 50

# ── SSH ──
ssh_user             = "almaadmin"
ssh_private_key_path = "~/.ssh/id_rsa"

# ── AWX ──
awx_url             = "https://awx.corp.internal"
awx_job_template_id = 42

# ── Database ──
db_engine  = "mariadb"
db_version = "10.11"
db_port    = 3306
