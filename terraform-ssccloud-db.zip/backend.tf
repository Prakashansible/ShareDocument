# ══════════════════════════════════════════════════════════════════
# backend.tf - Remote State Backend Configuration
# ══════════════════════════════════════════════════════════════════
# Configure your remote backend for state storage and locking.
# Uncomment and modify one of the examples below based on your
# organization's infrastructure.
# ══════════════════════════════════════════════════════════════════

# ── Option 1: S3-Compatible Backend ──
# terraform {
#   backend "s3" {
#     bucket         = "ssnc-terraform-state"
#     key            = "database-vms/terraform.tfstate"
#     region         = "us-east-1"
#     encrypt        = true
#     dynamodb_table = "terraform-state-lock"
#   }
# }

# ── Option 2: Consul Backend ──
# terraform {
#   backend "consul" {
#     address = "consul.corp.internal:8500"
#     scheme  = "https"
#     path    = "terraform/database-vms"
#     lock    = true
#   }
# }

# ── Option 3: Terraform Cloud / Enterprise ──
# terraform {
#   cloud {
#     organization = "ssnc"
#     workspaces {
#       name = "database-provisioning"
#     }
#   }
# }

# ── Option 4: Local Backend (Development Only) ──
# Default behavior when no backend is configured.
# State is stored locally in terraform.tfstate.
# WARNING: Not suitable for team/production use.
