# ══════════════════════════════════════════════════════════════════
# awx_trigger.tf - Phase 5: AWX Job Template Trigger
# ══════════════════════════════════════════════════════════════════
# Once /apps is mounted and ready, triggers the AWX Job Template
# via REST API using local-exec.
#
# The AWX playbook is fully responsible for:
#   - Creating all directories inside /apps
#   - Installing and configuring MySQL/MariaDB
#   - Starting and validating the database service
#
# If the AWX job fails or times out, terraform apply fails.
# ══════════════════════════════════════════════════════════════════

resource "null_resource" "awx_db_setup" {

  # Only run after LVM + /apps is ready
  depends_on = [null_resource.lvm_setup]

  triggers = {
    vm_id      = ssccloud_instance.db_vm.id
    db_engine  = var.db_engine
    db_version = var.db_version
  }

  provisioner "local-exec" {
    command     = "${path.module}/scripts/trigger_awx.sh"
    interpreter = ["/bin/bash", "-c"]

    environment = {
      AWX_URL          = var.awx_url
      AWX_TOKEN        = var.awx_token
      JOB_TEMPLATE_ID  = var.awx_job_template_id
      TARGET_HOST      = ssccloud_instance.db_vm.ip_address
      TARGET_HOSTNAME  = ssccloud_instance.db_vm.name
      DB_ENGINE        = var.db_engine
      DB_VERSION       = var.db_version
      DB_PORT          = var.db_port
      APPS_DIR         = var.mount_point
      POLL_INTERVAL    = "30"
      MAX_WAIT_SECONDS = "1800"
    }
  }
}
