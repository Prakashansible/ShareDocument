#!/usr/bin/env bash
# ============================================================================
# verify_backup.sh - restore the latest backup to a SCRATCH instance and check.
# Standalone: prints and writes a PASS/FAIL report; exit 0 = verified, 2 = failed.
# Never touches the live data dir or port. AlmaLinux 9 / PGDG layout.
#
#   ./verify_backup.sh --method pgbackrest --stanza main
#   ./verify_backup.sh --method basebackup --image /apps/backups/latest
# ============================================================================
set -euo pipefail

CONF="${PGOPS_HOME:-/apps/pg-ops}/etc/pg-ops.conf"
[ -f "$CONF" ] && . "$CONF"

METHOD="basebackup"
STANZA="main"
IMAGE="${BACKUP_DIR:-/apps/backups}/latest"
SCRATCH="${SCRATCH:-${BACKUP_DIR:-/apps/backups}/_verify}"
SCRATCH_PORT="${SCRATCH_PORT:-6543}"
PGBIN="${PGBIN:-/usr/pgsql-${PG_VERSION:-16}/bin}"
OUT="${PGOPS_OUT:-/apps/logs/pg-ops}"
TS="$(date -u +%Y%m%d_%H%M%S)"
REPORT="$OUT/backupverify_${TS}.txt"

while [ $# -gt 0 ]; do
  case "$1" in
    --method) METHOD="$2"; shift 2;;
    --stanza) STANZA="$2"; shift 2;;
    --image)  IMAGE="$2";  shift 2;;
    --port)   SCRATCH_PORT="$2"; shift 2;;
    *) echo "unknown arg: $1"; exit 1;;
  esac
done

mkdir -p "$OUT"
RESULT="PASS"
log(){ echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$REPORT"; }
fail(){ RESULT="FAIL"; log "FAIL: $*"; finish; exit 2; }

finish(){
  if [ -f "$SCRATCH/postmaster.pid" ]; then
    "$PGBIN/pg_ctl" -D "$SCRATCH" -m immediate stop >/dev/null 2>&1 || true
  fi
  case "$SCRATCH" in
    "${PGDATA:-}"|/|/apps/pgsql_data*) log "refusing to remove $SCRATCH";;
    *) rm -rf "$SCRATCH";;
  esac
  # header line at the very top for quick grep / alerting
  sed -i "1i RESULT: $RESULT  method=$METHOD  $(date -u +%Y-%m-%dT%H:%M:%SZ)" "$REPORT" 2>/dev/null || true
  echo "report: $REPORT"
}
trap 'finish' EXIT

[ "$SCRATCH" = "${PGDATA:-}" ] && fail "SCRATCH equals PGDATA"
[ "$SCRATCH_PORT" = "${PGPORT:-5432}" ] && fail "scratch port equals live port"

log "=== backup verification ($METHOD) -> $SCRATCH on port $SCRATCH_PORT ==="
rm -rf "$SCRATCH"; mkdir -p "$SCRATCH"; chmod 700 "$SCRATCH"

# ---- restore --------------------------------------------------------------
if [ "$METHOD" = "pgbackrest" ]; then
  command -v pgbackrest >/dev/null || fail "pgbackrest not found"
  pgbackrest --stanza="$STANZA" --pg1-path="$SCRATCH" \
             --type=immediate --target-action=promote restore >>"$REPORT" 2>&1 \
    || fail "pgbackrest restore returned non-zero"
elif [ "$METHOD" = "basebackup" ]; then
  if [ -f "$IMAGE/base.tar.gz" ]; then
    tar -xzf "$IMAGE/base.tar.gz" -C "$SCRATCH" || fail "untar base failed"
    [ -f "$IMAGE/pg_wal.tar.gz" ] && \
      tar -xzf "$IMAGE/pg_wal.tar.gz" -C "$SCRATCH/pg_wal" 2>/dev/null || true
  elif [ -d "$IMAGE" ]; then
    cp -a "$IMAGE/." "$SCRATCH/" || fail "copy image failed"
  else
    fail "no usable image at $IMAGE"
  fi
else
  fail "unknown --method $METHOD"
fi

# ---- open standalone, check, stop -----------------------------------------
echo "port = $SCRATCH_PORT" >> "$SCRATCH/postgresql.auto.conf"
rm -f "$SCRATCH/standby.signal" "$SCRATCH/recovery.signal"
chmod 700 "$SCRATCH"

log "starting scratch instance"
"$PGBIN/pg_ctl" -D "$SCRATCH" -o "-p $SCRATCH_PORT" -w -t 120 start >>"$REPORT" 2>&1 \
  || fail "scratch instance did not start (corrupt/incomplete backup?)"

PSQL="$PGBIN/psql -p $SCRATCH_PORT -d postgres -tAX"
log "version + connectivity"
$PSQL -c "SELECT version();" >>"$REPORT" 2>&1 || fail "cannot query restored instance"

log "row-count sanity (top tables)"
$PSQL -c "SELECT schemaname||'.'||relname, n_live_tup
          FROM pg_stat_user_tables ORDER BY n_live_tup DESC LIMIT 20;" >>"$REPORT" 2>&1 || true

if [ -x "$PGBIN/pg_amcheck" ]; then
  log "pg_amcheck heap + index verification"
  if "$PGBIN/pg_amcheck" -p "$SCRATCH_PORT" -d postgres --heapallindexed >>"$REPORT" 2>&1; then
    log "pg_amcheck: clean"
  else
    fail "pg_amcheck reported corruption"
  fi
fi

log "=== restore VERIFIED OK ==="
finish
trap - EXIT
exit 0
