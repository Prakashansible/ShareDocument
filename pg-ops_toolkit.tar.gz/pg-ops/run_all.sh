#!/usr/bin/env bash
# ============================================================================
# run_all.sh - run the read-only pg-ops checks in sequence and write ONE
# combined morning report. Intended for a single daily cron entry.
#
# Included (all read-only): slow-query triage, replication watchdog,
# log classifier, bloat advisor. NOT included: backup verification (it restores)
# and the parameter reviewer (on-demand, needs a proposed file).
#
# Each sub-check still writes its own detailed report to $PGOPS_OUT; this script
# pulls the FINDINGS out of each and stacks them, with a summary table on top.
#
# Exit code = worst of the checks (0 OK, 1 WARN, 2 CRIT). A check that fails to
# run at all is reported as ERROR and forces CRIT so it can't fail silently.
#
# Usage:
#   ./run_all.sh                     # print the full combined report (cron mails it)
#   ./run_all.sh --since-hours 12    # narrower log window
#   ./run_all.sh --quiet             # print only the OVERALL line (report still written)
# ============================================================================
set -uo pipefail   # deliberately NOT -e: one non-zero check must not stop the rest

CONF="${PGOPS_HOME:-/apps/pg-ops}/etc/pg-ops.conf"
[ -f "$CONF" ] && . "$CONF"
HOME_DIR="${PGOPS_HOME:-/apps/pg-ops}"
OUT="${PGOPS_OUT:-/apps/logs/pg-ops}"
mkdir -p "$OUT"

SINCE_HOURS=24
QUIET=0
while [ $# -gt 0 ]; do
  case "$1" in
    --since-hours) SINCE_HOURS="$2"; shift 2;;
    --quiet) QUIET=1; shift;;
    *) shift;;
  esac
done

TS="$(date -u +%Y%m%d_%H%M%S)"
REPORT="$OUT/morning_${TS}.txt"
BAR="=============================================================================="
DASH="------------------------------------------------------------------------------"

worst=0
SUM_NAME=(); SUM_SEV=(); SUM_PATH=()
DETAILS=""

# Pull just the FINDINGS block out of a tool report: everything from the
# "FINDINGS" header down to (but not including) the next section heading.
extract_findings(){
  awk '
    /^FINDINGS$/ { found=1 }
    {
      if (found && $0 ~ /^-+$/ && length($0) >= 10) { d++; if (d==2){ trimmed=1; exit } }
      if (found) buf[++n]=$0
    }
    END {
      end = trimmed ? n-2 : n
      if (end < 1) end = n
      for (i=1; i<=end; i++) print buf[i]
    }' "$1"
}

sev_to_ec(){ case "$1" in CRIT) echo 2;; WARN) echo 1;; *) echo 0;; esac; }

run_one(){                       # $1 display-name  $2.. command (--quiet appended)
  local name="$1"; shift
  local line ec sev path err ec2
  err="$(mktemp)"
  line="$("$@" --quiet 2>"$err")"; ec=$?
  path="$(printf '%s\n' "$line" | sed -n 's/.*(\(.*\)).*/\1/p')"
  sev="$(printf '%s\n'  "$line" | sed -n 's/^RESULT: *\([A-Z]*\).*/\1/p')"

  if [ -z "$sev" ] || [ ! -f "${path:-/nonexistent}" ]; then
    SUM_NAME+=("$name"); SUM_SEV+=("ERROR"); SUM_PATH+=("(no report - see detail)")
    DETAILS+="${BAR}
DETAIL: ${name}  [ERROR - check did not complete]
${BAR}
$(tail -n 15 "$err")

"
    worst=2
  else
    SUM_NAME+=("$name"); SUM_SEV+=("$sev"); SUM_PATH+=("$path")
    DETAILS+="${BAR}
DETAIL: ${name}  [${sev}]
${BAR}
$(extract_findings "$path")

"
    ec2="$(sev_to_ec "$sev")"; [ "$ec2" -gt "$worst" ] && worst="$ec2"
  fi
  rm -f "$err"
}

# ---- the read-only checks, in order ---------------------------------------
run_one "slow-query triage"    "$HOME_DIR/01_slow_query_triage/slow_query_triage.py" --top 20
run_one "replication watchdog" "$HOME_DIR/02_replication_watchdog/replication_watchdog.py"
run_one "log classifier"       "$HOME_DIR/03_log_classifier/log_classifier.py" --since-hours "$SINCE_HOURS"
run_one "bloat advisor"        "$HOME_DIR/04_bloat_advisor/bloat_advisor.py" --top 25

case "$worst" in 2) OVERALL=CRIT;; 1) OVERALL=WARN;; *) OVERALL=OK;; esac

# ---- assemble the combined report -----------------------------------------
{
  echo "$BAR"
  echo "pg-ops morning report"
  echo "$BAR"
  echo "host: $(hostname)   time: $(date -u +'%Y-%m-%d %H:%M:%S')Z"
  echo "OVERALL: ${OVERALL}   (worst of ${#SUM_NAME[@]} checks)"
  echo
  echo "SUMMARY"
  echo "$DASH"
  printf "  %-22s  %-6s  %s\n" "check" "result" "report"
  printf "  %-22s  %-6s  %s\n" "----------------------" "------" "----------------------------------------"
  for i in "${!SUM_NAME[@]}"; do
    printf "  %-22s  %-6s  %s\n" "${SUM_NAME[$i]}" "${SUM_SEV[$i]}" "${SUM_PATH[$i]}"
  done
  echo
  printf '%s\n' "$DETAILS"
} > "$REPORT"

ln -sfn "$REPORT" "$OUT/morning_latest.txt" 2>/dev/null || true

if [ "$QUIET" = "1" ]; then
  echo "OVERALL: ${OVERALL}  (${REPORT})"
else
  cat "$REPORT"
fi
exit "$worst"
