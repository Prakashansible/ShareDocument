-- vacuum_stats.sql : dead-tuple pressure + autovacuum history per table.
-- Native only (no pgstattuple required). :n substituted by the script.
SELECT coalesce(json_agg(t), '[]')
FROM (
    SELECT
        schemaname || '.' || relname                   AS tbl,
        n_live_tup                                     AS live,
        n_dead_tup                                     AS dead,
        round(100.0 * n_dead_tup
              / nullif(n_live_tup + n_dead_tup, 0), 1) AS dead_pct,
        n_mod_since_analyze                            AS mod_since_analyze,
        pg_relation_size(relid)                        AS heap_bytes,
        pg_size_pretty(pg_total_relation_size(relid))  AS total_size,
        coalesce(to_char(last_autovacuum,  'YYYY-MM-DD HH24:MI'), 'never') AS last_autovac,
        coalesce(to_char(last_autoanalyze, 'YYYY-MM-DD HH24:MI'), 'never') AS last_autoanalyze,
        autovacuum_count, autoanalyze_count
    FROM pg_stat_user_tables
    ORDER BY n_dead_tup DESC
    LIMIT :n
) t;
