#!/usr/bin/env python3
"""
bloat_advisor.py - dead-tuple / autovacuum advisor, standalone.

Collects dead-tuple pressure + autovacuum history, then applies deterministic
rules to emit ready-to-run commands:
  * manual VACUUM (ANALYZE) for tables over the dead-tuple % threshold;
  * PER-TABLE autovacuum settings for large tables, computed from row count so
    the fixed 0.2 scale_factor doesn't let big tables bloat between runs;
  * flags for tables never autovacuumed/analyzed.

Why per-table scale_factor: autovacuum fires when
    dead_tuples > autovacuum_vacuum_threshold + scale_factor * n_live_tup.
At the default scale_factor 0.2, a 50M-row table must accumulate ~10M dead rows
before it is touched. Lowering scale_factor per-table (below) makes it fire far
sooner without disturbing small tables or global GUCs.

Exit 0/1/2 by worst finding.

Usage:
  ./bloat_advisor.py --top 25
  ./bloat_advisor.py --top 25 --pgstattuple   # precise bloat on worst 5 (heavier)
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
from pgcommon import (run_sql_json, scalar, Report,   # noqa: E402
                      OK, INFO, WARN, CRIT)

HERE = os.path.dirname(os.path.abspath(__file__))
MB = 1048576


def num(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def recommend_autovacuum(live):
    """Return (scale_factor, threshold, cost_limit) for a table's live rows,
    or None if the default 0.2 is fine (small tables)."""
    if live >= 50_000_000:
        return (0.01, 50000, 2000)
    if live >= 5_000_000:
        return (0.02, 20000, 1500)
    if live >= 500_000:
        return (0.05, 10000, None)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=25)
    ap.add_argument("--dead-warn-pct", type=float, default=20.0)
    ap.add_argument("--dead-crit-pct", type=float, default=40.0)
    ap.add_argument("--min-dead", type=int, default=1000)
    ap.add_argument("--pgstattuple", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    sql = open(os.path.join(HERE, "vacuum_stats.sql")).read().replace(":n", str(args.top))
    tables = run_sql_json(sql)
    rep = Report("PostgreSQL bloat & autovacuum advisor (top %d)" % args.top)
    if not tables:
        rep.finding(OK, "No user tables found")
        return rep.emit("bloat", args.quiet)

    # trim the display to tables with real dead tuples
    shown = [t for t in tables if num(t.get("dead")) >= args.min_dead]
    rep.table("Dead-tuple pressure & autovacuum history", shown or tables[:10],
              cols=["tbl", "live", "dead", "dead_pct", "total_size",
                    "last_autovac", "last_autoanalyze"])

    vacuum_cmds, autovac_cmds = [], []
    for t in tables:
        tbl = t.get("tbl")
        live = num(t.get("live")); dead = num(t.get("dead"))
        dead_pct = num(t.get("dead_pct"))
        heap = num(t.get("heap_bytes"))

        # never maintained
        if t.get("last_autovac") == "never" and dead >= args.min_dead:
            rep.finding(WARN, "%s has NEVER been autovacuumed (dead=%d)" % (tbl, int(dead)),
                        "Autovacuum may be disabled or never reached its threshold.",
                        "VACUUM (VERBOSE, ANALYZE) %s;" % tbl)

        # dead-tuple pressure
        if dead >= args.min_dead and dead_pct >= args.dead_crit_pct:
            rep.finding(CRIT, "%s is %.0f%% dead tuples" % (tbl, dead_pct),
                        "Heavy bloat; index scans and disk footprint suffer.")
            vacuum_cmds.append("VACUUM (VERBOSE, ANALYZE) %s;   -- %.0f%% dead" % (tbl, dead_pct))
            if heap > 512 * MB:
                rep.finding(INFO, "%s bloat may need a rewrite" % tbl,
                            "If plain VACUUM does not reclaim enough, a rewrite will.\n"
                            "VACUUM FULL takes ACCESS EXCLUSIVE (blocks all access);\n"
                            "schedule it in a window, or use an online reorg approach.",
                            "-- during a maintenance window only:\n"
                            "VACUUM FULL %s;" % tbl)
        elif dead >= args.min_dead and dead_pct >= args.dead_warn_pct:
            rep.finding(WARN, "%s is %.0f%% dead tuples" % (tbl, dead_pct))
            vacuum_cmds.append("VACUUM (ANALYZE) %s;   -- %.0f%% dead" % (tbl, dead_pct))

        # per-table autovacuum tuning for large tables
        rec = recommend_autovacuum(live)
        if rec:
            sf, thr, cost = rec
            opts = ["autovacuum_vacuum_scale_factor = %s" % sf,
                    "autovacuum_vacuum_threshold = %d" % thr,
                    "autovacuum_analyze_scale_factor = %s" % sf]
            if cost:
                opts.append("autovacuum_vacuum_cost_limit = %d" % cost)
            autovac_cmds.append(
                "ALTER TABLE %s SET (\n    %s\n);" % (tbl, ",\n    ".join(opts)))

    if vacuum_cmds:
        rep.block("Recommended VACUUM commands (run now, low lock)",
                  "\n".join(vacuum_cmds))
    if autovac_cmds:
        rep.block("Recommended per-table autovacuum tuning (large tables)",
                  "\n\n".join(autovac_cmds))
        rep.finding(INFO, "%d large table(s) would benefit from per-table autovacuum"
                    % len(autovac_cmds),
                    "Applying scale_factor per-table (above) makes autovacuum keep up\n"
                    "without touching global GUCs.")

    # optional precise bloat
    if args.pgstattuple:
        has = scalar("SELECT count(*) FROM pg_extension WHERE extname='pgstattuple';")
        if has and int(has) > 0:
            rows = []
            for t in tables[:5]:
                try:
                    r = run_sql_json(
                        "SELECT coalesce(json_agg(s),'[]') FROM (SELECT "
                        "round(dead_tuple_percent,1) AS dead_pct, "
                        "pg_size_pretty(dead_tuple_len) AS dead_size, "
                        "round(free_percent,1) AS free_pct "
                        "FROM pgstattuple('%s')) s;" % t["tbl"])
                    if r:
                        r[0]["tbl"] = t["tbl"]; rows.append(r[0])
                except Exception:
                    pass
            if rows:
                rep.table("pgstattuple precise bloat (worst 5)", rows,
                          cols=["tbl", "dead_pct", "dead_size", "free_pct"])
        else:
            rep.finding(INFO, "pgstattuple not installed; skipped precise bloat",
                        "", "CREATE EXTENSION pgstattuple;")

    if not any(f.severity in (WARN, CRIT) for f in rep.findings):
        rep.finding(OK, "No table crossed the bloat thresholds")
    return rep.emit("bloat", args.quiet)


if __name__ == "__main__":
    sys.exit(main())
