#!/usr/bin/env python3
"""
param_safety_reviewer.py - review a proposed postgresql.conf change, standalone.

Feed it a file of 'name = value' lines. It reads live values + each parameter's
apply context, validates ranges, detects this node's role, and emits a concrete,
safe rollout plan plus a rollback plan - all as ready-to-run SQL. It enforces
your two hard rules by construction.

Usage:
  ./param_safety_reviewer.py --proposed change.conf
  # change.conf:
  #   max_connections = 500
  #   work_mem = 32MB
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
from pgcommon import (run_sql_json, scalar, Report,   # noqa: E402
                      OK, INFO, WARN, CRIT)

REPL_SENSITIVE = ["max_connections", "max_worker_processes", "max_wal_senders",
                  "max_prepared_transactions", "max_locks_per_transaction"]
PRIMARY = os.environ.get("PGOPS_PRIMARY", "db01")
STANDBY = os.environ.get("PGOPS_STANDBY", "db02")

# memory-ish params whose values may carry a unit
_UNIT_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([kKmMgGtT][bB]?)?\s*$")


def parse_proposed(path):
    out = {}
    for line in open(path):
        line = line.split("#", 1)[0].strip()
        m = re.match(r"^([a-zA-Z_.]+)\s*=\s*(.+?)\s*$", line)
        if m:
            out[m.group(1).lower()] = m.group(2).strip().strip("'\"")
    return out


def apply_commands(name, value, context):
    """Return (apply_text, needs_restart:bool)."""
    setline = "ALTER SYSTEM SET %s = '%s';" % (name, value)
    if context == "postmaster":
        return (setline + "\n-- then RESTART PostgreSQL (postmaster-context change)", True)
    if context in ("sighup", "superuser-backend", "backend"):
        return (setline + "\nSELECT pg_reload_conf();   -- reload, no restart", False)
    if context in ("user", "superuser"):
        return (setline + "\nSELECT pg_reload_conf();   -- or SET per-session", False)
    if context == "internal":
        return ("-- '%s' is compile-time internal and cannot be changed at runtime" % name, False)
    return (setline, False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--proposed", required=True)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    proposed = parse_proposed(args.proposed)
    if not proposed:
        print("No parameters parsed from", args.proposed); return 1

    standby = scalar("SELECT pg_is_in_recovery();") == "t"
    role = "STANDBY (in recovery)" if standby else "PRIMARY"
    rep = Report("PostgreSQL parameter change safety review", role=role)

    names = ",".join("'%s'" % n for n in proposed)
    live = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT name, setting, unit, context, vartype,
               min_val, max_val, boot_val, pending_restart
        FROM pg_settings WHERE name IN (%s)) t;""" % names)
    live_map = {r["name"]: r for r in live}

    diff_rows, restart_needed, sensitive_hit, rollback = [], [], [], []
    for name, newval in proposed.items():
        cur = live_map.get(name)
        if not cur:
            rep.finding(WARN, "unknown parameter '%s'" % name,
                        "Not present in pg_settings; check spelling / version.")
            continue
        context = cur.get("context", "")
        diff_rows.append({"parameter": name, "current": cur.get("setting"),
                          "proposed": newval, "context": context,
                          "unit": cur.get("unit") or "",
                          "repl_sensitive": "YES" if name in REPL_SENSITIVE else ""})
        # range validation for plain numerics (no unit)
        if cur.get("vartype") in ("integer", "real"):
            m = _UNIT_RE.match(newval)
            if m and not m.group(2):
                try:
                    v = float(m.group(1)); lo = float(cur["min_val"]); hi = float(cur["max_val"])
                    if v < lo or v > hi:
                        rep.finding(CRIT, "'%s' value %s out of range [%s..%s]"
                                    % (name, newval, cur["min_val"], cur["max_val"]),
                                    "PostgreSQL will reject this at apply time.")
                except (ValueError, KeyError):
                    pass

        apply_text, needs_restart = apply_commands(name, newval, context)
        if needs_restart:
            restart_needed.append(name)
        if name in REPL_SENSITIVE:
            sensitive_hit.append(name)
        # rollback
        rollback.append("ALTER SYSTEM SET %s = '%s';   -- was" % (name, cur.get("setting")))

        rep.finding(INFO if not needs_restart else WARN,
                    "%s: %s -> %s (%s)" % (name, cur.get("setting"), newval,
                                           "RESTART" if needs_restart else "reload"),
                    "apply context: %s" % context, apply_text)

    rep.table("Proposed changes vs live", diff_rows,
              cols=["parameter", "current", "proposed", "unit", "context", "repl_sensitive"])

    # ---- ordered rollout plan --------------------------------------------
    plan = []
    if sensitive_hit:
        plan.append("Replication-sensitive parameters detected: %s"
                    % ", ".join(sensitive_hit))
        plan.append("")
        plan.append("STANDBY-FIRST sequence (mandatory):")
        plan.append("  1. On the STANDBY (%s): apply the change and restart." % STANDBY)
        plan.append("     - the standby's value must be >= the primary's for these")
        plan.append("       params, or recovery refuses to start.")
        plan.append("  2. Confirm streaming resumed:")
        plan.append("       SELECT status FROM pg_stat_wal_receiver;   -- on standby")
        plan.append("       SELECT * FROM pg_stat_replication;         -- on primary")
        plan.append("  3. Only then apply + restart the PRIMARY (%s)." % PRIMARY)
        plan.append("")
    if restart_needed:
        plan.append("Requires a full restart (postmaster context): %s"
                    % ", ".join(restart_needed))
    else:
        plan.append("All changes apply with a reload (pg_reload_conf); no restart.")
    rep.block("Rollout plan", "\n".join(plan))

    # ---- standby guard ----------------------------------------------------
    if standby:
        rep.finding(WARN, "This node is a STANDBY - RESET ALL is forbidden here",
                    "ALTER SYSTEM RESET ALL wipes primary_conninfo from "
                    "postgresql.auto.conf and breaks replication.",
                    "To undo a single parameter on a standby use only:\n"
                    "ALTER SYSTEM RESET <param>;   SELECT pg_reload_conf();")

    rep.block("Rollback plan (revert to current values)",
              "\n".join(rollback) + "\nSELECT pg_reload_conf();\n"
              "-- (restart instead if a postmaster-context param was changed)")

    # ---- go / no-go -------------------------------------------------------
    if any(f.severity == CRIT for f in rep.findings):
        rep.finding(CRIT, "NO-GO: fix the flagged issues before applying")
    else:
        rep.finding(OK, "GO: plan is safe if the standby-first sequence is followed"
                    if sensitive_hit else "GO: low-risk change")
    return rep.emit("paramreview", args.quiet)


if __name__ == "__main__":
    sys.exit(main())
