-- top_statements.sql : top-N statements by total execution time.
-- Needs pg_stat_statements (shared_preload_libraries + CREATE EXTENSION).
-- :n is substituted by the script.
SELECT coalesce(json_agg(t), '[]')
FROM (
    SELECT
        queryid::text                              AS queryid,
        round(total_exec_time::numeric, 1)         AS total_ms,
        calls,
        round(mean_exec_time::numeric, 2)          AS mean_ms,
        round(stddev_exec_time::numeric, 2)        AS stddev_ms,
        rows,
        round((100.0 * total_exec_time
               / nullif(sum(total_exec_time) OVER (), 0))::numeric, 1) AS pct_total,
        round(shared_blks_hit
              / nullif(shared_blks_hit + shared_blks_read, 0)::numeric * 100, 1) AS cache_hit_pct,
        left(regexp_replace(query, '\s+', ' ', 'g'), 400) AS query
    FROM pg_stat_statements
    WHERE query !~* '^\s*(SET|SHOW|COMMIT|BEGIN|ROLLBACK|DEALLOCATE|RESET)'
    ORDER BY total_exec_time DESC
    LIMIT :n
) t;
