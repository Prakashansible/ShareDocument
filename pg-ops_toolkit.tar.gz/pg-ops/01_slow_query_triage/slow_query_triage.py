#!/usr/bin/env python3
"""
slow_query_triage.py - rank pg_stat_statements and triage with built-in rules.

Standalone: it collects, applies deterministic DBA heuristics, and writes a
report with findings + recommended actions. No external services.

Heuristics:
  * a statement using >= --pct-crit % of total time         -> WARN/CRIT (hot spot)
  * mean latency >= --mean-warn-ms                           -> WARN (slow)
  * cache_hit_pct < --cache-warn and calls significant       -> WARN (I/O bound)
  * stddev > mean (coefficient of variation > 1)             -> INFO (unstable plan)
  * user tables with seq_scan >> idx_scan and size > 50 MB   -> WARN (missing index?)
  * indexes never used (idx_scan = 0) on non-tiny tables     -> INFO (drop candidate)

Exit code: 0 OK/INFO, 1 WARN, 2 CRIT.

Usage:
  ./slow_query_triage.py --top 20
  ./slow_query_triage.py --top 20 --explain     # attach a plain EXPLAIN per hot stmt
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
from pgcommon import (run_sql, run_sql_json, Report,   # noqa: E402
                      OK, INFO, WARN, CRIT)

HERE = os.path.dirname(os.path.abspath(__file__))


def num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def explain_for(query):
    q = query.strip().rstrip(";")
    if not q.lower().startswith(("select", "with", "update", "delete", "insert")):
        return "(skipped: not analysable)"
    try:
        rows = run_sql("EXPLAIN (FORMAT TEXT) " + q)
        return "\n".join(r.get("QUERY PLAN", "") for r in rows) or "(empty plan)"
    except Exception as e:
        return "(EXPLAIN failed: %s)" % e


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("--explain", action="store_true")
    ap.add_argument("--pct-crit", type=float, default=40.0)
    ap.add_argument("--pct-warn", type=float, default=20.0)
    ap.add_argument("--mean-warn-ms", type=float, default=1000.0)
    ap.add_argument("--cache-warn", type=float, default=90.0)
    ap.add_argument("--min-calls", type=int, default=50)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    rep = Report("PostgreSQL slow-query triage (top %d)" % args.top)

    # is the extension actually there?
    have = run_sql_json(
        "SELECT coalesce(json_agg(t),'[]') FROM "
        "(SELECT 1 FROM pg_extension WHERE extname='pg_stat_statements') t;")
    if not have:
        rep.finding(CRIT, "pg_stat_statements not installed in this database",
                    "Cannot triage statements without it.",
                    "ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';\n"
                    "-- restart required (postmaster context), then:\n"
                    "CREATE EXTENSION pg_stat_statements;")
        return rep.emit("slowquery", args.quiet)

    sql = open(os.path.join(HERE, "top_statements.sql")).read().replace(":n", str(args.top))
    stmts = run_sql_json(sql)
    if not stmts:
        rep.finding(INFO, "No statements recorded yet",
                    "pg_stat_statements is empty (recently reset or idle instance).")
        return rep.emit("slowquery", args.quiet)

    rep.table("Top statements by total time", stmts,
              cols=["pct_total", "total_ms", "calls", "mean_ms", "stddev_ms",
                    "rows", "cache_hit_pct", "query"])

    # ---- per-statement rules ---------------------------------------------
    for s in stmts:
        pct = num(s.get("pct_total"))
        mean = num(s.get("mean_ms"))
        stddev = num(s.get("stddev_ms"))
        calls = num(s.get("calls"))
        cache = num(s.get("cache_hit_pct"), 100.0)
        qid = s.get("queryid")
        qtext = (s.get("query") or "")[:120]

        if pct >= args.pct_crit:
            rep.finding(CRIT, "queryid %s consumes %.0f%% of total exec time" % (qid, pct),
                        "%s ...\ncalls=%s mean=%sms" % (qtext, s.get("calls"), s.get("mean_ms")),
                        "Capture a full plan under load and tune first:\n"
                        "EXPLAIN (ANALYZE, BUFFERS) <the statement>;")
        elif pct >= args.pct_warn:
            rep.finding(WARN, "queryid %s consumes %.0f%% of total exec time" % (qid, pct),
                        "%s ..." % qtext)

        if mean >= args.mean_warn_ms and calls >= 1:
            rep.finding(WARN, "queryid %s slow mean latency %.0f ms" % (qid, mean),
                        "%s ..." % qtext)

        if cache < args.cache_warn and calls >= args.min_calls:
            rep.finding(WARN, "queryid %s low cache hit %.1f%% (I/O bound)" % (qid, cache),
                        "%s ...\nRepeated physical reads - check indexes or shared_buffers." % qtext)

        if mean > 0 and stddev > mean and calls >= args.min_calls:
            rep.finding(INFO, "queryid %s has an unstable plan (stddev > mean)" % qid,
                        "mean=%.0fms stddev=%.0fms - parameter-sensitive or plan flips."
                        % (mean, stddev))

    # ---- table / index structural rules ----------------------------------
    tbl = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT schemaname||'.'||relname AS tbl, seq_scan, idx_scan,
               pg_relation_size(relid) AS bytes,
               pg_size_pretty(pg_relation_size(relid)) AS size
        FROM pg_stat_user_tables
        ORDER BY seq_scan DESC LIMIT 25) t;""")
    seq_heavy = []
    for t in tbl:
        seq = num(t.get("seq_scan")); idx = num(t.get("idx_scan"))
        big = num(t.get("bytes")) > 50 * 1048576
        if big and seq > 1000 and seq > (idx * 5 + 1):
            seq_heavy.append(t)
    if seq_heavy:
        rep.table("Sequential-scan-heavy tables (>50MB)", seq_heavy,
                  cols=["tbl", "seq_scan", "idx_scan", "size"])
        rep.finding(WARN, "%d large table(s) served mostly by sequential scans"
                    % len(seq_heavy),
                    "Tables: " + ", ".join(t["tbl"] for t in seq_heavy),
                    "Review WHERE/JOIN predicates against these tables and add\n"
                    "covering indexes. Create them without blocking writes:\n"
                    "CREATE INDEX CONCURRENTLY ix_<tbl>_<cols> ON <tbl> (<cols>);")

    unused = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT schemaname||'.'||relname AS tbl, indexrelname AS index,
               pg_size_pretty(pg_relation_size(indexrelid)) AS size
        FROM pg_stat_user_indexes
        WHERE idx_scan = 0
          AND pg_relation_size(indexrelid) > 1048576
          AND indexrelid NOT IN (SELECT conindid FROM pg_constraint WHERE contype IN ('p','u'))
        ORDER BY pg_relation_size(indexrelid) DESC LIMIT 20) t;""")
    if unused:
        rep.table("Unused indexes (idx_scan=0, >1MB, non-constraint)", unused,
                  cols=["tbl", "index", "size"])
        rep.finding(INFO, "%d unused index(es) taking space and slowing writes"
                    % len(unused),
                    "These have never been scanned since stats were reset.",
                    "Confirm over a full business cycle, then:\n"
                    "DROP INDEX CONCURRENTLY <schema>.<index>;")

    # ---- optional plans for the hottest statements -----------------------
    if args.explain:
        for s in stmts[:5]:
            rep.block("EXPLAIN queryid %s (%.0f%% total)"
                      % (s.get("queryid"), num(s.get("pct_total"))),
                      explain_for(s.get("query") or ""))

    if not any(f.severity in (WARN, CRIT) for f in rep.findings):
        rep.finding(OK, "No slow-query hotspots crossed the thresholds")

    return rep.emit("slowquery", args.quiet)


if __name__ == "__main__":
    sys.exit(main())
