#!/usr/bin/env python3
"""
log_classifier.py - classify + trend PostgreSQL log events, standalone.

Dependency-free. Reads stderr or csvlog from /apps/logs, buckets events into
pattern classes, trends per hour, and turns each class into a rule-based finding
with concrete remediation. Exit 0/1/2 by worst finding.

Usage:
  ./log_classifier.py --since-hours 24
  ./log_classifier.py --glob 'postgresql-*.csv' --since-hours 12
"""
import argparse
import csv
import glob
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
from pgcommon import Report, OK, INFO, WARN, CRIT   # noqa: E402

PATTERNS = [
    ("deadlock",          re.compile(r"deadlock detected", re.I)),
    ("lock_timeout",      re.compile(r"canceling statement due to lock timeout", re.I)),
    ("statement_timeout", re.compile(r"canceling statement due to statement timeout", re.I)),
    ("auth_failure",      re.compile(r"password authentication failed|no pg_hba\.conf entry", re.I)),
    ("too_many_conns",    re.compile(r"too many clients|remaining connection slots", re.I)),
    ("checkpoint_freq",   re.compile(r"checkpoints are occurring too frequently", re.I)),
    ("disk_space",        re.compile(r"could not write|no space left|disk full", re.I)),
    ("wal_archive_fail",  re.compile(r"archive command failed|archiving .* failed", re.I)),
    ("replication",       re.compile(r"walreceiver|replication slot|streaming replication|primary_conninfo", re.I)),
    ("corruption",        re.compile(r"invalid page|checksum|could not read block|missing chunk", re.I)),
    ("oom_canceled",      re.compile(r"out of memory|terminating connection due to", re.I)),
]
SEV = re.compile(r"\b(WARNING|ERROR|FATAL|PANIC)\b")
LOG_KEEP = re.compile(
    r"checkpoints are occurring too frequently|archive command failed|"
    r"archiving .* failed|out of memory", re.I)
TS = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})")

# class -> (severity, headline, remediation)
RULES = {
    "corruption":      (CRIT, "Possible data corruption in the logs",
                        "Do NOT ignore. Identify the relation from the message, run\n"
                        "pg_amcheck on it, and restore/rebuild from a good backup or\n"
                        "the standby. Investigate storage/hardware."),
    "disk_space":      (CRIT, "Out-of-space / write failures",
                        "Free space on the data or WAL filesystem immediately; check\n"
                        "for an inactive replication slot pinning WAL under\n"
                        "/apps/pgsql_data and archiver backlog in /apps/pgsql_archives."),
    "oom_canceled":    (CRIT, "Out-of-memory / abnormal termination",
                        "Check work_mem x concurrency and the OOM killer (dmesg).\n"
                        "Lower work_mem or add a connection pooler."),
    "wal_archive_fail":(CRIT, "WAL archiving is failing",
                        "archive_command is erroring; WAL will accumulate in pg_wal.\n"
                        "Fix the archive target/permissions in /apps/pgsql_archives\n"
                        "before the data filesystem fills."),
    "too_many_conns":  (WARN, "Connection slots exhausted",
                        "Add a pooler (pgbouncer) or raise max_connections.\n"
                        "Raising max_connections is replication-sensitive: apply it\n"
                        "STANDBY-FIRST, then the primary."),
    "checkpoint_freq": (WARN, "Checkpoints occurring too frequently",
                        "Raise max_wal_size (reload, SIGHUP - safe on both nodes):\n"
                        "ALTER SYSTEM SET max_wal_size = '4GB'; SELECT pg_reload_conf();"),
    "deadlock":        (WARN, "Deadlocks detected",
                        "Enable log_lock_waits, identify the two statements, and make\n"
                        "them acquire locks in a consistent order (or shorten txns)."),
    "auth_failure":    (WARN, "Authentication failures",
                        "If the failing user is 'replicator', fix pg_hba.conf on the\n"
                        "primary (a 'replication' line for the standby host) - this is\n"
                        "the pattern behind a standby that stops streaming. Otherwise\n"
                        "check app credentials / possible brute force by source IP."),
    "lock_timeout":    (INFO, "Statements cancelled by lock_timeout", ""),
    "statement_timeout":(INFO, "Statements cancelled by statement_timeout", ""),
    "replication":     (INFO, "Replication-related log activity",
                        "Correlate with the replication watchdog output."),
}


def classify(msg):
    for name, rx in PATTERNS:
        if rx.search(msg):
            return name
    return "other"


def parse_stderr(path, since):
    for line in open(path, errors="replace"):
        m = SEV.search(line)
        sev = m.group(1) if m else ("LOG" if LOG_KEEP.search(line) else None)
        if not sev:
            continue
        ts = None
        tm = TS.match(line)
        if tm:
            try:
                ts = datetime.strptime(tm.group(1), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
        if since and ts and ts < since:
            continue
        yield ts, sev, line.strip()


def parse_csv(path, since):
    with open(path, errors="replace", newline="") as f:
        for row in csv.reader(f):
            if len(row) < 14:
                continue
            sev, msg = row[11], row[13]
            if sev not in ("WARNING", "ERROR", "FATAL", "PANIC") and not LOG_KEEP.search(msg):
                continue
            ts = None
            try:
                ts = datetime.strptime(row[0][:19], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
            if since and ts and ts < since:
                continue
            yield ts, sev, msg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logdir", default=os.environ.get("PG_LOGDIR", "/apps/logs"))
    ap.add_argument("--glob", default="*.log")
    ap.add_argument("--since-hours", type=int, default=24)
    ap.add_argument("--deadlock-warn", type=int, default=5)
    ap.add_argument("--auth-warn", type=int, default=10)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    since = datetime.now() - timedelta(hours=args.since_hours)
    files = sorted(glob.glob(os.path.join(args.logdir, args.glob)))
    rep = Report("PostgreSQL log analysis (last %dh)" % args.since_hours)
    if not files:
        rep.finding(WARN, "No log files matched",
                    "glob '%s' in %s returned nothing." % (args.glob, args.logdir))
        return rep.emit("logs", args.quiet)

    by_class = Counter(); by_sev = Counter(); by_hour = defaultdict(Counter)
    samples = defaultdict(list)
    for path in files:
        parser = parse_csv if path.endswith(".csv") else parse_stderr
        for ts, sev, msg in parser(path, since):
            cls = classify(msg)
            by_class[cls] += 1
            by_sev[sev] += 1
            if ts:
                by_hour[ts.strftime("%Y-%m-%d %H:00")][cls] += 1
            if len(samples[cls]) < 3:
                samples[cls].append(msg[:240])

    rep.table("Severity totals",
              [{"severity": k, "count": v} for k, v in by_sev.most_common()])
    rep.table("Event classes",
              [{"class": c, "count": n} for c, n in by_class.most_common()])

    top = [c for c, _ in by_class.most_common(4) if c != "other"]
    trend = []
    for hour in sorted(by_hour)[-24:]:
        row = {"hour": hour}
        row.update({c: by_hour[hour].get(c, 0) for c in top})
        trend.append(row)
    if trend:
        rep.table("Hourly trend (top classes)", trend)

    # ---- rule-based findings ---------------------------------------------
    if by_sev.get("PANIC"):
        rep.finding(CRIT, "PANIC entries present (%d)" % by_sev["PANIC"],
                    "A PANIC crashes/restarts the postmaster.",
                    "Read the surrounding log lines in %s immediately." % args.logdir)
    for cls, count in by_class.most_common():
        if cls == "other" or cls not in RULES:
            continue
        sev, head, action = RULES[cls]
        # escalate volume-sensitive classes
        if cls == "deadlock" and count >= args.deadlock_warn:
            sev = WARN
        if cls == "auth_failure" and count >= args.auth_warn:
            sev = WARN
        rep.finding(sev, "%s (%d occurrences)" % (head, count),
                    "\n".join(samples[cls]), action)

    if not any(f.severity in (WARN, CRIT) for f in rep.findings):
        rep.finding(OK, "No error patterns crossed alert thresholds")
    return rep.emit("logs", args.quiet)


if __name__ == "__main__":
    sys.exit(main())
