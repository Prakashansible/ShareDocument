#!/usr/bin/env bash
# setup.sh - install the toolkit under /apps/pg-ops on an AlmaLinux 9 host.
set -euo pipefail
DEST="${1:-/apps/pg-ops}"
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "Installing pg-ops toolkit -> $DEST"
mkdir -p "$DEST" "${PGOPS_OUT:-/apps/logs/pg-ops}"
cp -a "$SRC/." "$DEST/"
[ -f "$DEST/etc/pg-ops.conf" ] || cp "$SRC/etc/pg-ops.conf" "$DEST/etc/pg-ops.conf"
chmod 600 "$DEST/etc/pg-ops.conf"
chmod +x "$DEST"/0*/*.py "$DEST"/0*/*.sh "$DEST"/lib/*.py 2>/dev/null || true

echo
echo "Next:"
echo "  1. Edit $DEST/etc/pg-ops.conf (PG_VERSION, PGBIN, PGHOST/PGPORT/PGUSER, paths)."
echo "  2. In each DB to triage:  CREATE EXTENSION IF NOT EXISTS pg_stat_statements;"
echo "     (and shared_preload_libraries='pg_stat_statements' in postgresql.conf + restart)"
echo "  3. Smoke test:"
echo "       . $DEST/etc/pg-ops.conf"
echo "       $DEST/02_replication_watchdog/replication_watchdog.py"
echo "  4. Schedule: install $DEST/scheduling/pg-ops.crontab, or the systemd timers."
echo
echo "Reports are written to ${PGOPS_OUT:-/apps/logs/pg-ops}/ (with *_latest.txt symlinks)."
