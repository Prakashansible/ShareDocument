#!/usr/bin/env python3
"""
pgcommon.py - shared helpers for the standalone PostgreSQL ops toolkit.

Pure standard library (works on the Python 3.9 that ships with AlmaLinux 9).
No psycopg2, no third-party modules. Everything talks to the server through the
`psql` binary.

Provides:
  - run_sql / run_sql_json / scalar : query helpers.
  - Severity + Finding                : structured, rule-based findings.
  - Report                            : builds and writes a plain-text report
                                        and returns the exit code (max severity).
"""

import json
import os
import subprocess
import sys
from datetime import datetime, timezone

OUT_DIR = os.environ.get("PGOPS_OUT", "/apps/logs/pg-ops")
PGBIN = os.environ.get("PGBIN", "")


def _psql(*args):
    """Return the psql invocation list, honouring PGBIN and libpq env vars."""
    exe = os.path.join(PGBIN, "psql") if PGBIN else "psql"
    cmd = [exe, "-X", "-v", "ON_ERROR_STOP=1"]
    for flag, env in (("-d", "PGDATABASE"), ("-h", "PGHOST"),
                      ("-p", "PGPORT"), ("-U", "PGUSER")):
        val = os.environ.get(env)
        if val:
            cmd += [flag, str(val)]
    return cmd + list(args)


def run_sql(sql, timeout=60):
    """Run SQL, return list-of-dict rows (pipe-separated, header on)."""
    cmd = _psql("-A", "-F", "|", "--pset", "footer=off", "-c", sql)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError("psql failed: " + p.stderr.strip())
    lines = [l for l in p.stdout.splitlines() if l.strip()]
    if not lines:
        return []
    header = lines[0].split("|")
    return [dict(zip(header, l.split("|"))) for l in lines[1:]]


def run_sql_json(sql, timeout=60):
    """Run a query whose single column is json_agg(...); return a Python list.
    Wrap the inner query as: SELECT coalesce(json_agg(t),'[]') FROM (<q>) t;"""
    cmd = _psql("-A", "-t", "-q", "-c", sql)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError("psql failed: " + p.stderr.strip())
    out = p.stdout.strip()
    return json.loads(out) if out else []


def scalar(sql, timeout=30):
    cmd = _psql("-A", "-t", "-q", "-c", sql)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError("psql failed: " + p.stderr.strip())
    return p.stdout.strip() or None


def server_version_num():
    try:
        return int(scalar("SHOW server_version_num;") or 0)
    except Exception:
        return 0


# --------------------------------------------------------------------------- #
# Findings / severity
# --------------------------------------------------------------------------- #
OK, INFO, WARN, CRIT = "OK", "INFO", "WARN", "CRIT"
_RANK = {OK: 0, INFO: 1, WARN: 2, CRIT: 3}
_EXIT = {OK: 0, INFO: 0, WARN: 1, CRIT: 2}


class Finding:
    """One rule-based conclusion: a severity, a headline, detail, and an
    optional 'action' (a command block the DBA can run)."""
    def __init__(self, severity, title, detail="", action=""):
        self.severity = severity
        self.title = title
        self.detail = detail
        self.action = action


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #
class Report:
    def __init__(self, title, role=None):
        self.title = title
        self.role = role
        self.findings = []
        self.tables = []      # (heading, rows, cols)
        self.blocks = []      # (heading, text)
        self.ts = datetime.now(timezone.utc)

    def add(self, finding):
        self.findings.append(finding)
        return finding

    def finding(self, severity, title, detail="", action=""):
        return self.add(Finding(severity, title, detail, action))

    def table(self, heading, rows, cols=None):
        if rows:
            self.tables.append((heading, rows, cols or list(rows[0].keys())))
        else:
            self.tables.append((heading, [], cols or []))
        return self

    def block(self, heading, text):
        self.blocks.append((heading, text))
        return self

    def worst(self):
        return max((f.severity for f in self.findings), key=lambda s: _RANK[s],
                   default=OK)

    # ---- rendering --------------------------------------------------------
    @staticmethod
    def _fmt_table(rows, cols):
        if not rows:
            return "  (no rows)\n"
        widths = {c: len(str(c)) for c in cols}
        for r in rows:
            for c in cols:
                widths[c] = max(widths[c], len(str(r.get(c, ""))))
        line = "  " + "  ".join(str(c).ljust(widths[c]) for c in cols)
        sep = "  " + "  ".join("-" * widths[c] for c in cols)
        body = "\n".join(
            "  " + "  ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols)
            for r in rows)
        return line + "\n" + sep + "\n" + body + "\n"

    def render(self):
        w = self.worst()
        n = {s: sum(1 for f in self.findings if f.severity == s)
             for s in (CRIT, WARN, INFO, OK)}
        out = []
        out.append("=" * 78)
        out.append(self.title)
        out.append("=" * 78)
        host = os.uname().nodename
        out.append("host: %s   time: %sZ" %
                   (host, self.ts.strftime("%Y-%m-%d %H:%M:%S")))
        if self.role:
            out.append("role: %s" % self.role)
        # machine-readable summary line (easy to grep from cron mail / Nagios)
        out.append("RESULT: %s   crit=%d warn=%d info=%d" %
                   (w, n[CRIT], n[WARN], n[INFO]))
        out.append("")
        # findings
        out.append("FINDINGS")
        out.append("-" * 78)
        if not self.findings:
            out.append("  none")
        for f in sorted(self.findings, key=lambda x: -_RANK[x.severity]):
            out.append("[%s] %s" % (f.severity, f.title))
            if f.detail:
                for ln in f.detail.splitlines():
                    out.append("       " + ln)
            if f.action:
                out.append("   -> recommended action:")
                for ln in f.action.splitlines():
                    out.append("        " + ln)
            out.append("")
        # data tables
        for heading, rows, cols in self.tables:
            out.append(heading)
            out.append("-" * 78)
            out.append(self._fmt_table(rows, cols))
        # free blocks
        for heading, text in self.blocks:
            out.append(heading)
            out.append("-" * 78)
            out.append(text)
            out.append("")
        return "\n".join(out)

    def emit(self, tag, quiet=False):
        """Write the report to OUT_DIR and print it (unless quiet). Returns the
        process exit code derived from the worst finding."""
        os.makedirs(OUT_DIR, exist_ok=True)
        stamp = self.ts.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(OUT_DIR, "%s_%s.txt" % (tag, stamp))
        text = self.render()
        with open(path, "w") as f:
            f.write(text + "\n")
        # keep a stable "latest" pointer for dashboards / quick tailing
        latest = os.path.join(OUT_DIR, "%s_latest.txt" % tag)
        try:
            if os.path.islink(latest) or os.path.exists(latest):
                os.remove(latest)
            os.symlink(path, latest)
        except OSError:
            pass
        if not quiet:
            print(text)
        else:
            print("RESULT: %s  (%s)" % (self.worst(), path))
        return _EXIT[self.worst()]
