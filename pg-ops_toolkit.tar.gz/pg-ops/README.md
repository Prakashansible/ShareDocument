# pg-ops — standalone PostgreSQL operations toolkit

Six self-contained tools that run unattended on your AlmaLinux 9 / PostgreSQL
15–17 servers. Each one **collects diagnostics, applies deterministic DBA rules,
and writes a plain-text report** with findings, severities, and ready-to-run
recommended commands. Exit codes (0 OK, 1 WARN, 2 CRIT) drive cron/systemd alerts.

No external services and no third-party packages: just `psql`, the PostgreSQL
server utilities, Python 3.9 stdlib, and bash.

| # | Tool | What it does | Cadence |
|---|------|--------------|---------|
| 1 | `01_slow_query_triage/slow_query_triage.py` | Ranks `pg_stat_statements`; flags hot spots, low cache-hit, unstable plans, seq-scan-heavy tables, unused indexes | daily |
| 2 | `02_replication_watchdog/replication_watchdog.py` | Primary/standby lag, inactive-slot (`ssncpri`) + WAL-retention detection, remediation | 5 min |
| 3 | `03_log_classifier/log_classifier.py` | Buckets + trends `/apps/logs` events; per-class findings + fixes | 6 h |
| 4 | `04_bloat_advisor/bloat_advisor.py` | Dead-tuple pressure → emits VACUUM + per-table autovacuum `ALTER TABLE` commands | daily |
| 5 | `05_backup_verify/verify_backup.sh` | Restores latest backup to a scratch instance, `pg_amcheck`, PASS/FAIL | weekly |
| 6 | `06_param_safety_reviewer/param_safety_reviewer.py` | Reviews a proposed config change; standby-first plan + rollback | on demand |

## Combined morning report
`run_all.sh` runs the four **read-only** checks (slow-query, replication, logs,
bloat — not backup verification or the param reviewer) in sequence and writes one
combined report to `/apps/logs/pg-ops/morning_YYYYMMDD_HHMMSS.txt` (plus a
`morning_latest.txt` symlink). It stacks the FINDINGS from each check under a
summary table and exits with the worst severity. A check that fails to run is
shown as `ERROR` and forces CRIT so nothing fails silently.
```bash
./run_all.sh                    # full report (cron mails it)
./run_all.sh --since-hours 12   # narrower log window
./run_all.sh --quiet            # only the OVERALL line; report still written
```
The default crontab uses this as a single 06:30 morning entry.

## Install
```bash
./setup.sh /apps/pg-ops
vi /apps/pg-ops/etc/pg-ops.conf      # PG_VERSION, PGBIN, connection, paths
. /apps/pg-ops/etc/pg-ops.conf
/apps/pg-ops/02_replication_watchdog/replication_watchdog.py   # smoke test
```

## Output
Every run writes `NNtag_YYYYMMDD_HHMMSS.txt` to `/apps/logs/pg-ops/` and updates
a `tag_latest.txt` symlink. Each report starts with a grep-friendly line:
```
RESULT: WARN   crit=0 warn=2 info=1
```
Use `--quiet` in cron to print just that line (the full report is still written).

## Scheduling
- `scheduling/pg-ops.crontab` — all five scheduled jobs (set `MAILTO`).
- `scheduling/pg-ops-replication.{service,timer}` — systemd timer for the watchdog.

## The two hard rules, enforced in-code
- **Standby-first** for `max_connections`, `max_worker_processes`,
  `max_wal_senders`, `max_prepared_transactions`, `max_locks_per_transaction`
  (tools 2 and 6).
- **Never `ALTER SYSTEM RESET ALL` on a standby** — tool 6 refuses it and emits
  the per-parameter `RESET` form instead.

## Notes
- Tool 1 needs `pg_stat_statements` (it tells you how to enable it if missing).
- Tool 4's `--pgstattuple` gives precise bloat if the extension is present.
- Tool 5 only ever writes to a scratch dir on a scratch port and refuses to run
  if either collides with the live instance.
