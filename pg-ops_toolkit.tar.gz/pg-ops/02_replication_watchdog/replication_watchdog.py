#!/usr/bin/env python3
"""
replication_watchdog.py - streaming replication health, standalone.

Auto-detects primary vs standby, collects the right catalogs, applies
thresholds, and writes a report with findings + exact remediation that obeys
your two hard rules. Exit code 0/1/2 (OK/WARN/CRIT) drives cron/systemd alerts.

Usage:
  ./replication_watchdog.py --warn-lag-mb 64 --crit-lag-mb 512
  ./replication_watchdog.py --quiet          # cron-friendly (one summary line)
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
from pgcommon import (run_sql_json, scalar, Report,   # noqa: E402
                      OK, INFO, WARN, CRIT)

SLOT = os.environ.get("PGOPS_SLOT", "ssncpri")
PRIMARY = os.environ.get("PGOPS_PRIMARY", "db01")
STANDBY = os.environ.get("PGOPS_STANDBY", "db02")

STANDBY_FIRST = (
    "Standby-first rule for replication-sensitive params (max_connections,\n"
    "max_worker_processes, max_wal_senders, max_prepared_transactions,\n"
    "max_locks_per_transaction): raise + restart the STANDBY first, confirm\n"
    "streaming resumes, THEN the primary. On the standby use only\n"
    "ALTER SYSTEM RESET <param>; never ALTER SYSTEM RESET ALL.")


def num(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def assess_primary(rep, args):
    repl = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT application_name, client_addr::text AS client, state, sync_state,
               pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn)) AS replay_lag,
               pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn)                 AS replay_lag_bytes,
               coalesce(replay_lag::text,'') AS apply_time
        FROM pg_stat_replication) t;""")
    slots = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT slot_name, slot_type, active, wal_status,
               pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)) AS retained_wal,
               pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)                 AS retained_bytes
        FROM pg_replication_slots) t;""")
    rep.table("pg_stat_replication", repl,
              cols=["application_name", "client", "state", "sync_state",
                    "replay_lag", "apply_time"])
    rep.table("pg_replication_slots", slots,
              cols=["slot_name", "slot_type", "active", "wal_status", "retained_wal"])

    if not repl:
        rep.finding(WARN, "No standby is currently connected to this primary",
                    "pg_stat_replication is empty.",
                    "On %s check: is postgres up? is the walreceiver started?\n"
                    "Check primary_conninfo on the standby and pg_hba.conf here\n"
                    "(a 'replication' line for user 'replicator')." % STANDBY)

    for r in repl:
        lag_mb = num(r.get("replay_lag_bytes")) / 1048576
        who = r.get("application_name") or r.get("client")
        if lag_mb >= args.crit_lag_mb:
            rep.finding(CRIT, "replay lag %.0f MB to %s" % (lag_mb, who),
                        "Standby is falling far behind on apply.",
                        "Check standby I/O and recovery conflicts; confirm the\n"
                        "standby is not paused (pg_wal_replay_resume() if so).")
        elif lag_mb >= args.warn_lag_mb:
            rep.finding(WARN, "replay lag %.0f MB to %s" % (lag_mb, who))

    for s in slots:
        name = s.get("slot_name")
        if s.get("active") == "f":
            ret = s.get("retained_wal")
            rep.finding(CRIT, "replication slot '%s' is INACTIVE" % name,
                        "No consumer is attached; the slot is pinning WAL "
                        "(retained %s and growing). This is the ssncpri-style\n"
                        "failure that can fill pg_wal and stop the primary." % ret,
                        "1) Restart/repair the standby's walreceiver so it\n"
                        "   reconnects to slot '%s'.\n"
                        "2) If the standby is gone for good, drop the slot to\n"
                        "   release WAL:  SELECT pg_drop_replication_slot('%s');\n"
                        "3) %s" % (name, name, STANDBY_FIRST))
        if s.get("wal_status") in ("lost", "unreserved"):
            rep.finding(CRIT, "slot '%s' wal_status=%s" % (name, s.get("wal_status")),
                        "Required WAL has been removed; the standby cannot catch\n"
                        "up by streaming alone.",
                        "Rebuild the standby (pg_basebackup or pgBackRest restore),\n"
                        "then restart streaming against slot '%s'." % name)


def assess_standby(rep, args):
    wr = run_sql_json("""
      SELECT coalesce(json_agg(t),'[]') FROM (
        SELECT status, sender_host, slot_name,
               last_msg_receipt_time::text AS last_msg,
               pg_last_wal_receive_lsn()::text AS receive_lsn,
               pg_last_wal_replay_lsn()::text  AS replay_lsn,
               pg_size_pretty(pg_wal_lsn_diff(
                   pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn())) AS apply_lag,
               pg_wal_lsn_diff(pg_last_wal_receive_lsn(),
                               pg_last_wal_replay_lsn()) AS apply_lag_bytes,
               coalesce(extract(epoch FROM (now()
                   - pg_last_xact_replay_timestamp()))::int, -1) AS replay_age_s
        FROM pg_stat_wal_receiver) t;""")
    rep.table("pg_stat_wal_receiver", wr,
              cols=["status", "sender_host", "slot_name", "last_msg",
                    "apply_lag", "replay_age_s"])
    paused = scalar("SELECT pg_is_wal_replay_paused();") == "t"
    if paused:
        rep.finding(WARN, "WAL replay is PAUSED on this standby",
                    "Received WAL is not being applied.",
                    "SELECT pg_wal_replay_resume();")
    if not wr:
        rep.finding(CRIT, "No walreceiver row - this standby is NOT streaming",
                    "pg_stat_wal_receiver is empty.",
                    "Check on this standby:\n"
                    "  - primary_conninfo in postgresql.auto.conf is intact\n"
                    "    (a stray ALTER SYSTEM RESET ALL wipes it);\n"
                    "  - the primary %s has a 'replication' pg_hba.conf entry for\n"
                    "    user 'replicator' from this host;\n"
                    "  - slot '%s' exists and is not lost on the primary;\n"
                    "  - server log /apps/logs for the walreceiver FATAL." % (PRIMARY, SLOT))
        return
    lag_mb = num(wr[0].get("apply_lag_bytes")) / 1048576
    if lag_mb >= args.crit_lag_mb:
        rep.finding(CRIT, "apply lag %.0f MB" % lag_mb,
                    "Standby apply is far behind received WAL.")
    elif lag_mb >= args.warn_lag_mb:
        rep.finding(WARN, "apply lag %.0f MB" % lag_mb)
    else:
        rep.finding(OK, "streaming healthy (apply lag %.0f MB)" % lag_mb)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--warn-lag-mb", type=float, default=64)
    ap.add_argument("--crit-lag-mb", type=float, default=512)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    standby = scalar("SELECT pg_is_in_recovery();") == "t"
    role = "STANDBY (in recovery)" if standby else "PRIMARY"
    rep = Report("PostgreSQL replication health", role=role)
    if standby:
        assess_standby(rep, args)
    else:
        assess_primary(rep, args)
    if not rep.findings:
        rep.finding(OK, "All replication checks passed")
    return rep.emit("replication", args.quiet)


if __name__ == "__main__":
    sys.exit(main())
