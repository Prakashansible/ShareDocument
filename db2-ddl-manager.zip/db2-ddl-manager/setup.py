"""Setup configuration for db2-ddl-manager."""

from pathlib import Path
from setuptools import setup, find_packages

HERE = Path(__file__).parent
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="db2-ddl-manager",
    version="1.0.0",
    description="Production-grade CLI for DB2 DDL management across multiple servers",
    long_description=README,
    long_description_content_type="text/markdown",
    author="DBA Team",
    python_requires=">=3.10",
    packages=find_packages(exclude=["tests*"]),
    install_requires=[
        "click>=8.1,<9",
        "paramiko>=3.4,<4",
        "sshtunnel>=0.4,<1",
        "ibm_db>=3.2",
        "PyYAML>=6.0,<7",
        "rich>=13.0,<14",
    ],
    entry_points={
        "console_scripts": [
            "db2ddl=db2ddl.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Unix",
        "Topic :: Database",
        "Topic :: System :: Systems Administration",
        "Environment :: Console",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
    ],
)
