# db2-ddl-manager

A production-grade Python CLI tool for managing DB2 DDL (Data Definition Language) operations across multiple servers and environments. Designed for DBA teams operating large-scale DB2 estates on AIX/Linux bastion hosts, with optional laptop/workstation mode for local development.

---

## 1. Overview

`db2-ddl-manager` automates the lifecycle of DDL changes (CREATE TABLE, ALTER TABLE ADD COLUMN) across all DB2 instances and databases in dev, beta, and production environments simultaneously. It eliminates the error-prone manual process of SSH-ing to each server and running DDL one database at a time.

Key capabilities:

- **Dynamic discovery** — no static database lists. Uses `db2ilist` and `db2 list db directory` over SSH to discover all instances and databases at runtime.
- **Full idempotency** — safe to re-run. Checks SYSCAT before executing; skips objects that already exist.
- **Per-column idempotency for ALTER** — adds only the columns that are missing, skips those that already exist.
- **Multi-environment** — target dev, beta, prod, or all environments in a single command.
- **Three execution modes** — runs on AIX/Linux bastions (single-hop or direct) or from a developer laptop (double-hop via bastion).
- **Automatic rollback generation** — produces a DROP TABLE or DROP COLUMN script after every successful run.
- **Structured audit logging** — every operation is logged as JSON (JSONL) with full context: user, server, database, SQL executed, duration, status.
- **Per-environment locking** — prevents two DBAs from running concurrent DDL against the same environment.
- **Beta/prod safety gates** — interactive confirmation required before any write operation in beta or production.
- **Rich console output** — color-coded summary tables with per-database status, reorg status, skip/fail details.

---

## 2. How It Works

```
db2ddl discover --env prod
       |
       v
  For each server in inventory:
    SSH --> db2ilist --> [db2inst1, db2inst2, ...]
    For each instance:
      sudo -i -u <instance> db2 get dbm cfg | grep SVCENAME --> port
      sudo -i -u <instance> db2 list db directory --> [PRODDB1, PRODDB2, ...]
    Apply filters (exclude_instances, exclude_databases, include_databases)
    Cache results to /tmp/db2ddl_discovery_<env>_latest.json

db2ddl create-table --env prod --ddl-file ddl/create.sql
       |
       v
  Load cached (or re-discover) topology
  Validate DDL file (no DB connection needed)
  Prompt for CONFIRM PRODUCTION
  Acquire /tmp/db2ddl_prod.lock
  For each server -> instance -> database:
    Connect via SSH tunnel (or direct / double-hop depending on mode)
    Check SYSCAT.TABLES for idempotency
    Execute CREATE TABLE {schema}.TABLENAME
    Check reorg status
    Write audit log entry
  Release lock
  Print summary table
  Write rollback script to ddl/rollback/
```

The schema for each database is derived automatically: `schema = "ZPS" + database_name` (e.g., database `DEVDB1` uses schema `ZPSDEVDB1`). The `{schema}` placeholder in your DDL files is replaced at execution time.

---

## 3. Execution Modes

### `bastion` (recommended for production)

The tool is installed and run **on the AIX/Linux bastion host**. All SSH connections are single-hop (bastion → target). DB2 connections use an SSH tunnel from the bastion to the target DB2 port.

```
[bastion host]
    |-- SSH --> [db2server01]  (discovery + DB2 connection via tunnel)
    |-- SSH --> [db2server02]
    ...
```

### `bastion_direct`

Same as `bastion` (tool on bastion, single-hop SSH for discovery), but DB2 connections go over direct TCP instead of an SSH tunnel. Use this only when the bastion has network-level access to the DB2 listener ports.

```
[bastion host]
    |-- SSH --> [db2server01]  (discovery via SSH)
    |-- TCP --> [db2server01:50000]  (DB2 connection — direct, no tunnel)
```

### `laptop`

The tool runs on a developer laptop or workstation. All connections use a double-hop through the bastion:

```
[laptop]
    |-- SSH --> [bastion]
                    |-- SSH --> [db2server01]  (discovery — Paramiko direct-tcpip channel)
                    |-- TCP --> [db2server01:50000]  (DB2 connection via sshtunnel)
```

Set `execution_mode: laptop` in your `inventory.yaml` and fill in the `bastion:` section.

---

## 4. Prerequisites

### All Modes

| Requirement | Notes |
|---|---|
| Python 3.10+ | Check with `python3 --version` |
| SSH key access | The SSH user in `target_ssh` must have a valid key on all target servers |
| `sudo` rights | The SSH user needs `sudo -i -u <instance>` to run DB2 commands as each instance owner |
| DB2 password | Stored in an environment variable (e.g., `DB2_PASSWORD`) — never in YAML |

### Bastion Mode (AIX-specific)

On IBM AIX, the `ibm_db` Python package requires the DB2 client runtime libraries. Before installing:

```sh
export IBM_DB_HOME=/opt/IBM/db2/V11.5    # or your DB2 installation path
export LIBPATH=$IBM_DB_HOME/lib64:$LIBPATH
export PATH=$IBM_DB_HOME/bin:$PATH
```

Add these to your `.profile` or `.bashrc` to persist across sessions.

The `ibm_db` package compiles a C extension at install time. On AIX, this requires:
- `xlc` (IBM C compiler) or `gcc` installed
- DB2 client headers (`db2ApiDf.h` etc.) available under `$IBM_DB_HOME/include`

### Laptop Mode

- Laptop needs SSH access to the bastion (key-based authentication)
- Bastion needs SSH access to all target DB2 servers
- No DB2 client or `ibm_db` needed on the laptop — the DB2 connection is tunneled through

---

## 5a. Installing on Bastion (AIX/Linux)

```sh
# 1. Ensure Python 3.10+ is available
python3 --version

# 2. Set DB2 library paths (AIX only)
export IBM_DB_HOME=/opt/IBM/db2/V11.5
export LIBPATH=$IBM_DB_HOME/lib64:$LIBPATH

# 3. Clone or copy the project to the bastion
cd /opt/dba-tools
git clone https://github.com/yourorg/db2-ddl-manager.git
cd db2-ddl-manager

# 4. Create a Python virtual environment
python3 -m venv .venv
source .venv/bin/activate

# 5. Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# 6. Install the CLI tool
pip install -e .

# 7. Verify installation
db2ddl --version

# 8. Create your inventory file
cp config/inventory.example.yaml config/inventory.yaml
vi config/inventory.yaml   # edit for your environment

# 9. Set the DB2 password environment variable
export DB2_PASSWORD='your_db2_instance_password'

# 10. Test discovery
db2ddl discover --env dev
```

To make the `LIBPATH` and `IBM_DB_HOME` permanent, add them to `/opt/dba-tools/db2-ddl-manager/.venv/bin/activate` or your `.profile`.

---

## 5b. Installing on Laptop

```sh
# 1. Ensure Python 3.10+ is installed
python3 --version

# 2. Clone the repository
git clone https://github.com/yourorg/db2-ddl-manager.git
cd db2-ddl-manager

# 3. Create virtual environment
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 4. Install dependencies (ibm_db may fail on laptop without DB2 client — that's OK
#    in laptop mode; DB2 connections are tunneled and ibm_db runs on the bastion side)
pip install --upgrade pip
pip install -r requirements.txt

# 5. Install the CLI
pip install -e .

# 6. Configure inventory
cp config/inventory.example.yaml config/inventory.yaml
# Edit config/inventory.yaml:
#   - Set execution_mode: laptop
#   - Fill in the bastion: section with host, port, user, key_file
#   - Fill in target_ssh: with the SSH user/key for DB2 servers

# 7. Set the DB2 password
export DB2_PASSWORD='your_db2_instance_password'

# 8. Test
db2ddl discover --env dev
```

---

## 6. Configuration

Configuration lives in `config/inventory.yaml` (not committed to git). Copy from `config/inventory.example.yaml`.

### Top-level structure

```yaml
execution_mode: bastion          # bastion | bastion_direct | laptop

bastion:                         # Only required for laptop mode
  host: bastion01.corp.example.com
  port: 22
  user: dba_svc_acct
  key_file: ~/.ssh/id_rsa_bastion

target_ssh:
  user: db2_ssh_user             # OS user on target DB2 servers
  key_file: ~/.ssh/id_rsa_db2
  port: 22

db2_credentials:
  password_var: DB2_PASSWORD     # Name of the env var holding the password

connection_defaults:
  db2_connect_timeout: 10
  ddl_statement_timeout: 120
  ssh_command_timeout: 30
  retry_count: 1
  retry_delay: 5

environments:
  dev:
    servers:
      - host: db2dev01.internal.example.com
    filters:
      exclude_instances: [db2fenc1, dasuser]
      exclude_databases: [TOOLSDB, SAMPLE]

  beta:
    servers:
      - host: db2beta01.internal.example.com
      - host: db2beta02.internal.example.com
    filters:
      exclude_instances: [db2fenc1]
      exclude_databases: [TOOLSDB]

  prod:
    servers:
      - host: db2prod01.internal.example.com
      # ... up to 8 servers
    filters:
      exclude_instances: [db2fenc1, dasuser]
      exclude_databases: [TOOLSDB, HISTDB]
      # include_databases: [PRODDB1, PRODDB2]  # whitelist recommended for prod
```

### Schema convention

The schema is derived automatically from the database name:

```
database name: DEVDB1
schema:        ZPSDEVDB1   (= "ZPS" + database_name)
```

Use `{schema}` as a placeholder in your DDL files. Do not hardcode schema names.

---

## 7. Quick Start

```sh
# Step 1: Verify SSH connectivity and see what will be targeted
db2ddl discover --env dev

# Step 2: Validate your DDL file (no DB connection needed)
db2ddl validate-ddl --ddl-file ddl/my_table.sql --type create

# Step 3: Dry run — see what SQL would execute, without making changes
db2ddl create-table --env dev --ddl-file ddl/my_table.sql --dry-run

# Step 4: Execute for real
db2ddl create-table --env dev --ddl-file ddl/my_table.sql
```

---

## 8. Command Reference

All commands accept `--help` for detailed usage.

### `db2ddl discover`

Live topology discovery via SSH. Runs `db2ilist` and `db2 list db directory` on each server.

```sh
db2ddl discover --env <ENV> [OPTIONS]

Options:
  --env TEXT          Target environment: dev, beta, prod, or all  [required]
  --server TEXT       Filter to a specific server hostname
  --use-cache         Use cached discovery results (< 15 min old)
  --config PATH       Path to inventory YAML (default: config/inventory.yaml)
  --log-level TEXT    Log level: DEBUG, INFO, WARNING, ERROR (default: INFO)
```

Example:
```sh
db2ddl discover --env all
db2ddl discover --env prod --server db2prod01.internal.example.com
```

### `db2ddl create-table`

Execute a CREATE TABLE DDL file across all discovered databases.

```sh
db2ddl create-table --env <ENV> --ddl-file <PATH> [OPTIONS]

Options:
  --env TEXT          Target environment  [required]
  --ddl-file PATH     Path to CREATE TABLE DDL file  [required]
  --dry-run           Show SQL without executing
  --fail-fast         Stop on first error
  --server TEXT       Limit to one server
  --instance TEXT     Limit to one instance
  --database TEXT     Limit to one database
  --use-cache         Use cached discovery
  --config PATH       Path to inventory YAML
```

Example:
```sh
db2ddl create-table --env dev --ddl-file ddl/samples/create_sample_table.sql --dry-run
db2ddl create-table --env beta --ddl-file ddl/my_table.sql
db2ddl create-table --env prod --ddl-file ddl/my_table.sql --fail-fast
```

### `db2ddl add-columns`

Execute ALTER TABLE ADD COLUMN across all discovered databases.

```sh
db2ddl add-columns --env <ENV> --table <NAME> --ddl-file <PATH> [OPTIONS]

Options:
  --env TEXT          Target environment  [required]
  --table TEXT        Table name (without schema prefix)  [required]
  --ddl-file PATH     DDL file with ADD COLUMN definitions  [required]
  --auto-reorg        Run REORG+RUNSTATS automatically if reorg is pending
  --dry-run           Show SQL without executing
  --fail-fast         Stop on first error
  --server TEXT       Limit to one server
  --instance TEXT     Limit to one instance
  --database TEXT     Limit to one database
  --use-cache         Use cached discovery
  --config PATH       Path to inventory YAML
```

Example:
```sh
db2ddl add-columns --env dev \
  --table CUSTOMER_ORDERS \
  --ddl-file ddl/samples/alter_add_columns_sample.sql \
  --dry-run

db2ddl add-columns --env prod \
  --table CUSTOMER_ORDERS \
  --ddl-file ddl/alter_add_promo_cols.sql \
  --auto-reorg
```

### `db2ddl check-status`

Check reorg/stats status for a table across all databases. Does not modify anything.

```sh
db2ddl check-status --env <ENV> --table <NAME> [OPTIONS]

Options:
  --env TEXT          Target environment  [required]
  --table TEXT        Table name  [required]
  --server / --instance / --database TEXT   Filter options
  --use-cache         Use cached discovery
  --config PATH       Path to inventory YAML
```

Example:
```sh
db2ddl check-status --env prod --table CUSTOMER_ORDERS
db2ddl check-status --env all --table CUSTOMER_ORDERS
```

### `db2ddl reorg`

Run REORG (and optionally RUNSTATS) on a table.

```sh
db2ddl reorg --env <ENV> --table <NAME> [OPTIONS]

Options:
  --env TEXT          Target environment  [required]
  --table TEXT        Table name  [required]
  --only-pending      Only REORG databases where reorg is pending
  --runstats          Run RUNSTATS after REORG completes
  --dry-run           Show what would execute without running
  --server / --instance / --database TEXT   Filter options
  --use-cache         Use cached discovery
  --config PATH       Path to inventory YAML
```

Example:
```sh
# Reorg only where pending, with runstats
db2ddl reorg --env prod --table CUSTOMER_ORDERS --only-pending --runstats

# Full reorg of all instances, dry run first
db2ddl reorg --env prod --table CUSTOMER_ORDERS --dry-run
db2ddl reorg --env prod --table CUSTOMER_ORDERS
```

### `db2ddl list-inventory`

Display the static YAML inventory configuration. No SSH connections made.

```sh
db2ddl list-inventory --env <ENV> [OPTIONS]

Options:
  --env TEXT          Environment to display (or 'all')  [required]
  --config PATH       Path to inventory YAML
```

Example:
```sh
db2ddl list-inventory --env all
```

### `db2ddl validate-ddl`

Validate a DDL file for syntax issues without connecting to any database.

```sh
db2ddl validate-ddl --ddl-file <PATH> --type <create|alter>

Options:
  --ddl-file PATH     Path to DDL file  [required]
  --type TEXT         Type: 'create' or 'alter'  [required]
```

Checks performed:
- File exists and is readable
- Not empty
- Required keywords present (`CREATE TABLE` or `ADD COLUMN`)
- `{schema}` placeholder present (for CREATE files)
- No dangerous statements (`DROP TABLE`, `TRUNCATE`, `DELETE FROM`, etc.)
- Column data types are valid DB2 types

Example:
```sh
db2ddl validate-ddl --ddl-file ddl/my_table.sql --type create
db2ddl validate-ddl --ddl-file ddl/alter_cols.sql --type alter
```

Exit codes: `0` = valid, `5` = validation failed.

---

## 9. Discovery System

The discovery system is the foundation of all operations. It runs automatically before any DDL command.

### How discovery works

For each server in the inventory:

1. SSH to the server using the key in `target_ssh`
2. Run `db2ilist` to get all instance names on that server
3. For each instance:
   - Run `sudo -i -u <instance> db2 get dbm cfg | grep SVCENAME` to get the listener port
   - If SVCENAME is a service name (not a number), resolve it via `/etc/services`
   - Run `sudo -i -u <instance> db2 list db directory` to get all databases
   - Only databases with `Directory entry type = Indirect` are included (remote catalog entries are excluded)
4. Apply filters from inventory (`exclude_instances`, `exclude_databases`, `include_databases`)
5. Build `DiscoveredServer` → `DiscoveredInstance` → `DiscoveredDatabase` objects

### Discovery cache

Results are cached to `/tmp/db2ddl_discovery_<env>_latest.json` for 15 minutes. Use `--use-cache` on subsequent commands to skip re-discovery and speed up the workflow:

```sh
db2ddl discover --env prod          # runs discovery, populates cache
db2ddl create-table --env prod \
  --ddl-file ddl/my_table.sql \
  --use-cache                        # uses cached results, skips SSH
```

### Unreachable servers

If a server is unreachable (SSH timeout, host down, authentication failure), it is marked `reachable=False` in the topology. DDL commands skip these servers and report them as `CONN_FAILED` in the summary.

### The sudo requirement

The SSH user needs passwordless `sudo -i -u <instance>` rights for `bash`. Add to `/etc/sudoers` on each DB2 server:

```
db2_ssh_user ALL=(db2inst1,db2inst2) NOPASSWD: /bin/bash
```

---

## 10. Schema Convention

The schema for each database is derived as:

```
schema = "ZPS" + database_name.upper()
```

Examples:

| Database | Schema |
|---|---|
| DEVDB1 | ZPSDEVDB1 |
| BETADB2 | ZPSBETADB2 |
| PRODDB8 | ZPSPRODDBB8 |

In your DDL files, always use `{schema}` as the placeholder:

```sql
-- Correct:
CREATE TABLE {schema}.MY_TABLE ( ... );

-- Wrong — do not hardcode:
CREATE TABLE ZPSDEVDB1.MY_TABLE ( ... );
```

The tool substitutes `{schema}` with the correct value for each database at execution time.

---

## 11. Safety Features

### DDL Validation (pre-execution)

Before connecting to any database, the tool validates the DDL file:

- Checks for dangerous statements (`DROP TABLE`, `DROP DATABASE`, `TRUNCATE`, `DELETE FROM`, `DROP SCHEMA`, `DROP TABLESPACE`)
- Verifies required keywords and `{schema}` placeholder
- Warns on unrecognized data types

Validation runs at the start of `create-table` and `add-columns` commands. The run aborts if validation fails.

### Idempotency

- **create-table**: Checks `SYSCAT.TABLES` before creating. Skips with status `SKIPPED` if the table already exists.
- **add-columns**: Checks `SYSCAT.COLUMNS` for each column before altering. Only the missing columns are added. If all columns already exist, the database is skipped entirely.

### Beta/prod confirmation gates

Interactive prompts are required before write operations in non-dev environments:

- **beta**: Simple Y/N confirmation
- **prod**: Two-step confirmation — backup acknowledgment + typing `CONFIRM PRODUCTION`

### Per-environment locking

The tool creates `/tmp/db2ddl_<env>.lock` before starting any write operation. If a lock exists and the owning process is still alive, the command fails with a `LockConflictError` showing who holds the lock, what they are running, and when they started.

Stale locks (where the process is dead) are automatically cleaned up.

### Fail-fast mode

Use `--fail-fast` to stop the entire run on the first error. Without it, the tool continues to the next database and reports all failures in the summary.

### Rollback script generation

After every successful write operation (create-table or add-columns), a rollback script is automatically generated in `ddl/rollback/`:

- `drop_<tablename>_<timestamp>.sql` — for create-table
- `alter_drop_<tablename>_<timestamp>.sql` — for add-columns

These scripts are NOT auto-executed. They are reference scripts for manual rollback if needed.

---

## 12. Logging and Audit

### Log files

Daily JSON log files are written to `logs/db2ddl_YYYY-MM-DD.log` (one line per event, JSONL format). The rich console handler provides human-readable output to stderr during execution.

### Audit entries

Every database-level operation writes a structured audit entry:

```json
{
  "timestamp": "2026-04-03T14:23:11.452Z",
  "command": "add-columns",
  "environment": "prod",
  "server": "db2prod01.internal.example.com",
  "instance": "db2inst1",
  "database": "PRODDB1",
  "schema": "ZPSPRODDB1",
  "table": "CUSTOMER_ORDERS",
  "sql_executed": "ALTER TABLE ZPSPRODDB1.CUSTOMER_ORDERS\n  ADD COLUMN PROMO_CODE VARCHAR(50)",
  "status": "SUCCESS",
  "reorg_pending": true,
  "reorg_executed": false,
  "runstats_executed": false,
  "duration_ms": 847,
  "dry_run": false,
  "os_user": "dba_ops",
  "db2_user": "db2inst1",
  "error_message": null,
  "execution_mode": "bastion"
}
```

Passwords are never logged. Any key containing `pwd` or `password` is stripped before writing.

### Querying audit logs with jq

```sh
# All successful operations today
jq 'select(.status == "SUCCESS")' logs/db2ddl_$(date +%Y-%m-%d).log

# All failed operations
jq 'select(.status == "FAILED" or .status == "CONN_FAILED")' logs/db2ddl_$(date +%Y-%m-%d).log

# Operations on a specific table
jq 'select(.table == "CUSTOMER_ORDERS")' logs/db2ddl_$(date +%Y-%m-%d).log

# All databases where reorg is pending
jq 'select(.reorg_pending == true) | {server, database, table}' logs/db2ddl_$(date +%Y-%m-%d).log

# Summary count by status
jq -s 'group_by(.status) | map({status: .[0].status, count: length})' logs/db2ddl_$(date +%Y-%m-%d).log

# Operations by a specific user
jq 'select(.os_user == "dba_ops")' logs/db2ddl_$(date +%Y-%m-%d).log
```

---

## 13. Troubleshooting

### Error: `Inventory file not found`

```
ConfigError: Inventory file not found: config/inventory.yaml
```

**Fix:** Copy the example inventory and edit it:
```sh
cp config/inventory.example.yaml config/inventory.yaml
vi config/inventory.yaml
```

---

### Error: `Required environment variable DB2_PASSWORD is not set`

```
ERROR: Required environment variable DB2_PASSWORD is not set.
```

**Fix:** Export the variable before running:
```sh
export DB2_PASSWORD='your_db2_password'
```

If you use a different variable name, set `db2_credentials.password_var` in your inventory.

---

### Error: `ibm_db not available`

```
ibm_db not available. DB2 connections will fail.
```

**Fix on AIX/Linux:**
```sh
export IBM_DB_HOME=/opt/IBM/db2/V11.5
export LIBPATH=$IBM_DB_HOME/lib64:$LIBPATH
pip install ibm_db
```

**On laptop (laptop mode):** `ibm_db` is not needed on the laptop itself — connections are tunneled. If you see this warning on a laptop with `execution_mode: laptop`, it is non-fatal and can be ignored.

---

### Error: `SSH/discovery failed: Authentication failed`

```
db2ddl.discovery - ERROR - db2dev01: SSH/discovery failed: Authentication failed.
```

**Causes and fixes:**
1. Wrong `target_ssh.key_file` path — verify the key file exists and is readable
2. Wrong `target_ssh.user` — verify the OS user exists on the target server
3. Key not authorized — ensure the public key is in `~/.ssh/authorized_keys` on the target server
4. Permissions on `~/.ssh/` — on the target: `chmod 700 ~/.ssh && chmod 600 ~/.ssh/authorized_keys`

In laptop mode, also verify the bastion key:
```sh
ssh -i ~/.ssh/id_rsa_bastion dba_svc_acct@bastion01.corp.example.com
```

---

### Error: `Could not find SVCENAME in dbm cfg output`

```
RuntimeError: Could not find SVCENAME in dbm cfg output for instance db2inst1
```

**Cause:** The discovery command `sudo -i -u db2inst1 db2 get dbm cfg` returned no output, or the instance has no SVCENAME configured.

**Fixes:**
1. Verify `sudo` permissions — the SSH user must be able to run `sudo -i -u db2inst1 bash`
2. Verify the instance is started: `sudo -i -u db2inst1 bash -c '. ~/sqllib/db2profile && db2start'`
3. Verify SVCENAME is set: `sudo -i -u db2inst1 bash -c '. ~/sqllib/db2profile && db2 get dbm cfg | grep SVCENAME'`

---

### Error: `Environment 'prod' is locked by user 'dba_alice'`

```
LockConflictError: Environment 'prod' is locked by user 'dba_alice' (PID 12345)
   Running: add-columns --table CUSTOMER_ORDERS
   Since: 2026-04-03T14:10:00Z
```

**Fix:** Wait for the running operation to complete. If the other process is stuck or dead, remove the lock file manually:
```sh
rm /tmp/db2ddl_prod.lock
```

Only remove the lock file if you are certain the original process is no longer running.

---

### Error: `DDL Validation Failed: DDL file must contain the {schema} placeholder`

**Fix:** Update your DDL file to use `{schema}` instead of a hardcoded schema:
```sql
-- Wrong:
CREATE TABLE ZPSDEVDB1.MY_TABLE ( ... );

-- Correct:
CREATE TABLE {schema}.MY_TABLE ( ... );
```

---

## Project Structure

```
db2-ddl-manager/
├── db2ddl/
│   ├── __init__.py      Package init, version, OS warning
│   ├── cli.py           Click CLI entry point — all 7 commands
│   ├── config.py        YAML inventory loader and validator
│   ├── discovery.py     SSH-based DB2 topology discovery
│   ├── connection.py    DB2 connection manager (3 modes)
│   ├── executor.py      Core DDL execution engine
│   ├── validators.py    DDL file pre-validation (no DB needed)
│   ├── reorg.py         REORG/RUNSTATS execution
│   ├── rollback.py      Auto-generate rollback scripts
│   ├── report.py        Rich console summary report
│   ├── lockfile.py      Per-environment lock management
│   └── logger.py        Structured JSON + rich logging
├── config/
│   └── inventory.example.yaml
├── ddl/
│   ├── samples/
│   │   ├── create_sample_table.sql
│   │   └── alter_add_columns_sample.sql
│   └── rollback/        Auto-generated rollback scripts (gitignored)
├── logs/                Daily JSONL audit logs (gitignored)
├── requirements.txt
├── setup.py
├── .gitignore
└── README.md
```

---

## License

MIT License. See LICENSE file for details.
