-- =============================================================================
-- Sample ALTER TABLE ADD COLUMN DDL for db2-ddl-manager
-- =============================================================================
-- USAGE:
--   db2ddl validate-ddl --ddl-file ddl/samples/alter_add_columns_sample.sql --type alter
--   db2ddl add-columns --env dev --table CUSTOMER_ORDERS \
--                      --ddl-file ddl/samples/alter_add_columns_sample.sql --dry-run
--   db2ddl add-columns --env dev --table CUSTOMER_ORDERS \
--                      --ddl-file ddl/samples/alter_add_columns_sample.sql
--   db2ddl add-columns --env dev --table CUSTOMER_ORDERS \
--                      --ddl-file ddl/samples/alter_add_columns_sample.sql --auto-reorg
--
-- IMPORTANT — FORMAT RULES:
--   1. Include ONLY the ADD COLUMN clauses here — one per line.
--   2. Do NOT include "ALTER TABLE {schema}.CUSTOMER_ORDERS" — the tool adds that.
--   3. Do NOT end lines with semicolons.
--   4. Comments (-- lines) and blank lines are ignored.
--
-- IDEMPOTENCY:
--   The tool checks SYSCAT.COLUMNS before executing. Columns that already
--   exist are silently skipped. Only genuinely new columns are added.
--   This makes re-running safe at any time.
--
-- REORG NOTE:
--   DB2 requires a REORG after adding columns with non-null defaults to enable
--   full use of the new columns. Use --auto-reorg to trigger this automatically,
--   or run: db2ddl reorg --env dev --table CUSTOMER_ORDERS --only-pending --runstats
-- =============================================================================

ADD COLUMN PROMO_CODE        VARCHAR(50)
ADD COLUMN DISCOUNT_AMOUNT   DECIMAL(12, 2) DEFAULT 0.00
ADD COLUMN LOYALTY_POINTS    INTEGER        DEFAULT 0
ADD COLUMN PREFERRED_CARRIER VARCHAR(100)
ADD COLUMN DELIVERY_NOTES    VARCHAR(500)
ADD COLUMN IS_GIFT           CHAR(1)        DEFAULT 'N'
ADD COLUMN GIFT_MESSAGE      VARCHAR(250)
ADD COLUMN LAST_MODIFIED_BY  VARCHAR(64)    DEFAULT CURRENT USER
