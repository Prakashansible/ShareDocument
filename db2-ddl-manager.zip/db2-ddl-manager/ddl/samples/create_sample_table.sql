-- =============================================================================
-- Sample CREATE TABLE DDL for db2-ddl-manager
-- =============================================================================
-- USAGE:
--   db2ddl validate-ddl --ddl-file ddl/samples/create_sample_table.sql --type create
--   db2ddl create-table --env dev --ddl-file ddl/samples/create_sample_table.sql --dry-run
--   db2ddl create-table --env dev --ddl-file ddl/samples/create_sample_table.sql
--
-- SCHEMA PLACEHOLDER:
--   The tool automatically replaces {schema} with the discovered schema for each
--   database. Schema is derived as: ZPS + DATABASE_NAME (e.g., ZPSDEVDB1).
--   Do NOT hardcode the schema name here.
--
-- IDEMPOTENCY:
--   This DDL is safe to run multiple times. The tool checks SYSCAT.TABLES
--   before executing and skips databases where the table already exists.
-- =============================================================================

CREATE TABLE {schema}.CUSTOMER_ORDERS
(
    ORDER_ID          BIGINT          NOT NULL GENERATED ALWAYS AS IDENTITY
                                      (START WITH 1, INCREMENT BY 1),
    CUSTOMER_ID       BIGINT          NOT NULL,
    ORDER_DATE        TIMESTAMP       NOT NULL DEFAULT CURRENT TIMESTAMP,
    STATUS            VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
    TOTAL_AMOUNT      DECIMAL(15, 2)  NOT NULL DEFAULT 0.00,
    CURRENCY_CODE     CHAR(3)         NOT NULL DEFAULT 'USD',
    SHIPPING_ADDRESS  VARCHAR(500),
    NOTES             CLOB(1M),
    CREATED_BY        VARCHAR(64)     NOT NULL DEFAULT CURRENT USER,
    CREATED_AT        TIMESTAMP       NOT NULL DEFAULT CURRENT TIMESTAMP,
    UPDATED_AT        TIMESTAMP       NOT NULL DEFAULT CURRENT TIMESTAMP,
    CONSTRAINT PK_CUSTOMER_ORDERS PRIMARY KEY (ORDER_ID),
    CONSTRAINT CHK_STATUS CHECK (STATUS IN ('PENDING', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED')),
    CONSTRAINT CHK_AMOUNT CHECK (TOTAL_AMOUNT >= 0)
)
IN USERSPACE1;
