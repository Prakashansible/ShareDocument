"""
Generate db2-ddl-manager module map as a Word document.

Run:
    pip install python-docx
    python generate_map_doc.py

Output: db2_ddl_manager_module_map.docx  (same directory as this script)
"""

from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import docx.opc.constants

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

MONO_FONT = "Courier New"
TITLE_FONT = "Calibri"

DARK_BLUE  = RGBColor(0x1F, 0x49, 0x7D)   # heading colour
MID_BLUE   = RGBColor(0x2E, 0x74, 0xB5)   # sub-heading
BOX_GREY   = RGBColor(0xF2, 0xF2, 0xF2)   # code block background
GREEN      = RGBColor(0x37, 0x86, 0x10)
ORANGE     = RGBColor(0xC5, 0x50, 0x04)
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)


def set_cell_bg(cell, hex_colour: str):
    """Set a table cell background colour (hex string e.g. '1F497D')."""
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_colour)
    tcPr.append(shd)


def add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(text)
    run.bold = True
    if level == 1:
        run.font.size   = Pt(16)
        run.font.color.rgb = DARK_BLUE
    elif level == 2:
        run.font.size   = Pt(13)
        run.font.color.rgb = MID_BLUE
    else:
        run.font.size   = Pt(11)
        run.font.color.rgb = ORANGE
    run.font.name = TITLE_FONT
    return p


def add_code_block(doc: Document, text: str, font_size: int = 7):
    """Add a shaded monospace paragraph for ASCII diagrams."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(0)

    # Grey shading on the paragraph
    pPr  = p._p.get_or_add_pPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  "F2F2F2")
    pPr.append(shd)

    run = p.add_run(text)
    run.font.name = MONO_FONT
    run.font.size = Pt(font_size)
    return p


def add_body(doc: Document, text: str):
    p = doc.add_paragraph(text)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after  = Pt(4)
    for run in p.runs:
        run.font.size = Pt(10)
        run.font.name = TITLE_FONT
    return p


def add_spacer(doc: Document):
    p = doc.add_paragraph("")
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(4)


def add_module_table(doc: Document):
    """Render the module-roles table as a real Word table."""
    rows = [
        ("Module",       "Role & Key Exports",                                                 True),
        ("cli.py",       "Entry point. 7 Click commands. Orchestrates all other modules.\n"
                         "Exports: main(), cli group",                                         False),
        ("config.py",    "Loads/validates inventory.yaml. Resolves DB2_PASSWORD.\n"
                         "Exports: load_config, get_servers_for_env,\n"
                         "         get_filters_for_env, get_db2_password",                    False),
        ("discovery.py", "SSH discovery engine. All 3 modes. Caches to /tmp/.\n"
                         "Exports: discover_topology, parse_db2ilist,\n"
                         "         parse_db_directory, run_remote_command\n"
                         "Dataclasses: DiscoveredServer, DiscoveredInstance, DiscoveredDatabase", False),
        ("connection.py","DB2 connection factory. All 3 SSH modes. Retry logic.\n"
                         "Exports: db2_connection (context manager)\n"
                         "Uses: ibm_db, sshtunnel, paramiko",                                 False),
        ("executor.py",  "Core DDL iteration loop. Idempotency checks. Audit writing.\n"
                         "Exports: execute_create_table, execute_add_columns\n"
                         "Calls: connection, reorg, rollback, logger, report, validators",     False),
        ("validators.py","Stateless DDL file validation. No SSH, no DB2 required.\n"
                         "Exports: validate_ddl_file, parse_alter_columns, DdlType",           False),
        ("reorg.py",     "SYSCAT checks + ADMIN_CMD REORG/RUNSTATS.\n"
                         "Exports: check_reorg_status, run_reorg, run_runstats",               False),
        ("rollback.py",  "Generates DROP TABLE / DROP COLUMN scripts → ddl/rollback/\n"
                         "Exports: generate_create_table_rollback, generate_add_columns_rollback", False),
        ("report.py",    "Rich-formatted summary tables. Stateless renderer.\n"
                         "Exports: print_summary_report, ExecutionSummary,\n"
                         "         DatabaseResult, OperationStatus",                           False),
        ("lockfile.py",  "/tmp/db2ddl_<env>.lock. Stale PID detection. atexit cleanup.\n"
                         "Exports: EnvironmentLock (context manager)",                         False),
        ("logger.py",    "JSON audit log (JSONL) + Rich console. Daily log rotation.\n"
                         "Exports: setup_logging, write_audit_entry",                          False),
    ]

    tbl = doc.add_table(rows=len(rows), cols=2)
    tbl.style = "Table Grid"
    tbl.columns[0].width = Cm(3.8)
    tbl.columns[1].width = Cm(13.4)

    for i, (mod, role, is_header) in enumerate(rows):
        cells = tbl.rows[i].cells
        # Module cell
        cells[0].width = Cm(3.8)
        p0 = cells[0].paragraphs[0]
        run0 = p0.add_run(mod)
        run0.font.name = MONO_FONT
        run0.font.size = Pt(8.5)
        run0.bold = is_header

        # Role cell
        cells[1].width = Cm(13.4)
        p1 = cells[1].paragraphs[0]
        run1 = p1.add_run(role)
        run1.font.name = MONO_FONT
        run1.font.size = Pt(8.5)
        run1.bold = is_header

        if is_header:
            set_cell_bg(cells[0], "1F497D")
            set_cell_bg(cells[1], "1F497D")
            run0.font.color.rgb = WHITE
            run1.font.color.rgb = WHITE
        elif i % 2 == 0:
            set_cell_bg(cells[0], "DEEAF1")
            set_cell_bg(cells[1], "DEEAF1")

    return tbl


# ---------------------------------------------------------------------------
# Content blocks
# ---------------------------------------------------------------------------

MODULE_DEPENDENCY = """\
┌─────────────────────────────────────────────────────────────────────────┐
│                       db2-ddl-manager                                   │
│                   Module Dependency Graph                               │
└─────────────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────────┐
  │                       cli.py  (entry point)                         │
  │  discover | create-table | add-columns | check-status | reorg ...   │
  └──┬──┬──┬──┬──┬──┬──┬──┬──┬──────────────────────────────────────── ┘
     │  │  │  │  │  │  │  │  │
     ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼
  ┌──────┐ ┌──────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
  │config│ │logger│ │discovery │ │ executor │ │ lockfile │ │validators│
  │ .py  │ │ .py  │ │   .py    │ │   .py    │ │   .py    │ │   .py    │
  └──────┘ └──────┘ └────┬─────┘ └────┬─────┘ └──────────┘ └──────────┘
                          │             │
                          │             ├──────────────────► reorg.py
                          │             ├──────────────────► rollback.py
                          │             ├──────────────────► report.py
                          │             ├──────────────────► logger.py
                          │             ├──────────────────► validators.py
                          │             └──────────────────► connection.py
                          │                                       │
                     [paramiko]                             [ibm_db]
                       SSH                                 [sshtunnel]"""

COMMAND_DISCOVER = """\
  cli.discover()
    ├─► config.load_config()           reads inventory.yaml
    ├─► config.get_servers_for_env()   gets server list from YAML
    ├─► config.get_filters_for_env()   gets include/exclude filters
    └─► discovery.discover_topology()
          ├─► discovery._load_cache()              if --use-cache flag
          └─► discovery._discover_server()         per server (parallel-ready)
                ├─► discovery.run_remote_command()
                │     ├─► _run_command_single_hop()   bastion / bastion_direct
                │     └─► _run_command_double_hop()   laptop (nested paramiko)
                ├─► discovery.parse_db2ilist()      parse instance names (1/line)
                ├─► discovery._resolve_instance_port()
                │     └─► run_remote_command() → grep /etc/services
                ├─► discovery._discover_databases()
                │     └─► run_remote_command() → db2 list db directory
                ├─► discovery.parse_db_directory()  keep only Indirect entries
                └─► discovery._save_cache()         → /tmp/db2ddl_<env>_latest.json"""

COMMAND_CREATE = """\
  cli.create_table()
    ├─► config.load_config()
    ├─► validators.validate_ddl_file(DdlType.CREATE)
    │     └─► validators._validate_create()
    ├─► config.get_db2_password()       reads DB2_PASSWORD env var
    └─► cli._run_create_table_for_env()
          ├─► config.get_servers_for_env()
          ├─► config.get_filters_for_env()
          ├─► discovery.discover_topology()
          ├─► cli._safety_confirmation()   beta: y/N   prod: typed confirmation
          ├─► lockfile.EnvironmentLock.__enter__()  → /tmp/db2ddl_<env>.lock
          ├─► executor.execute_create_table()
          │     └─► executor._execute_create_on_db()    per database
          │           ├─► connection.db2_connection()   context manager
          │           │     ├─► _connect_bastion_tunnel()    mode=bastion
          │           │     ├─► _connect_bastion_direct()    mode=bastion_direct
          │           │     └─► _connect_laptop_tunnel()     mode=laptop
          │           ├─► SYSCAT.TABLES query            idempotency check
          │           ├─► cursor.execute(CREATE TABLE)   DDL execution
          │           ├─► reorg.check_reorg_status()
          │           ├─► executor._write_audit()
          │           │     └─► logger.write_audit_entry() → logs/db2ddl_YYYY-MM-DD.log
          │           └─► rollback.generate_create_table_rollback()
          ├─► report.print_summary_report()
          └─► lockfile.EnvironmentLock.__exit__()    deletes lock file"""

COMMAND_ALTER = """\
  cli.add_columns()
    ├─► config.load_config()
    ├─► validators.validate_ddl_file(DdlType.ALTER)
    │     └─► validators._validate_alter()
    ├─► config.get_db2_password()
    ├─► discovery.discover_topology()
    ├─► cli._safety_confirmation()
    ├─► lockfile.EnvironmentLock.__enter__()
    ├─► executor.execute_add_columns()
    │     ├─► validators.parse_alter_columns()    extract ADD COLUMN defs
    │     └─► executor._execute_alter_on_db()    per database
    │           ├─► connection.db2_connection()
    │           ├─► SYSCAT.TABLES query           verify table exists
    │           ├─► SYSCAT.COLUMNS query          per column — existence check
    │           ├─► cursor.execute(ALTER TABLE)   only new columns
    │           ├─► reorg.check_reorg_status()
    │           ├─► reorg.run_reorg()             if --auto-reorg and pending
    │           │     └─► SYSPROC.ADMIN_CMD('REORG TABLE ...')
    │           ├─► reorg.run_runstats()          if --auto-reorg
    │           │     └─► SYSPROC.ADMIN_CMD('RUNSTATS ...')
    │           ├─► executor._write_audit()
    │           └─► rollback.generate_add_columns_rollback()
    ├─► report.print_summary_report()
    └─► lockfile.EnvironmentLock.__exit__()"""

COMMAND_STATUS = """\
  cli.check_status() / cli.reorg()
    ├─► config.load_config()
    ├─► config.get_db2_password()
    ├─► discovery.discover_topology()
    └─► [per database loop in cli]
          ├─► connection.db2_connection()
          ├─► reorg.check_reorg_status()
          │     ├─► SYSCAT.TABLES            row count + last stats time
          │     └─► SYSPROC.ADMIN_GET_TAB_INFO()   reorg_pending flag
          ├─► reorg.run_reorg()              (reorg command only)
          └─► reorg.run_runstats()           (reorg command, --runstats flag)

  cli.validate_ddl()
    └─► validators.validate_ddl_file()    NO SSH, NO DB2 — pure file check

  cli.list_inventory()
    └─► config.load_config()             NO SSH, NO DB2 — YAML read only"""

DATA_FLOW = """\
  inventory.yaml ──► config.py ──► cfg dict (passed everywhere)
                                        │
  $DB2_PASSWORD ─────────────► get_db2_password() ──► string (memory only)
                                                             │
  ddl/*.sql ──► validators.py ──► ValidationResult          │
       │              │                                      │
       │         parse_alter_columns()                       │
       │              │                                      │
       │          [column defs]                              │
       │                                                     │
       ▼                                                     │
  discovery.py                                               │
    SSH (paramiko)                                           │
    ├── db2ilist ──────► instance names                      │
    ├── SVCENAME ──────► port numbers                        │
    └── db2 list db ───► database names ──► list[DiscoveredServer]
                                                     │       │
                                                     ▼       ▼
                                             executor.py
                                               │
                                   ┌───────────┼──────────────┐
                                   ▼           ▼              ▼
                            connection.py  SYSCAT.*      reorg.py
                            (ibm_db +      queries       ADMIN_CMD
                            sshtunnel)     idempotency   REORG/RUNSTATS
                                   │
                                   ▼
                            DatabaseResult ──► ExecutionSummary
                                   │                  │
                                   ▼                  ▼
                            logger.py           report.py
                            (JSONL audit)       (Rich table)
                                   │
                                   ▼
                            logs/db2ddl_YYYY-MM-DD.log

                            rollback.py ──► ddl/rollback/*.sql"""

SSH_MODES = """\
  execution_mode (from inventory.yaml)
         │
         ├─── "bastion" ─────────────────────────────────────────────────────┐
         │    Tool ON bastion                                                 │
         │    Discovery:  paramiko ──SSH──► target:22 ──► db2ilist           │
         │    DB2 conn:   sshtunnel ──SSH──► target:22                       │
         │                └── tunnel localhost:random → target:50000          │
         │                └── ibm_db connects to localhost:random             │
         │                                                                    │
         ├─── "bastion_direct" ──────────────────────────────────────────────┤
         │    Tool ON bastion                                                 │
         │    Discovery:  paramiko ──SSH──► target:22 ──► db2ilist           │
         │    DB2 conn:   ibm_db ──TCP──► target:50000  (no tunnel)          │
         │                                                                    │
         └─── "laptop" ──────────────────────────────────────────────────────┘
              Tool on LAPTOP
              Discovery:  paramiko ──SSH──► bastion:22
                           └── open channel ──► target:22 ──► db2ilist
              DB2 conn:   sshtunnel ──SSH──► bastion:22
                           └── remote_bind = (target, 50000)
                           localhost:random ──► bastion ──► target:50000
                           ibm_db connects to localhost:random

  ─────────────────────────────────────────────────────────────────────────
  connection.db2_connection()
    ├─ mode="bastion"        → _connect_bastion_tunnel()  → SSHTunnelForwarder → ibm_db
    ├─ mode="bastion_direct" → _connect_bastion_direct()  → ibm_db (direct TCP)
    └─ mode="laptop"         → _connect_laptop_tunnel()   → SSHTunnelForwarder → ibm_db

  discovery.run_remote_command()
    ├─ mode="bastion"        → _run_command_single_hop()  → paramiko.SSHClient
    ├─ mode="bastion_direct" → _run_command_single_hop()  → paramiko.SSHClient
    └─ mode="laptop"         → _run_command_double_hop()  → paramiko (nested channels)"""

SCHEMA_CONVENTION = """\
  Database name ──► Schema = "ZPS" + DATABASE_NAME

  Examples:
    DEVDB1   →  ZPSDEVDB1   →  ZPSDEVDB1.CUSTOMER_ORDERS
    BETADB3  →  ZPSBETADB3  →  ZPSBETADB3.CUSTOMER_ORDERS
    PRODDB7  →  ZPSPRODDB7  →  ZPSPRODDB7.CUSTOMER_ORDERS

  DDL placeholder substitution (per database, per execution):
    {schema}      → ZPS + database_name      e.g.  ZPSDEVDB1
    {database}    → database name            e.g.  DEVDB1
    {instance}    → DB2 instance name        e.g.  db2inst1
    {server}      → server hostname          e.g.  devdb01.example.com
    {environment} → environment              e.g.  dev"""

SAFETY_TIERS = """\
  Check                              Dev    Beta   Prod
  ─────────────────────────────────────────────────────
  DDL validation                      ✓      ✓      ✓
  Lock file protection                ✓      ✓      ✓
  Dry-run recommended in help         ✓      ✓      ✓
  Discovery before execution          ✓      ✓      ✓
  Confirmation prompt                 —      ✓      ✓
  Backup confirmation                 —      —      ✓
  Double confirmation (type text)     —      —      ✓

  Beta prompt:
    ⚠  You are targeting BETA environment.
       Targeting: N database(s)
       Proceed? [y/N]:

  Prod prompt:
    🔴 WARNING: You are targeting PRODUCTION environment.
       Have you confirmed that backups are current? [y/N]:
       Type 'CONFIRM PRODUCTION' to proceed:"""

EXIT_CODES = """\
  Code  Meaning
  ────────────────────────────────────────────────────
  0     All operations succeeded (or all skipped)
  1     Partial failure (some databases failed)
  2     Aborted (--fail-fast triggered)
  3     Configuration error (bad YAML / missing env var)
  4     Lock conflict (environment already locked)
  5     DDL validation error (bad SQL file)
  6     Discovery failed (no reachable servers)"""


# ---------------------------------------------------------------------------
# Build the document
# ---------------------------------------------------------------------------

def build_document() -> Document:
    doc = Document()

    # Page margins
    for section in doc.sections:
        section.top_margin    = Cm(1.8)
        section.bottom_margin = Cm(1.8)
        section.left_margin   = Cm(2.0)
        section.right_margin  = Cm(2.0)

    # ── Cover title ──────────────────────────────────────────────────────────
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tr = title.add_run("db2-ddl-manager")
    tr.font.name  = TITLE_FONT
    tr.font.size  = Pt(26)
    tr.font.bold  = True
    tr.font.color.rgb = DARK_BLUE

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sr = sub.add_run("Module & Function Connection Map")
    sr.font.name  = TITLE_FONT
    sr.font.size  = Pt(14)
    sr.font.color.rgb = MID_BLUE

    doc.add_paragraph()

    # ── 1. Module Dependency ─────────────────────────────────────────────────
    add_heading(doc, "1. Module Dependency Graph", 1)
    add_body(doc,
        "cli.py is the sole orchestrator — the only module that imports from all others. "
        "executor.py acts as a second-level orchestrator below cli.py for DDL execution. "
        "All other modules are single-responsibility units with no cross-sibling imports.")
    add_code_block(doc, MODULE_DEPENDENCY, font_size=7)
    add_spacer(doc)

    # ── 2. Command → Function call maps ─────────────────────────────────────
    add_heading(doc, "2. Command → Module → Function Call Maps", 1)
    add_body(doc,
        "Each CLI command follows the same pattern: load config → validate DDL → "
        "discover topology → confirm (beta/prod) → acquire lock → execute → report → release lock.")

    add_heading(doc, "2.1  db2ddl discover", 2)
    add_code_block(doc, COMMAND_DISCOVER, font_size=7.5)
    add_spacer(doc)

    add_heading(doc, "2.2  db2ddl create-table", 2)
    add_code_block(doc, COMMAND_CREATE, font_size=7.5)
    add_spacer(doc)

    add_heading(doc, "2.3  db2ddl add-columns", 2)
    add_code_block(doc, COMMAND_ALTER, font_size=7.5)
    add_spacer(doc)

    add_heading(doc, "2.4  db2ddl check-status / reorg / validate-ddl / list-inventory", 2)
    add_code_block(doc, COMMAND_STATUS, font_size=7.5)
    add_spacer(doc)

    # ── 3. Data Flow ─────────────────────────────────────────────────────────
    add_heading(doc, "3. Runtime Data Flow", 1)
    add_body(doc,
        "Shows how data moves from static files and environment variables, "
        "through discovery (SSH), into the executor, and out to logs, "
        "reports, and rollback scripts.")
    add_code_block(doc, DATA_FLOW, font_size=7.5)
    add_spacer(doc)

    # ── 4. SSH + Connection mode routing ─────────────────────────────────────
    add_heading(doc, "4. SSH & Connection Mode Routing", 1)
    add_body(doc,
        "execution_mode in inventory.yaml controls how both discovery SSH commands "
        "and DB2 database connections are established. "
        "The same context manager (db2_connection) is used everywhere — "
        "the routing is transparent to the executor.")
    add_code_block(doc, SSH_MODES, font_size=7.5)
    add_spacer(doc)

    # ── 5. Schema Convention ─────────────────────────────────────────────────
    add_heading(doc, "5. Schema Naming & DDL Placeholder Substitution", 1)
    add_body(doc,
        "Schema names are deterministically derived — never stored in config. "
        "All placeholders in DDL files are substituted per-database at execution time.")
    add_code_block(doc, SCHEMA_CONVENTION, font_size=8)
    add_spacer(doc)

    # ── 6. Safety Tiers ──────────────────────────────────────────────────────
    add_heading(doc, "6. Safety Tiers by Environment", 1)
    add_body(doc,
        "Dev requires no confirmation. Beta requires a y/N prompt. "
        "Prod requires backup confirmation plus typing the exact string "
        "'CONFIRM PRODUCTION'.")
    add_code_block(doc, SAFETY_TIERS, font_size=8)
    add_spacer(doc)

    # ── 7. Exit Codes ────────────────────────────────────────────────────────
    add_heading(doc, "7. Exit Codes", 1)
    add_code_block(doc, EXIT_CODES, font_size=8)
    add_spacer(doc)

    # ── 8. Module Roles Table ────────────────────────────────────────────────
    add_heading(doc, "8. Module Roles at a Glance", 1)
    add_body(doc,
        "Quick reference: what each module owns and what it exports.")
    add_module_table(doc)

    return doc


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    try:
        from docx import Document as _check
    except ImportError:
        print("python-docx not installed. Run:  pip install python-docx")
        raise SystemExit(1)

    out_path = Path(__file__).parent / "db2_ddl_manager_module_map.docx"
    doc = build_document()
    doc.save(out_path)
    print(f"✓ Document saved: {out_path}")
