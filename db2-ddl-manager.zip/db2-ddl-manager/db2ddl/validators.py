"""DDL file pre-validation for db2-ddl-manager."""

import re
import sys
from enum import Enum
from pathlib import Path
from typing import NamedTuple, Optional


class DdlType(str, Enum):
    CREATE = "create"
    ALTER = "alter"


class ValidationError(NamedTuple):
    line_number: Optional[int]
    message: str


class ValidationResult(NamedTuple):
    valid: bool
    errors: list[ValidationError]
    warnings: list[str]
    columns: list[str]  # for ALTER files, the column names being added


VALID_DB2_TYPES = {
    "BIGINT", "INT", "INTEGER", "SMALLINT", "DECIMAL", "NUMERIC",
    "REAL", "DOUBLE", "FLOAT", "CHAR", "CHARACTER", "VARCHAR",
    "CLOB", "BLOB", "GRAPHIC", "VARGRAPHIC", "DATE", "TIME",
    "TIMESTAMP", "BOOLEAN", "DECFLOAT", "BINARY", "VARBINARY",
    "XML", "ROWID",
}

DANGEROUS_PATTERNS = [
    (r'\bDROP\s+TABLE\b', "DROP TABLE"),
    (r'\bDROP\s+DATABASE\b', "DROP DATABASE"),
    (r'\bTRUNCATE\b', "TRUNCATE"),
    (r'\bDELETE\s+FROM\b', "DELETE FROM"),
    (r'\bDROP\s+SCHEMA\b', "DROP SCHEMA"),
    (r'\bDROP\s+TABLESPACE\b', "DROP TABLESPACE"),
]


def validate_ddl_file(file_path: str, ddl_type: DdlType) -> ValidationResult:
    """
    Validate a DDL file for syntax issues without connecting to any database.

    Args:
        file_path: Path to the DDL file.
        ddl_type: Type of DDL -- 'create' or 'alter'.

    Returns:
        ValidationResult with valid flag, errors, warnings, and discovered column names.
    """
    path = Path(file_path)
    errors: list[ValidationError] = []
    warnings: list[str] = []
    columns: list[str] = []

    # File existence check
    if not path.exists():
        return ValidationResult(
            valid=False,
            errors=[ValidationError(None, f"DDL file not found: {file_path}")],
            warnings=[],
            columns=[],
        )

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as e:
        return ValidationResult(
            valid=False,
            errors=[ValidationError(None, f"Cannot read DDL file: {e}")],
            warnings=[],
            columns=[],
        )

    if not content.strip():
        errors.append(ValidationError(None, "DDL file is empty"))
        return ValidationResult(valid=False, errors=errors, warnings=warnings, columns=columns)

    lines = content.splitlines()

    # Check for dangerous statements
    for i, line in enumerate(lines, start=1):
        upper = line.upper()
        for pattern, label in DANGEROUS_PATTERNS:
            if re.search(pattern, upper):
                errors.append(ValidationError(i, f"Dangerous statement detected: {label}"))

    # Type-specific checks
    if ddl_type == DdlType.CREATE:
        columns, create_errors, create_warnings = _validate_create(content, lines)
        errors.extend(create_errors)
        warnings.extend(create_warnings)
    elif ddl_type == DdlType.ALTER:
        columns, alter_errors, alter_warnings = _validate_alter(content, lines)
        errors.extend(alter_errors)
        warnings.extend(alter_warnings)

    return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings, columns=columns)


def _validate_create(content: str, lines: list[str]) -> tuple[list[str], list[ValidationError], list[str]]:
    """Validate a CREATE TABLE DDL file."""
    errors: list[ValidationError] = []
    warnings: list[str] = []
    columns: list[str] = []
    upper_content = content.upper()

    if "CREATE TABLE" not in upper_content:
        errors.append(ValidationError(None, "Expected 'CREATE TABLE' keyword not found"))

    if "{schema}" not in content and "{SCHEMA}" not in content.upper():
        errors.append(ValidationError(None, "DDL file must contain the {schema} placeholder"))

    # Extract and validate column definitions
    # Find content between outer parentheses
    paren_match = re.search(r'\((.+)\)', content, re.DOTALL)
    if paren_match:
        col_defs = paren_match.group(1)
        for i, line in enumerate(col_defs.splitlines(), start=1):
            stripped = line.strip().rstrip(",")
            if not stripped or stripped.upper().startswith("PRIMARY KEY") or stripped.upper().startswith("CONSTRAINT"):
                continue
            parts = stripped.split()
            if len(parts) >= 2:
                col_name = parts[0].strip('"')
                col_type = re.sub(r'\(.*\)', '', parts[1]).upper()
                if col_type not in VALID_DB2_TYPES:
                    warnings.append(f"Column '{col_name}': unrecognized type '{parts[1]}' -- verify it is a valid DB2 type")
                columns.append(col_name)

    return columns, errors, warnings


def _validate_alter(content: str, lines: list[str]) -> tuple[list[str], list[ValidationError], list[str]]:
    """Validate an ALTER TABLE (add-columns) DDL file."""
    errors: list[ValidationError] = []
    warnings: list[str] = []
    columns: list[str] = []
    upper_content = content.upper()

    if "ADD COLUMN" not in upper_content:
        errors.append(ValidationError(None, "ALTER DDL file must contain at least one 'ADD COLUMN' clause"))

    if "CREATE TABLE" in upper_content or "ALTER TABLE" in upper_content:
        warnings.append(
            "ALTER DDL file should contain ONLY column definitions (ADD COLUMN ...), "
            "NOT the full 'ALTER TABLE <name>' prefix -- the tool adds that automatically"
        )

    # Extract column names from ADD COLUMN lines
    for i, line in enumerate(lines, start=1):
        stripped = line.strip()
        match = re.match(r'ADD\s+COLUMN\s+(\w+)\s+(\S+)', stripped, re.IGNORECASE)
        if match:
            col_name = match.group(1)
            col_type = re.sub(r'\(.*\)', '', match.group(2)).upper()
            columns.append(col_name.upper())
            if col_type not in VALID_DB2_TYPES:
                warnings.append(
                    f"Line {i}: Column '{col_name}': unrecognized type '{match.group(2)}' -- verify it is a valid DB2 type"
                )

    return columns, errors, warnings


def parse_alter_columns(ddl_content: str) -> list[dict[str, str]]:
    """
    Parse ADD COLUMN definitions from an alter DDL file.

    Returns:
        List of dicts with 'name' and 'definition' keys.
        'definition' is the full 'ADD COLUMN ...' clause.
    """
    columns = []
    lines = ddl_content.strip().splitlines()
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("--"):
            continue
        match = re.match(r'(ADD\s+COLUMN\s+(\w+)\s+.+)', stripped, re.IGNORECASE)
        if match:
            columns.append({
                "name": match.group(2).upper(),
                "definition": match.group(1).rstrip(";"),
            })
    return columns
