"""
db2-ddl-manager CLI entry point.

Commands:
  discover        Live topology discovery via SSH (db2ilist, db2 list db directory)
  create-table    CREATE TABLE across all discovered databases
  add-columns     ALTER TABLE ADD COLUMN across all discovered databases
  check-status    Check table reorg/stats status
  reorg           Run REORG (and optionally RUNSTATS) on a table
  list-inventory  Display static YAML inventory config (no SSH)
  validate-ddl    Validate DDL file syntax without connecting to any database
"""

import logging
import os
import platform
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.tree import Tree
from rich import print as rprint

from db2ddl import __version__
from db2ddl.config import (
    ConfigError,
    get_connection_defaults,
    get_db2_password,
    get_filters_for_env,
    get_servers_for_env,
    load_config,
)
from db2ddl.discovery import discover_topology
from db2ddl.executor import execute_add_columns, execute_create_table
from db2ddl.lockfile import EnvironmentLock, LockConflictError
from db2ddl.logger import setup_logging
from db2ddl.reorg import check_reorg_status, run_reorg, run_runstats
from db2ddl.report import DatabaseResult, ExecutionSummary, OperationStatus, print_summary_report
from db2ddl.validators import DdlType, validate_ddl_file
from db2ddl.connection import db2_connection

console = Console()

VALID_ENVIRONMENTS = ("dev", "beta", "prod", "all")


def _validate_env(ctx, param, value):
    if value not in VALID_ENVIRONMENTS:
        raise click.BadParameter(f"Must be one of: {', '.join(VALID_ENVIRONMENTS)}")
    return value


def _load_config_or_exit(config_path: Optional[str]) -> dict:
    try:
        return load_config(config_path)
    except ConfigError as e:
        console.print(f"[red]Configuration Error:[/red] {e}")
        sys.exit(3)


def _check_platform_warnings(config: dict) -> None:
    """Warn if execution_mode doesn't match the detected OS."""
    mode = config.get("execution_mode", "bastion")
    current_os = platform.system()
    if mode in ("bastion", "bastion_direct") and current_os not in ("AIX", "Linux"):
        console.print(
            f"[yellow]Warning: execution_mode='{mode}' is set (expects AIX/Linux bastion), "
            f"but this system is '{current_os}'. "
            f"Consider using execution_mode=laptop if running from a workstation.[/yellow]"
        )


def _check_aix_libpath() -> None:
    """On AIX, warn if LIBPATH is not set (required for ibm_db)."""
    if platform.system() == "AIX":
        libpath = os.environ.get("LIBPATH", "")
        if not libpath:
            console.print(
                "[red]ERROR: LIBPATH is not set. On AIX, ibm_db requires LIBPATH to point to "
                "the DB2 client libraries.[/red]\n"
                "  Set it with:\n"
                "    export IBM_DB_HOME=/opt/IBM/db2/V11.5\n"
                "    export LIBPATH=$IBM_DB_HOME/lib64:$LIBPATH\n"
            )
            sys.exit(3)


@click.group()
@click.version_option(__version__)
@click.option("--log-level", default="INFO", help="Log level (DEBUG, INFO, WARNING, ERROR)")
def cli(log_level: str):
    """db2-ddl-manager: DDL lifecycle manager for DB2 across multiple servers.

    Discovers instances and databases dynamically via SSH (db2ilist + db2 list db directory).
    The DB2 username for each connection is the discovered instance name.
    """
    setup_logging(log_level)
    _check_aix_libpath()


# ---------------------------------------------------------------------------
#  Common options reused across multiple commands
# ---------------------------------------------------------------------------

ENV_OPTION = click.option("--env", required=True, callback=_validate_env, help="Target environment: dev, beta, prod, or all")
DRY_RUN_OPTION = click.option("--dry-run", is_flag=True, default=False, help="Show what would execute without making changes")
FAIL_FAST_OPTION = click.option("--fail-fast", is_flag=True, default=False, help="Stop on first error")
SERVER_OPTION = click.option("--server", default=None, help="Filter to a specific server hostname")
INSTANCE_OPTION = click.option("--instance", default=None, help="Filter to a specific instance name")
DATABASE_OPTION = click.option("--database", default=None, help="Filter to a specific database name")
USE_CACHE_OPTION = click.option("--use-cache", is_flag=True, default=False, help="Use cached discovery results (<15 min old)")
CONFIG_OPTION = click.option("--config", default=None, type=click.Path(), help="Path to inventory YAML (default: config/inventory.yaml)")


# ---------------------------------------------------------------------------
#  discover
# ---------------------------------------------------------------------------

@cli.command()
@ENV_OPTION
@SERVER_OPTION
@USE_CACHE_OPTION
@CONFIG_OPTION
def discover(env: str, server: Optional[str], use_cache: bool, config: Optional[str]):
    """Live topology discovery: SSH -> db2ilist -> db2 list db directory.

    This is the first command to run -- verify SSH connectivity and see what the tool will target.
    Results are cached for 15 minutes for use by subsequent commands with --use-cache.
    """
    cfg = _load_config_or_exit(config)
    _check_platform_warnings(cfg)

    envs_to_discover = list(cfg["environments"].keys()) if env == "all" else [env]

    for target_env in envs_to_discover:
        console.print(f"\n[bold blue]Discovering DB2 topology for environment: {target_env.upper()}[/bold blue]")
        mode = cfg.get("execution_mode", "bastion")
        if mode == "laptop":
            bastion_host = cfg.get("bastion", {}).get("host", "unknown")
            console.print(f"   Via bastion: {bastion_host}")

        servers = get_servers_for_env(cfg, target_env)
        filters = get_filters_for_env(cfg, target_env)

        topology = discover_topology(
            env=target_env,
            servers=servers,
            config=cfg,
            filters=filters,
            use_cache=use_cache,
            server_filter=server,
        )

        # Build and print rich tree
        tree = Tree(f"[bold]Environment: {target_env.upper()}[/bold]")
        total_instances = 0
        total_databases = 0
        reachable = 0
        unreachable = 0

        for srv in topology:
            if srv.reachable:
                reachable += 1
                srv_node = tree.add(f"[cyan]{srv.host}[/cyan]  [green]\\[SSH: OK][/green]")
                for inst in srv.instances:
                    total_instances += 1
                    inst_node = srv_node.add(
                        f"[blue]{inst.name} (port: {inst.port})[/blue]  [dim]\\[discovered via db2ilist][/dim]"
                    )
                    for db in inst.databases:
                        total_databases += 1
                        inst_node.add(f"{db.name}  [dim]-> schema: {db.schema}[/dim]")
            else:
                unreachable += 1
                srv_node = tree.add(f"[cyan]{srv.host}[/cyan]  [red]\\[SSH: UNREACHABLE][/red]")
                srv_node.add(f"[red](discovery failed -- {srv.error_message})[/red]")

        console.print(tree)

        # Filters info
        exclude_inst = filters.get("exclude_instances") or []
        exclude_db = filters.get("exclude_databases") or []
        include_db = filters.get("include_databases") or []
        console.print(f"\n  Filters applied:")
        console.print(f"    exclude_instances: {', '.join(exclude_inst) or '(none)'}")
        console.print(f"    exclude_databases: {', '.join(exclude_db) or '(none)'}")
        if include_db:
            console.print(f"    include_databases: {', '.join(include_db)}")

        console.print(
            f"\n  [bold]Summary:[/bold] {len(topology)} servers | "
            f"{reachable} reachable | {total_instances} instances | {total_databases} databases"
        )
        if unreachable:
            console.print(
                f"  [yellow]Warning: {unreachable} server(s) unreachable -- "
                f"DDL commands will skip them with CONN_FAILED status[/yellow]"
            )


# ---------------------------------------------------------------------------
#  create-table
# ---------------------------------------------------------------------------

@cli.command("create-table")
@ENV_OPTION
@click.option("--ddl-file", required=True, type=click.Path(exists=True), help="Path to CREATE TABLE DDL file")
@DRY_RUN_OPTION
@FAIL_FAST_OPTION
@SERVER_OPTION
@INSTANCE_OPTION
@DATABASE_OPTION
@USE_CACHE_OPTION
@CONFIG_OPTION
def create_table(
    env: str, ddl_file: str, dry_run: bool, fail_fast: bool,
    server: Optional[str], instance: Optional[str], database: Optional[str],
    use_cache: bool, config: Optional[str],
):
    """CREATE TABLE across all discovered databases in the target environment.

    Idempotent: skips databases where the table already exists.
    Auto-generates a rollback (DROP TABLE) script after successful execution.

    Recommended workflow:
      1. db2ddl discover --env dev
      2. db2ddl create-table --env dev --ddl-file ddl/create.sql --dry-run
      3. db2ddl create-table --env dev --ddl-file ddl/create.sql
    """
    cfg = _load_config_or_exit(config)
    _check_platform_warnings(cfg)

    # Validate DDL
    validation = validate_ddl_file(ddl_file, DdlType.CREATE)
    if not validation.valid:
        console.print("[red]DDL Validation Failed:[/red]")
        for err in validation.errors:
            loc = f"Line {err.line_number}: " if err.line_number else ""
            console.print(f"  {loc}{err.message}")
        sys.exit(5)
    if validation.warnings:
        for warn in validation.warnings:
            console.print(f"[yellow]Warning: {warn}[/yellow]")

    # Extract table name from DDL
    ddl_content = Path(ddl_file).read_text(encoding="utf-8")
    table_match = re.search(r'CREATE\s+TABLE\s+\{schema\}\.(\w+)', ddl_content, re.IGNORECASE)
    if not table_match:
        console.print("[red]Cannot extract table name from DDL. Ensure format: CREATE TABLE {schema}.TABLENAME[/red]")
        sys.exit(5)
    table_name = table_match.group(1).upper()

    # Validate credentials
    if not dry_run:
        get_db2_password(cfg)

    envs_to_run = list(cfg["environments"].keys()) if env == "all" else [env]

    for target_env in envs_to_run:
        _run_create_table_for_env(
            env=target_env, cfg=cfg, ddl_content=ddl_content, table_name=table_name,
            dry_run=dry_run, fail_fast=fail_fast, server=server,
            instance=instance, database=database, use_cache=use_cache,
        )


def _run_create_table_for_env(
    env: str, cfg: dict, ddl_content: str, table_name: str,
    dry_run: bool, fail_fast: bool, server: Optional[str],
    instance: Optional[str], database: Optional[str], use_cache: bool,
):
    """Run create-table for a single environment."""
    servers = get_servers_for_env(cfg, env)
    filters = get_filters_for_env(cfg, env)

    console.print(f"\n[bold]Environment: {env.upper()}[/bold]")

    # Discover topology
    topology = discover_topology(
        env=env, servers=servers, config=cfg, filters=filters,
        use_cache=use_cache, server_filter=server,
    )

    total_dbs = sum(
        len(inst.databases) for srv in topology if srv.reachable for inst in srv.instances
    )
    console.print(f"  Discovered: {len(topology)} servers | {total_dbs} target databases")

    # Safety confirmation for beta/prod
    if not dry_run:
        if not _safety_confirmation(env, total_dbs, table_name):
            console.print("[yellow]Aborted by user.[/yellow]")
            return

    # Acquire lock and execute
    try:
        with EnvironmentLock(env, f"create-table --table {table_name}"):
            summary = execute_create_table(
                ddl_content=ddl_content,
                table_name=table_name,
                topology=topology,
                config=cfg,
                environment=env,
                dry_run=dry_run,
                fail_fast=fail_fast,
                instance_filter=instance,
                database_filter=database,
            )
    except LockConflictError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(4)

    print_summary_report(summary)

    # Exit code
    if summary.failed_count > 0:
        sys.exit(1)


# ---------------------------------------------------------------------------
#  add-columns
# ---------------------------------------------------------------------------

@cli.command("add-columns")
@ENV_OPTION
@click.option("--table", required=True, help="Table name (without schema prefix)")
@click.option("--ddl-file", required=True, type=click.Path(exists=True), help="DDL file with ADD COLUMN definitions")
@click.option("--auto-reorg", is_flag=True, default=False, help="Automatically run REORG+RUNSTATS if reorg pending")
@DRY_RUN_OPTION
@FAIL_FAST_OPTION
@SERVER_OPTION
@INSTANCE_OPTION
@DATABASE_OPTION
@USE_CACHE_OPTION
@CONFIG_OPTION
def add_columns(
    env: str, table: str, ddl_file: str, auto_reorg: bool,
    dry_run: bool, fail_fast: bool,
    server: Optional[str], instance: Optional[str], database: Optional[str],
    use_cache: bool, config: Optional[str],
):
    """ALTER TABLE ADD COLUMN across all discovered databases.

    The DDL file should contain ONLY column definitions (ADD COLUMN ...),
    NOT the full 'ALTER TABLE <name>' prefix -- the tool adds that automatically.

    Idempotent: skips columns that already exist, skips tables that don't exist.
    Auto-generates a rollback (DROP COLUMN) script after successful execution.
    """
    cfg = _load_config_or_exit(config)
    _check_platform_warnings(cfg)

    # Validate DDL
    validation = validate_ddl_file(ddl_file, DdlType.ALTER)
    if not validation.valid:
        console.print("[red]DDL Validation Failed:[/red]")
        for err in validation.errors:
            loc = f"Line {err.line_number}: " if err.line_number else ""
            console.print(f"  {loc}{err.message}")
        sys.exit(5)
    if validation.warnings:
        for warn in validation.warnings:
            console.print(f"[yellow]Warning: {warn}[/yellow]")

    ddl_content = Path(ddl_file).read_text(encoding="utf-8")
    table_name = table.upper()

    if not dry_run:
        get_db2_password(cfg)

    envs_to_run = list(cfg["environments"].keys()) if env == "all" else [env]

    for target_env in envs_to_run:
        servers = get_servers_for_env(cfg, target_env)
        filters = get_filters_for_env(cfg, target_env)

        console.print(f"\n[bold]Environment: {target_env.upper()}[/bold]")

        topology = discover_topology(
            env=target_env, servers=servers, config=cfg, filters=filters,
            use_cache=use_cache, server_filter=server,
        )

        total_dbs = sum(
            len(inst.databases) for srv in topology if srv.reachable for inst in srv.instances
        )
        console.print(f"  Discovered: {len(topology)} servers | {total_dbs} target databases")

        if not dry_run:
            if not _safety_confirmation(target_env, total_dbs, f"add-columns on {table_name}"):
                console.print("[yellow]Aborted by user.[/yellow]")
                continue

        try:
            with EnvironmentLock(target_env, f"add-columns --table {table_name}"):
                summary = execute_add_columns(
                    ddl_content=ddl_content,
                    table_name=table_name,
                    topology=topology,
                    config=cfg,
                    environment=target_env,
                    dry_run=dry_run,
                    fail_fast=fail_fast,
                    auto_reorg=auto_reorg,
                    instance_filter=instance,
                    database_filter=database,
                )
        except LockConflictError as e:
            console.print(f"[red]{e}[/red]")
            sys.exit(4)

        print_summary_report(summary)

        if summary.failed_count > 0:
            sys.exit(1)


# ---------------------------------------------------------------------------
#  check-status
# ---------------------------------------------------------------------------

@cli.command("check-status")
@ENV_OPTION
@click.option("--table", required=True, help="Table name (without schema prefix)")
@SERVER_OPTION
@INSTANCE_OPTION
@DATABASE_OPTION
@USE_CACHE_OPTION
@CONFIG_OPTION
def check_status(
    env: str, table: str,
    server: Optional[str], instance: Optional[str], database: Optional[str],
    use_cache: bool, config: Optional[str],
):
    """Check table reorg/stats status across all discovered databases."""
    from rich.table import Table as RichTable
    from rich import box

    cfg = _load_config_or_exit(config)
    _check_platform_warnings(cfg)
    get_db2_password(cfg)

    table_name = table.upper()
    envs_to_run = list(cfg["environments"].keys()) if env == "all" else [env]

    for target_env in envs_to_run:
        servers = get_servers_for_env(cfg, target_env)
        filters = get_filters_for_env(cfg, target_env)
        topology = discover_topology(
            env=target_env, servers=servers, config=cfg, filters=filters,
            use_cache=use_cache, server_filter=server,
        )

        console.print(f"\n[bold]Check Status: {table_name} -- {target_env.upper()}[/bold]")

        rich_table = RichTable(box=box.DOUBLE_EDGE, show_header=True, header_style="bold cyan")
        rich_table.add_column("Server")
        rich_table.add_column("Instance")
        rich_table.add_column("Database")
        rich_table.add_column("Reorg Status", justify="center")
        rich_table.add_column("Last Stats")

        ok_count = 0
        failed_count = 0
        pending_count = 0

        for srv in topology:
            if not srv.reachable:
                rich_table.add_row(srv.host, "--", "--", "[red]UNREACHABLE[/red]", "N/A")
                failed_count += 1
                continue

            for inst in srv.instances:
                if instance and inst.name != instance:
                    continue
                for db in inst.databases:
                    if database and db.name != database:
                        continue
                    schema = db.schema
                    try:
                        with db2_connection(srv.host, inst.port, db.name, inst.name, cfg) as conn:
                            status = check_reorg_status(conn, schema, table_name)
                        if status.error:
                            reorg_display = "[red]ERROR[/red]"
                            failed_count += 1
                        elif status.pending:
                            reorg_display = "[yellow]PENDING[/yellow]"
                            pending_count += 1
                        else:
                            reorg_display = "[green]OK[/green]"
                            ok_count += 1
                        stats_display = str(status.last_stats)[:10] if status.last_stats else "N/A"
                    except Exception as e:
                        reorg_display = "[red]CONN FAIL[/red]"
                        stats_display = "N/A"
                        failed_count += 1

                    rich_table.add_row(
                        srv.host.split(".")[0],
                        inst.name,
                        db.name,
                        reorg_display,
                        stats_display,
                    )

        console.print(rich_table)
        console.print(
            f"  Reorg Pending: [yellow]{pending_count}[/yellow] | "
            f"OK: [green]{ok_count}[/green] | "
            f"Connection Failed: [red]{failed_count}[/red]"
        )


# ---------------------------------------------------------------------------
#  reorg
# ---------------------------------------------------------------------------

@cli.command()
@ENV_OPTION
@click.option("--table", required=True, help="Table name (without schema prefix)")
@click.option("--only-pending", is_flag=True, default=False, help="Only REORG databases where reorg is pending")
@click.option("--runstats", is_flag=True, default=False, help="Run RUNSTATS after REORG completes")
@DRY_RUN_OPTION
@SERVER_OPTION
@INSTANCE_OPTION
@DATABASE_OPTION
@USE_CACHE_OPTION
@CONFIG_OPTION
def reorg(
    env: str, table: str, only_pending: bool, runstats: bool, dry_run: bool,
    server: Optional[str], instance: Optional[str], database: Optional[str],
    use_cache: bool, config: Optional[str],
):
    """Run REORG (and optionally RUNSTATS) on a table across targeted databases."""
    cfg = _load_config_or_exit(config)
    _check_platform_warnings(cfg)
    get_db2_password(cfg)

    table_name = table.upper()
    envs_to_run = list(cfg["environments"].keys()) if env == "all" else [env]

    for target_env in envs_to_run:
        servers = get_servers_for_env(cfg, target_env)
        filters = get_filters_for_env(cfg, target_env)
        topology = discover_topology(
            env=target_env, servers=servers, config=cfg, filters=filters,
            use_cache=use_cache, server_filter=server,
        )

        console.print(f"\n[bold]REORG: {table_name} -- {target_env.upper()}[/bold]")

        for srv in topology:
            if not srv.reachable:
                continue
            for inst in srv.instances:
                if instance and inst.name != instance:
                    continue
                for db in inst.databases:
                    if database and db.name != database:
                        continue
                    schema = db.schema
                    try:
                        with db2_connection(srv.host, inst.port, db.name, inst.name, cfg) as conn:
                            status = check_reorg_status(conn, schema, table_name)
                            if only_pending and not status.pending:
                                console.print(f"  [dim]SKIP {db.name}@{srv.host} -- reorg not pending[/dim]")
                                continue
                            if dry_run:
                                console.print(f"  [blue][DRY RUN] Would REORG {schema}.{table_name} on {db.name}@{srv.host}[/blue]")
                                if runstats:
                                    console.print(f"  [blue][DRY RUN] Would RUNSTATS {schema}.{table_name} on {db.name}@{srv.host}[/blue]")
                                continue
                            reorg_ok = run_reorg(conn, schema, table_name)
                            if reorg_ok:
                                console.print(f"  [green]REORG OK: {db.name}@{srv.host}[/green]")
                                if runstats:
                                    run_runstats(conn, schema, table_name)
                                    console.print(f"  [green]RUNSTATS OK: {db.name}@{srv.host}[/green]")
                            else:
                                console.print(f"  [red]REORG FAILED: {db.name}@{srv.host}[/red]")
                    except Exception as e:
                        console.print(f"  [red]CONN_FAILED: {db.name}@{srv.host}: {e}[/red]")


# ---------------------------------------------------------------------------
#  list-inventory
# ---------------------------------------------------------------------------

@cli.command("list-inventory")
@ENV_OPTION
@CONFIG_OPTION
def list_inventory(env: str, config: Optional[str]):
    """Display the static YAML inventory config. Does NOT connect to any server.

    Use 'db2ddl discover' for live topology.
    """
    cfg = _load_config_or_exit(config)

    console.print("\n[bold blue]Inventory Configuration (from inventory.yaml)[/bold blue]\n")

    mode = cfg.get("execution_mode", "bastion")
    console.print(f"  Execution Mode: [cyan]{mode}[/cyan]")

    if mode == "laptop":
        bastion = cfg.get("bastion", {})
        console.print(f"\n  Bastion: {bastion.get('host', 'N/A')} "
                      f"(port: {bastion.get('port', 22)}, user: {bastion.get('user', 'N/A')})")
    else:
        console.print(f"\n  [dim](Bastion config ignored -- tool runs in '{mode}' mode on this host)[/dim]")

    creds = cfg.get("db2_credentials", {})
    console.print(f"  Credentials: UID = <instance_name> (from db2ilist) / "
                  f"PWD = {creds.get('password_var', 'DB2_PASSWORD')} (from env var)")

    environments = cfg.get("environments", {})
    envs_to_show = list(environments.keys()) if env == "all" else [env]

    for env_name in envs_to_show:
        env_cfg = environments.get(env_name)
        if not env_cfg:
            console.print(f"  [red]Environment '{env_name}' not found in inventory[/red]")
            continue

        servers = env_cfg.get("servers", [])
        filters = env_cfg.get("filters", {})

        console.print(f"\n  [bold green]Environment: {env_name.upper()}[/bold green]")
        console.print(f"    Servers ({len(servers)}):")
        for i, srv in enumerate(servers, start=1):
            console.print(f"      {i}. {srv.get('host', 'N/A')}")

        if filters:
            console.print("    Filters:")
            exc_inst = filters.get("exclude_instances") or []
            exc_db = filters.get("exclude_databases") or []
            inc_db = filters.get("include_databases") or []
            console.print(f"      exclude_instances: {', '.join(exc_inst) or '(none)'}")
            console.print(f"      exclude_databases: {', '.join(exc_db) or '(none)'}")
            if inc_db:
                console.print(f"      include_databases: {', '.join(inc_db)}")
        else:
            console.print("    Filters: (none -- all discovered instances/databases are targeted)")


# ---------------------------------------------------------------------------
#  validate-ddl
# ---------------------------------------------------------------------------

@cli.command("validate-ddl")
@click.option("--ddl-file", required=True, type=click.Path(), help="Path to DDL file to validate")
@click.option("--type", "ddl_type", required=True, type=click.Choice(["create", "alter"]), help="Type of DDL: create or alter")
def validate_ddl(ddl_file: str, ddl_type: str):
    """Validate a DDL file for syntax issues without connecting to any database.

    Checks for:
      - File existence and readability
      - Required keywords (CREATE TABLE, ADD COLUMN)
      - {schema} placeholder presence
      - Dangerous statements (DROP, TRUNCATE, DELETE)
      - Valid DB2 data types
    """
    dtype = DdlType.CREATE if ddl_type == "create" else DdlType.ALTER
    result = validate_ddl_file(ddl_file, dtype)

    console.print(f"\n[bold]Validating:[/bold] {ddl_file}  [dim](type: {ddl_type})[/dim]")

    if result.valid:
        console.print("[green]DDL file is valid[/green]")
        if result.columns:
            console.print(f"  Columns detected: {', '.join(result.columns)}")
    else:
        console.print(f"[red]DDL validation failed ({len(result.errors)} error(s)):[/red]")
        for err in result.errors:
            loc = f"Line {err.line_number}: " if err.line_number else ""
            console.print(f"  [red]{loc}{err.message}[/red]")

    if result.warnings:
        console.print(f"[yellow]Warnings ({len(result.warnings)}):[/yellow]")
        for warn in result.warnings:
            console.print(f"  [yellow]{warn}[/yellow]")

    sys.exit(0 if result.valid else 5)


# ---------------------------------------------------------------------------
#  Safety confirmation helpers
# ---------------------------------------------------------------------------

def _safety_confirmation(env: str, total_dbs: int, operation: str) -> bool:
    """
    Show safety confirmation prompts for beta and prod environments.

    Returns True if the user confirms, False if they abort.
    """
    if env == "dev":
        return True

    if env == "beta":
        console.print(f"\n[yellow]Warning: You are targeting BETA environment.[/yellow]")
        console.print(f"   Targeting: {total_dbs} database(s) with: {operation}")
        answer = click.prompt("   Proceed?", default="N").strip().upper()
        return answer in ("Y", "YES")

    if env == "prod":
        console.print(f"\n[bold red]WARNING: You are targeting PRODUCTION environment.[/bold red]")
        console.print(f"   Targeting: {total_dbs} database(s) with: {operation}")
        backup_answer = click.prompt("\n   Have you confirmed that backups are current?", default="N").strip().upper()
        if backup_answer not in ("Y", "YES"):
            return False
        confirm_text = click.prompt("\n   Type 'CONFIRM PRODUCTION' to proceed").strip()
        return confirm_text == "CONFIRM PRODUCTION"

    return True


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

def main():
    """Main entry point for the db2ddl CLI."""
    cli()


if __name__ == "__main__":
    main()
