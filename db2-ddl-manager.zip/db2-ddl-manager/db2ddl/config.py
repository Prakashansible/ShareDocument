"""YAML inventory loader and validator for db2-ddl-manager."""

import os
import sys
from pathlib import Path
from typing import Any, Optional

import yaml

DEFAULT_CONFIG_PATH = Path(__file__).parent.parent / "config" / "inventory.yaml"

VALID_EXECUTION_MODES = {"bastion", "bastion_direct", "laptop"}
VALID_ENVIRONMENTS = {"dev", "beta", "prod"}


class ConfigError(Exception):
    """Raised when the inventory YAML is invalid or missing required fields."""


def load_config(config_path: Optional[Path] = None) -> dict[str, Any]:
    """
    Load and validate the inventory YAML file.

    Args:
        config_path: Path to inventory.yaml. Defaults to config/inventory.yaml.

    Returns:
        Parsed and validated config dict.

    Raises:
        ConfigError: If the file is missing, unreadable, or fails validation.
    """
    path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
    if not path.exists():
        raise ConfigError(
            f"Inventory file not found: {path}\n"
            f"Copy config/inventory.example.yaml to config/inventory.yaml and edit it."
        )

    try:
        with open(path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigError(f"Failed to parse inventory YAML: {e}") from e

    if not isinstance(config, dict):
        raise ConfigError("Inventory YAML must be a mapping at the top level.")

    _validate_config(config)
    return config


def _validate_config(config: dict[str, Any]) -> None:
    """Validate required fields in the inventory config."""
    # execution_mode
    mode = config.get("execution_mode")
    if mode not in VALID_EXECUTION_MODES:
        raise ConfigError(
            f"Invalid execution_mode '{mode}'. Must be one of: {', '.join(VALID_EXECUTION_MODES)}"
        )

    # bastion section required only for laptop mode
    if mode == "laptop":
        bastion = config.get("bastion")
        if not bastion or not isinstance(bastion, dict):
            raise ConfigError("execution_mode=laptop requires a 'bastion' section in inventory.yaml")
        for field in ("host", "port", "user", "key_file"):
            if field not in bastion:
                raise ConfigError(f"bastion.{field} is required when execution_mode=laptop")

    # target_ssh
    target_ssh = config.get("target_ssh")
    if not target_ssh or not isinstance(target_ssh, dict):
        raise ConfigError("'target_ssh' section is required in inventory.yaml")
    for field in ("user", "key_file", "port"):
        if field not in target_ssh:
            raise ConfigError(f"target_ssh.{field} is required")

    # db2_credentials
    creds = config.get("db2_credentials")
    if not creds or not isinstance(creds, dict):
        raise ConfigError("'db2_credentials' section is required in inventory.yaml")
    if "password_var" not in creds:
        raise ConfigError("db2_credentials.password_var is required")

    # environments
    environments = config.get("environments")
    if not environments or not isinstance(environments, dict):
        raise ConfigError("'environments' section with at least one environment is required")

    for env_name, env_cfg in environments.items():
        if env_name not in VALID_ENVIRONMENTS:
            raise ConfigError(f"Unknown environment '{env_name}'. Must be one of: {', '.join(VALID_ENVIRONMENTS)}")
        if not env_cfg or not isinstance(env_cfg, dict):
            raise ConfigError(f"Environment '{env_name}' must be a mapping with a 'servers' list")
        servers = env_cfg.get("servers")
        if not servers or not isinstance(servers, list) or len(servers) == 0:
            raise ConfigError(f"Environment '{env_name}' must have at least one server in 'servers'")
        for server in servers:
            if not isinstance(server, dict) or "host" not in server:
                raise ConfigError(
                    f"Each server in environment '{env_name}' must be a mapping with a 'host' key"
                )


def get_db2_password(config: dict[str, Any]) -> str:
    """
    Retrieve the DB2 password from the environment variable specified in config.

    Raises:
        SystemExit: If the required environment variable is not set.
    """
    var_name = config["db2_credentials"]["password_var"]
    password = os.environ.get(var_name)
    if not password:
        print(
            f"\n✗ ERROR: Required environment variable {var_name} is not set.\n"
            f"  Set it with: export {var_name}='<your_password>'\n",
            file=sys.stderr,
        )
        sys.exit(3)
    return password


def get_servers_for_env(config: dict[str, Any], env: str) -> list[dict[str, Any]]:
    """Return the list of server dicts for the given environment."""
    environments = config.get("environments", {})
    env_cfg = environments.get(env)
    if not env_cfg:
        raise ConfigError(f"Environment '{env}' not found in inventory. Available: {list(environments.keys())}")
    return env_cfg.get("servers", [])


def get_filters_for_env(config: dict[str, Any], env: str) -> dict[str, Any]:
    """Return the filter config for the given environment (may be empty)."""
    environments = config.get("environments", {})
    env_cfg = environments.get(env, {})
    return env_cfg.get("filters", {})


def get_connection_defaults(config: dict[str, Any]) -> dict[str, Any]:
    """Return connection defaults, filling in missing keys with sensible defaults."""
    defaults = {
        "db2_connect_timeout": 10,
        "ddl_statement_timeout": 120,
        "ssh_command_timeout": 30,
        "retry_count": 1,
        "retry_delay": 5,
    }
    user_defaults = config.get("connection_defaults", {})
    if isinstance(user_defaults, dict):
        defaults.update(user_defaults)
    return defaults
