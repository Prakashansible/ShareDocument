"""Summary report generator for db2-ddl-manager using rich."""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

console = Console()
logger = logging.getLogger("db2ddl.report")


class OperationStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    CONN_FAILED = "CONN_FAILED"
    DRY_RUN = "DRY_RUN"


@dataclass
class DatabaseResult:
    """Result of a DDL operation on a single database."""
    server: str
    instance: str
    database: str
    schema: str
    status: OperationStatus = OperationStatus.FAILED
    reorg_status: str = "N/A"       # OK | PENDING | N/A
    reorg_executed: bool = False
    runstats_executed: bool = False
    skip_reason: Optional[str] = None
    error_message: Optional[str] = None
    sql_executed: Optional[str] = None
    duration_ms: Optional[int] = None


@dataclass
class ExecutionSummary:
    """Aggregated results for a full DDL command run."""
    command: str
    table: Optional[str]
    environment: str
    dry_run: bool
    started_at: datetime
    results: list[DatabaseResult] = field(default_factory=list)
    rollback_file: Optional[Path] = None
    audit_log_file: Optional[Path] = None

    def add_result(self, result: DatabaseResult) -> None:
        self.results.append(result)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def success_count(self) -> int:
        return sum(1 for r in self.results if r.status == OperationStatus.SUCCESS)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.results if r.status in (OperationStatus.FAILED, OperationStatus.CONN_FAILED))

    @property
    def skipped_count(self) -> int:
        return sum(1 for r in self.results if r.status == OperationStatus.SKIPPED)

    @property
    def reorg_pending_count(self) -> int:
        return sum(1 for r in self.results if r.reorg_status == "PENDING")


STATUS_COLORS = {
    OperationStatus.SUCCESS: "green",
    OperationStatus.FAILED: "red",
    OperationStatus.SKIPPED: "yellow",
    OperationStatus.CONN_FAILED: "red",
    OperationStatus.DRY_RUN: "blue",
}

REORG_COLORS = {
    "OK": "green",
    "PENDING": "yellow",
    "N/A": "dim",
}


def print_summary_report(summary: ExecutionSummary) -> None:
    """Print the full summary report table to the console."""
    ts_str = summary.started_at.strftime("%Y-%m-%d %H:%M:%S UTC")

    # Header panel
    header_lines = [
        f"  Command    : {summary.command}",
        f"  Table      : {summary.table or 'N/A'}",
        f"  Environment: {summary.environment}",
        f"  Dry Run    : {'Yes' if summary.dry_run else 'No'}",
        f"  Timestamp  : {ts_str}",
    ]
    console.print(Panel("\n".join(header_lines), title="DDL Execution Summary", border_style="blue"))

    if not summary.results:
        console.print("[yellow]  No databases were targeted.[/yellow]")
        return

    # Main results table
    results_table = Table(box=box.DOUBLE_EDGE, show_header=True, header_style="bold cyan")
    results_table.add_column("Server", style="cyan", no_wrap=True)
    results_table.add_column("Instance", style="cyan")
    results_table.add_column("Database", style="white")
    results_table.add_column("Schema", style="dim white")
    results_table.add_column("Status", justify="center")
    results_table.add_column("Reorg", justify="center")

    for result in summary.results:
        status_color = STATUS_COLORS.get(result.status, "white")
        reorg_color = REORG_COLORS.get(result.reorg_status, "white")
        results_table.add_row(
            result.server.split(".")[0],  # short hostname
            result.instance,
            result.database,
            result.schema,
            f"[{status_color}]{result.status.value}[/{status_color}]",
            f"[{reorg_color}]{result.reorg_status}[/{reorg_color}]",
        )

    console.print(results_table)

    # Footer stats
    console.print(
        f"\n  Total: [bold]{summary.total}[/bold] | "
        f"[green]Success: {summary.success_count}[/green] | "
        f"[red]Failed: {summary.failed_count}[/red] | "
        f"[yellow]Skipped: {summary.skipped_count}[/yellow] | "
        f"[yellow]Reorg Pending: {summary.reorg_pending_count}[/yellow]"
    )

    # Skipped details
    skipped = [r for r in summary.results if r.status == OperationStatus.SKIPPED and r.skip_reason]
    if skipped:
        console.print("\n  [bold yellow]Skipped Details:[/bold yellow]")
        for r in skipped:
            console.print(f"    {r.database}/{r.instance}@{r.server}: {r.skip_reason}")

    # Failed details
    failed = [r for r in summary.results if r.status in (OperationStatus.FAILED, OperationStatus.CONN_FAILED) and r.error_message]
    if failed:
        console.print("\n  [bold red]Failed Details:[/bold red]")
        for r in failed:
            console.print(f"    {r.database}/{r.instance}@{r.server}: {r.error_message}")

    # Rollback and log file paths
    if summary.rollback_file:
        console.print(f"\n  [dim]Rollback script: {summary.rollback_file}[/dim]")
    if summary.audit_log_file:
        console.print(f"  [dim]Audit log      : {summary.audit_log_file}[/dim]")

    console.print()
