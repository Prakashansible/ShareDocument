"""Auto-generate rollback DDL scripts for executed DDL operations."""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("db2ddl.rollback")

ROLLBACK_DIR = Path(__file__).parent.parent / "ddl" / "rollback"


def generate_create_table_rollback(
    table_name: str,
    environment: str,
    timestamp: Optional[datetime] = None,
) -> Path:
    """
    Generate a rollback script for a CREATE TABLE operation (DROP TABLE).

    Args:
        table_name: The table name (without schema prefix).
        environment: Environment where the DDL was executed.
        timestamp: Override timestamp for the filename (defaults to now).

    Returns:
        Path to the generated rollback script.
    """
    ts = timestamp or datetime.now(tz=timezone.utc)
    ts_str = ts.strftime("%Y%m%d_%H%M%S")
    filename = f"drop_{table_name.lower()}_{ts_str}.sql"
    ROLLBACK_DIR.mkdir(parents=True, exist_ok=True)
    rollback_path = ROLLBACK_DIR / filename

    content = f"""-- Auto-generated rollback for create-table
-- Generated: {ts.isoformat()}
-- Environment: {environment}
-- Table: {{schema}}.{table_name}
-- WARNING: This will permanently delete the table and all its data!
-- Replace {{schema}} with the actual schema before running manually.

DROP TABLE {{schema}}.{table_name};
"""
    rollback_path.write_text(content, encoding="utf-8")
    logger.info(f"  Rollback script generated: {rollback_path}")
    return rollback_path


def generate_add_columns_rollback(
    table_name: str,
    columns: list[str],
    environment: str,
    timestamp: Optional[datetime] = None,
) -> Path:
    """
    Generate a rollback script for an add-columns operation (DROP COLUMN).

    Args:
        table_name: The table name (without schema prefix).
        columns: List of column names that were added.
        environment: Environment where the DDL was executed.
        timestamp: Override timestamp for the filename.

    Returns:
        Path to the generated rollback script.
    """
    ts = timestamp or datetime.now(tz=timezone.utc)
    ts_str = ts.strftime("%Y%m%d_%H%M%S")
    filename = f"alter_drop_{table_name.lower()}_{ts_str}.sql"
    ROLLBACK_DIR.mkdir(parents=True, exist_ok=True)
    rollback_path = ROLLBACK_DIR / filename

    drop_clauses = "\n  ".join(f"DROP COLUMN {col}" for col in columns)

    content = f"""-- Auto-generated rollback for add-columns
-- Generated: {ts.isoformat()}
-- Environment: {environment}
-- Table: {{schema}}.{table_name}
-- Columns to drop: {', '.join(columns)}
-- NOTE: ALTER TABLE DROP COLUMN requires REORG afterward.
-- Replace {{schema}} with the actual schema before running manually.

ALTER TABLE {{schema}}.{table_name}
  {drop_clauses};

-- Run REORG after dropping columns:
-- CALL SYSPROC.ADMIN_CMD('REORG TABLE {{schema}}.{table_name}');
"""
    rollback_path.write_text(content, encoding="utf-8")
    logger.info(f"  Rollback script generated: {rollback_path}")
    return rollback_path
