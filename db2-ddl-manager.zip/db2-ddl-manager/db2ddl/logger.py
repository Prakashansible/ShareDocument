"""Structured JSON logging setup for db2-ddl-manager."""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.logging import RichHandler

console = Console(stderr=True)

LOG_DIR = Path(__file__).parent.parent / "logs"


class JsonLineFormatter(logging.Formatter):
    """Format log records as single-line JSON (JSONL)."""

    def format(self, record: logging.LogRecord) -> str:
        log_obj: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        # attach any extra fields passed via extra= kwarg
        for key, val in record.__dict__.items():
            if key not in (
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "exc_info", "exc_text", "stack_info",
                "lineno", "funcName", "created", "msecs", "relativeCreated",
                "thread", "threadName", "processName", "process", "message",
                "taskName",
            ):
                log_obj[key] = val
        return json.dumps(log_obj, default=str)


def setup_logging(log_level: str = "INFO") -> logging.Logger:
    """Configure root logger with JSON file handler and rich console handler."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"db2ddl_{datetime.now().strftime('%Y-%m-%d')}.log"

    root_logger = logging.getLogger("db2ddl")
    root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # JSON file handler
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(JsonLineFormatter())
    file_handler.setLevel(logging.DEBUG)

    # Rich console handler (for human-readable output to stderr)
    console_handler = RichHandler(
        console=console,
        show_path=False,
        rich_tracebacks=True,
        markup=True,
    )
    console_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    return root_logger


def write_audit_entry(entry: dict[str, Any]) -> None:
    """Write a structured audit log entry to the daily JSON log file."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"db2ddl_{datetime.now().strftime('%Y-%m-%d')}.log"
    # Ensure no password leakage
    safe_entry = {k: v for k, v in entry.items() if "pwd" not in k.lower() and "password" not in k.lower()}
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(safe_entry, default=str) + "\n")
