"""
DB2 database connection manager for db2-ddl-manager.

Three connection modes:
  bastion        -- Tool on bastion, single-hop SSH tunnel to target DB2 port
  bastion_direct -- Tool on bastion, direct TCP to target DB2 port (no tunnel)
  laptop         -- Tool on laptop, double-hop tunnel: laptop->bastion->target DB2 port

The DB2 username (UID) is always the discovered instance name.
The password comes from the DB2_PASSWORD environment variable.
"""

import logging
import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

logger = logging.getLogger("db2ddl.connection")

# ibm_db is an optional dependency at import time -- we check before use
try:
    import ibm_db
    import ibm_db_dbi
    IBM_DB_AVAILABLE = True
except ImportError:
    IBM_DB_AVAILABLE = False
    logger.warning(
        "ibm_db not available. DB2 connections will fail. "
        "Ensure IBM_DB_HOME is set and ibm_db is installed."
    )

try:
    from sshtunnel import SSHTunnelForwarder
    SSHTUNNEL_AVAILABLE = True
except ImportError:
    SSHTUNNEL_AVAILABLE = False
    logger.warning("sshtunnel not available. SSH-tunneled connections will fail.")


class ConnectionError(Exception):
    """Raised when a DB2 database connection fails."""


@contextmanager
def db2_connection(
    server_host: str,
    instance_port: int,
    database: str,
    instance_name: str,
    config: dict,
) -> Generator:
    """
    Context manager yielding a DB-API 2.0 DB2 connection.

    Automatically selects the connection strategy based on execution_mode.

    Args:
        server_host: Target DB2 server hostname.
        instance_port: DB2 instance listening port (from SVCENAME discovery).
        database: Database name (e.g., 'DEVDB1').
        instance_name: DB2 instance name -- also used as UID (e.g., 'db2inst1').
        config: Full inventory config dict.

    Yields:
        An ibm_db_dbi.Connection object.

    Raises:
        ConnectionError: If connection fails after retries.
    """
    if not IBM_DB_AVAILABLE:
        raise ConnectionError(
            "ibm_db package not available. Install it with: pip install ibm_db\n"
            "On AIX: ensure IBM_DB_HOME is set and LIBPATH includes $IBM_DB_HOME/lib64"
        )

    mode = config.get("execution_mode", "bastion")
    conn_defaults = config.get("connection_defaults", {})
    retry_count = conn_defaults.get("retry_count", 1)
    retry_delay = conn_defaults.get("retry_delay", 5)
    db2_password = os.environ[config["db2_credentials"]["password_var"]]

    last_error: Exception = Exception("No connection attempt made")

    for attempt in range(retry_count + 1):
        if attempt > 0:
            logger.warning(
                f"  Retrying connection to {database}@{server_host} "
                f"(attempt {attempt + 1}/{retry_count + 1}) after {retry_delay}s"
            )
            time.sleep(retry_delay)
        try:
            if mode == "bastion":
                ctx = _connect_bastion_tunnel(
                    server_host, instance_port, database, instance_name, db2_password, config
                )
            elif mode == "bastion_direct":
                ctx = _connect_bastion_direct(
                    server_host, instance_port, database, instance_name, db2_password, config
                )
            elif mode == "laptop":
                ctx = _connect_laptop_tunnel(
                    server_host, instance_port, database, instance_name, db2_password, config
                )
            else:
                raise ValueError(f"Unknown execution_mode: {mode!r}")

            with ctx as conn:
                yield conn
            return  # success
        except GeneratorExit:
            raise
        except Exception as e:
            last_error = e
            logger.error(
                f"  Connection attempt {attempt + 1} failed for {database}@{server_host}: {e}",
                extra={
                    "server": server_host, "database": database,
                    "instance": instance_name, "retry_attempted": attempt > 0,
                },
            )

    raise ConnectionError(
        f"Failed to connect to {database}@{server_host} after {retry_count + 1} attempt(s): {last_error}"
    ) from last_error


@contextmanager
def _connect_bastion_tunnel(
    server_host: str, instance_port: int, database: str,
    instance_name: str, db2_password: str, config: dict
):
    """Single-hop SSH tunnel: bastion -> target_server:instance_port."""
    if not SSHTUNNEL_AVAILABLE:
        raise ConnectionError("sshtunnel package not available. Install with: pip install sshtunnel")

    target_ssh = config["target_ssh"]
    key_file = str(Path(target_ssh["key_file"]).expanduser())

    with SSHTunnelForwarder(
        ssh_address_or_host=(server_host, target_ssh.get("port", 22)),
        ssh_username=target_ssh["user"],
        ssh_pkey=key_file,
        remote_bind_address=("127.0.0.1", instance_port),
        local_bind_address=("127.0.0.1", 0),
        set_keepalive=30.0,
    ) as tunnel:
        conn_str = _build_conn_str(
            database=database,
            host="127.0.0.1",
            port=tunnel.local_bind_port,
            uid=instance_name,
            pwd=db2_password,
        )
        raw_conn = ibm_db.connect(conn_str, "", "")
        conn = ibm_db_dbi.Connection(raw_conn)
        try:
            yield conn
        finally:
            try:
                conn.close()
            except Exception:
                pass


@contextmanager
def _connect_bastion_direct(
    server_host: str, instance_port: int, database: str,
    instance_name: str, db2_password: str, config: dict
):
    """Direct TCP from bastion to target DB2 port -- no SSH tunnel."""
    conn_str = _build_conn_str(
        database=database,
        host=server_host,
        port=instance_port,
        uid=instance_name,
        pwd=db2_password,
    )
    raw_conn = ibm_db.connect(conn_str, "", "")
    conn = ibm_db_dbi.Connection(raw_conn)
    try:
        yield conn
    finally:
        try:
            conn.close()
        except Exception:
            pass


@contextmanager
def _connect_laptop_tunnel(
    server_host: str, instance_port: int, database: str,
    instance_name: str, db2_password: str, config: dict
):
    """Double-hop tunnel: laptop -> bastion -> target_server:instance_port."""
    if not SSHTUNNEL_AVAILABLE:
        raise ConnectionError("sshtunnel package not available. Install with: pip install sshtunnel")

    bastion_cfg = config["bastion"]
    key_file = str(Path(bastion_cfg["key_file"]).expanduser())

    with SSHTunnelForwarder(
        ssh_address_or_host=(bastion_cfg["host"], bastion_cfg.get("port", 22)),
        ssh_username=bastion_cfg["user"],
        ssh_pkey=key_file,
        remote_bind_address=(server_host, instance_port),
        local_bind_address=("127.0.0.1", 0),
        set_keepalive=30.0,
    ) as tunnel:
        conn_str = _build_conn_str(
            database=database,
            host="127.0.0.1",
            port=tunnel.local_bind_port,
            uid=instance_name,
            pwd=db2_password,
        )
        raw_conn = ibm_db.connect(conn_str, "", "")
        conn = ibm_db_dbi.Connection(raw_conn)
        try:
            yield conn
        finally:
            try:
                conn.close()
            except Exception:
                pass


def _build_conn_str(database: str, host: str, port: int, uid: str, pwd: str) -> str:
    """Build an ibm_db DSN connection string. UID is the DB2 instance name."""
    return (
        f"DATABASE={database};"
        f"HOSTNAME={host};"
        f"PORT={port};"
        f"PROTOCOL=TCPIP;"
        f"UID={uid};"
        f"PWD={pwd};"
        f"ConnectTimeout=10;"
    )
