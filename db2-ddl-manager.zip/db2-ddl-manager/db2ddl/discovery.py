"""
Dynamic DB2 instance and database discovery via SSH.

Discovery flow per server:
1. SSH to server (single-hop in bastion/bastion_direct mode, double-hop in laptop mode)
2. Run `db2ilist` -> get instance names
3. For each instance: resolve port via SVCENAME, list databases
4. Apply include/exclude filters
5. Return structured topology

The discovered instance name is also used as the DB2 UID for connections.
"""

import json
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import paramiko

logger = logging.getLogger("db2ddl.discovery")

CACHE_DIR = Path("/tmp")
CACHE_TTL_SECONDS = 900  # 15 minutes


@dataclass
class DiscoveredDatabase:
    """A single DB2 database discovered via 'db2 list db directory'."""
    name: str
    schema: str  # ZPS + database_name


@dataclass
class DiscoveredInstance:
    """A DB2 instance discovered via db2ilist, with its databases."""
    name: str          # instance name, also used as DB2 UID
    port: int
    databases: list[DiscoveredDatabase] = field(default_factory=list)


@dataclass
class DiscoveredServer:
    """A target DB2 server with all its discovered instances."""
    host: str
    reachable: bool
    error_message: Optional[str] = None
    instances: list[DiscoveredInstance] = field(default_factory=list)


def discover_topology(
    env: str,
    servers: list[dict],
    config: dict,
    filters: dict,
    use_cache: bool = False,
    server_filter: Optional[str] = None,
) -> list[DiscoveredServer]:
    """
    Discover DB2 instances and databases across all servers in an environment.

    Args:
        env: Environment name (dev, beta, prod).
        servers: List of server dicts from inventory (each has 'host').
        config: Full inventory config dict.
        filters: Filter dict from inventory (exclude_instances, exclude_databases, include_databases).
        use_cache: If True, attempt to load from cache file first.
        server_filter: If set, only discover this specific server hostname.

    Returns:
        List of DiscoveredServer objects.
    """
    if use_cache:
        cached = _load_cache(env)
        if cached is not None:
            logger.info(f"Using cached discovery for environment '{env}'")
            results = _deserialize_topology(cached)
            if server_filter:
                results = [s for s in results if s.host == server_filter]
            return results

    results: list[DiscoveredServer] = []
    for server_cfg in servers:
        host = server_cfg["host"]
        if server_filter and host != server_filter:
            continue
        logger.info(f"Discovering topology on {host}")
        discovered = _discover_server(host, config, filters)
        results.append(discovered)

    _save_cache(env, results)
    return results


def _discover_server(host: str, config: dict, filters: dict) -> DiscoveredServer:
    """Discover instances and databases on a single server."""
    try:
        # Step 1: Get instance names via db2ilist
        stdout, _ = run_remote_command(host, "db2ilist", config)
        instance_names = parse_db2ilist(stdout)
        logger.info(f"  {host}: found instances: {instance_names}")
    except Exception as e:
        logger.error(f"  {host}: SSH/discovery failed: {e}")
        return DiscoveredServer(host=host, reachable=False, error_message=str(e))

    # Apply exclude_instances filter
    exclude_instances = set(filters.get("exclude_instances") or [])
    instance_names = [n for n in instance_names if n not in exclude_instances]

    exclude_databases = set(
        db.upper() for db in (filters.get("exclude_databases") or [])
    )
    include_databases = set(
        db.upper() for db in (filters.get("include_databases") or [])
    )

    discovered_instances: list[DiscoveredInstance] = []
    for inst_name in instance_names:
        try:
            port = _resolve_instance_port(host, inst_name, config)
        except Exception as e:
            logger.error(f"  {host}/{inst_name}: port resolution failed: {e}")
            continue

        try:
            db_names = _discover_databases(host, inst_name, config)
        except Exception as e:
            logger.error(f"  {host}/{inst_name}: database discovery failed: {e}")
            continue

        # Apply database filters
        filtered_dbs: list[DiscoveredDatabase] = []
        for db_name in db_names:
            db_upper = db_name.upper()
            if db_upper in exclude_databases:
                logger.debug(f"  {host}/{inst_name}: excluding database {db_name}")
                continue
            if include_databases and db_upper not in include_databases:
                logger.debug(f"  {host}/{inst_name}: database {db_name} not in include_databases whitelist")
                continue
            schema = "ZPS" + db_upper
            filtered_dbs.append(DiscoveredDatabase(name=db_upper, schema=schema))

        discovered_instances.append(
            DiscoveredInstance(name=inst_name, port=port, databases=filtered_dbs)
        )

    return DiscoveredServer(host=host, reachable=True, instances=discovered_instances)


def _resolve_instance_port(host: str, instance_name: str, config: dict) -> int:
    """
    Resolve the TCP port for a DB2 instance by reading SVCENAME from dbm cfg.

    Returns:
        Integer port number.

    Raises:
        RuntimeError: If port cannot be resolved.
    """
    cmd = (
        f"sudo -i -u {instance_name} bash -c "
        f"'. ~/sqllib/db2profile && db2 get dbm cfg' | grep -i svcename"
    )
    stdout, _ = run_remote_command(host, cmd, config)
    # Parse: "TCP/IP Service name    (SVCENAME) = db2c_db2inst1"
    match = re.search(r'SVCENAME\s*\)\s*=\s*(\S+)', stdout, re.IGNORECASE)
    if not match:
        raise RuntimeError(f"Could not find SVCENAME in dbm cfg output for instance {instance_name}")

    svcename = match.group(1).strip()
    if svcename.isdigit():
        return int(svcename)

    # It's a service name -- resolve via /etc/services
    resolve_cmd = f"grep -w {svcename} /etc/services | awk '{{print $2}}' | cut -d/ -f1 | head -1"
    stdout2, _ = run_remote_command(host, resolve_cmd, config)
    port_str = stdout2.strip()
    if not port_str or not port_str.isdigit():
        raise RuntimeError(
            f"Could not resolve service name '{svcename}' to a port via /etc/services on {host}"
        )
    return int(port_str)


def _discover_databases(host: str, instance_name: str, config: dict) -> list[str]:
    """
    Run 'db2 list db directory' as the instance owner and parse database names.
    Only returns databases with Directory entry type = Indirect.
    """
    cmd = (
        f"sudo -i -u {instance_name} bash -c "
        f"'. ~/sqllib/db2profile && db2 list db directory'"
    )
    stdout, _ = run_remote_command(host, cmd, config)
    return parse_db_directory(stdout)


# ---------------------------------------------------------------------------
#  Parsing helpers
# ---------------------------------------------------------------------------

def parse_db2ilist(output: str) -> list[str]:
    """
    Parse output of 'db2ilist' command.

    Each line is an instance name. Blank lines and whitespace-only lines are ignored.

    Args:
        output: Raw stdout from db2ilist.

    Returns:
        List of instance name strings.
    """
    names = []
    for line in output.splitlines():
        stripped = line.strip()
        if stripped:
            names.append(stripped)
    return names


def parse_db_directory(output: str) -> list[str]:
    """
    Parse output of 'db2 list db directory'.

    Only returns databases where 'Directory entry type = Indirect'.

    Args:
        output: Raw stdout from 'db2 list db directory'.

    Returns:
        List of database name strings (uppercase).
    """
    databases: list[str] = []
    # Split into blocks by "Database N entry:"
    blocks = re.split(r'Database\s+\d+\s+entry:', output)
    for block in blocks:
        # Extract database name
        name_match = re.search(r'Database name\s*=\s*(\S+)', block)
        type_match = re.search(r'Directory entry type\s*=\s*(\S+)', block)
        if name_match and type_match:
            db_name = name_match.group(1).strip().upper()
            entry_type = type_match.group(1).strip()
            if entry_type.lower() == "indirect":
                databases.append(db_name)
    return databases


# ---------------------------------------------------------------------------
#  SSH command execution (mode-aware)
# ---------------------------------------------------------------------------

def run_remote_command(server_host: str, command: str, config: dict) -> tuple[str, str]:
    """
    Execute a shell command on a target server via SSH.

    Dispatches to single-hop or double-hop SSH based on execution_mode.

    Args:
        server_host: Hostname of the target DB2 server.
        command: Shell command to execute.
        config: Full inventory config dict.

    Returns:
        Tuple of (stdout, stderr) strings.

    Raises:
        RuntimeError: If the command exits with a non-zero status.
    """
    mode = config.get("execution_mode", "bastion")
    if mode in ("bastion", "bastion_direct"):
        return _run_command_single_hop(server_host, command, config)
    elif mode == "laptop":
        return _run_command_double_hop(server_host, command, config)
    else:
        raise ValueError(f"Unknown execution_mode: {mode!r}")


def _run_command_single_hop(server_host: str, command: str, config: dict) -> tuple[str, str]:
    """
    Execute a command on target_server via single-hop SSH from the bastion.
    Used in 'bastion' and 'bastion_direct' modes.
    """
    target_ssh = config["target_ssh"]
    conn_defaults = config.get("connection_defaults", {})
    ssh_timeout = target_ssh.get("ssh_timeout", 15)
    cmd_timeout = conn_defaults.get("ssh_command_timeout", 30)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=server_host,
            port=target_ssh.get("port", 22),
            username=target_ssh["user"],
            key_filename=str(Path(target_ssh["key_file"]).expanduser()),
            timeout=ssh_timeout,
            banner_timeout=ssh_timeout,
            auth_timeout=ssh_timeout,
        )
        stdin, stdout, stderr = client.exec_command(command, timeout=cmd_timeout)
        output = stdout.read().decode("utf-8", errors="replace")
        errors = stderr.read().decode("utf-8", errors="replace")
        exit_code = stdout.channel.recv_exit_status()
    finally:
        client.close()

    if exit_code != 0:
        raise RuntimeError(
            f"Command failed on {server_host} (exit {exit_code}): {errors.strip()}"
        )
    return output, errors


def _run_command_double_hop(server_host: str, command: str, config: dict) -> tuple[str, str]:
    """
    Execute a command on target_server via double-hop SSH: laptop -> bastion -> target.
    Used in 'laptop' mode.
    """
    bastion_cfg = config["bastion"]
    target_ssh = config["target_ssh"]
    conn_defaults = config.get("connection_defaults", {})
    bastion_timeout = bastion_cfg.get("ssh_timeout", 15)
    target_timeout = target_ssh.get("ssh_timeout", 15)
    cmd_timeout = conn_defaults.get("ssh_command_timeout", 30)

    bastion_client = paramiko.SSHClient()
    bastion_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        bastion_client.connect(
            hostname=bastion_cfg["host"],
            port=bastion_cfg.get("port", 22),
            username=bastion_cfg["user"],
            key_filename=str(Path(bastion_cfg["key_file"]).expanduser()),
            timeout=bastion_timeout,
            banner_timeout=bastion_timeout,
            auth_timeout=bastion_timeout,
        )

        # Open direct-tcpip channel through bastion to target:22
        bastion_transport = bastion_client.get_transport()
        channel = bastion_transport.open_channel(
            kind="direct-tcpip",
            dest_addr=(server_host, target_ssh.get("port", 22)),
            src_addr=("127.0.0.1", 0),
        )

        target_client = paramiko.SSHClient()
        target_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            target_client.connect(
                hostname=server_host,
                username=target_ssh["user"],
                key_filename=str(Path(target_ssh["key_file"]).expanduser()),
                sock=channel,
                timeout=target_timeout,
                banner_timeout=target_timeout,
                auth_timeout=target_timeout,
            )
            stdin, stdout, stderr = target_client.exec_command(command, timeout=cmd_timeout)
            output = stdout.read().decode("utf-8", errors="replace")
            errors = stderr.read().decode("utf-8", errors="replace")
            exit_code = stdout.channel.recv_exit_status()
        finally:
            target_client.close()
    finally:
        bastion_client.close()

    if exit_code != 0:
        raise RuntimeError(
            f"Command failed on {server_host} via bastion (exit {exit_code}): {errors.strip()}"
        )
    return output, errors


# ---------------------------------------------------------------------------
#  Cache management
# ---------------------------------------------------------------------------

def _cache_path(env: str) -> Path:
    return CACHE_DIR / f"db2ddl_discovery_{env}_latest.json"


def _save_cache(env: str, topology: list[DiscoveredServer]) -> None:
    """Serialize and save discovery results to a cache file."""
    try:
        data = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "env": env,
            "servers": _serialize_topology(topology),
        }
        cache_path = _cache_path(env)
        cache_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.debug(f"Discovery results cached to {cache_path}")
    except Exception as e:
        logger.warning(f"Failed to write discovery cache: {e}")


def _load_cache(env: str) -> Optional[dict]:
    """Load discovery cache if it exists and is fresh (< TTL)."""
    cache_path = _cache_path(env)
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        ts = datetime.fromisoformat(data["timestamp"])
        age = (datetime.now(tz=timezone.utc) - ts).total_seconds()
        if age > CACHE_TTL_SECONDS:
            logger.info(f"Discovery cache expired (age {age:.0f}s > TTL {CACHE_TTL_SECONDS}s) -- re-discovering")
            return None
        return data
    except Exception as e:
        logger.warning(f"Failed to read discovery cache: {e}")
        return None


def _serialize_topology(topology: list[DiscoveredServer]) -> list[dict]:
    result = []
    for server in topology:
        result.append({
            "host": server.host,
            "reachable": server.reachable,
            "error_message": server.error_message,
            "instances": [
                {
                    "name": inst.name,
                    "port": inst.port,
                    "databases": [
                        {"name": db.name, "schema": db.schema}
                        for db in inst.databases
                    ],
                }
                for inst in server.instances
            ],
        })
    return result


def _deserialize_topology(data: dict) -> list[DiscoveredServer]:
    servers = []
    for s in data.get("servers", []):
        instances = []
        for i in s.get("instances", []):
            databases = [
                DiscoveredDatabase(name=d["name"], schema=d["schema"])
                for d in i.get("databases", [])
            ]
            instances.append(DiscoveredInstance(name=i["name"], port=i["port"], databases=databases))
        servers.append(DiscoveredServer(
            host=s["host"],
            reachable=s["reachable"],
            error_message=s.get("error_message"),
            instances=instances,
        ))
    return servers
