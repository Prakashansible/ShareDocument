"""
Core DDL execution engine for db2-ddl-manager.

Iterates the discovered topology (env -> servers -> instances -> databases)
and executes DDL operations with idempotency checks, audit logging,
and rollback generation.
"""

import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from db2ddl.connection import db2_connection, ConnectionError
from db2ddl.discovery import DiscoveredServer
from db2ddl.logger import write_audit_entry
from db2ddl.reorg import check_reorg_status, run_reorg, run_runstats
from db2ddl.report import DatabaseResult, ExecutionSummary, OperationStatus
from db2ddl.rollback import generate_create_table_rollback, generate_add_columns_rollback
from db2ddl.validators import parse_alter_columns

logger = logging.getLogger("db2ddl.executor")

LOG_DIR = Path(__file__).parent.parent / "logs"


def execute_create_table(
    ddl_content: str,
    table_name: str,
    topology: list[DiscoveredServer],
    config: dict,
    environment: str,
    dry_run: bool = False,
    fail_fast: bool = False,
    instance_filter: Optional[str] = None,
    database_filter: Optional[str] = None,
) -> ExecutionSummary:
    """
    Execute CREATE TABLE across all discovered databases.

    Args:
        ddl_content: Raw DDL file content (with {schema} placeholder).
        table_name: Table name being created (for idempotency and rollback).
        topology: Discovered server topology.
        config: Full inventory config dict.
        environment: Target environment name.
        dry_run: If True, show SQL but do not execute.
        fail_fast: If True, stop on first failure.
        instance_filter: If set, only target this instance.
        database_filter: If set, only target this database.

    Returns:
        ExecutionSummary with all results.
    """
    started_at = datetime.now(tz=timezone.utc)
    summary = ExecutionSummary(
        command="create-table",
        table=table_name,
        environment=environment,
        dry_run=dry_run,
        started_at=started_at,
    )
    rollback_needed = False

    for server in topology:
        if not server.reachable:
            logger.warning(f"Skipping unreachable server: {server.host}")
            continue

        for instance in server.instances:
            if instance_filter and instance.name != instance_filter:
                continue

            for database in instance.databases:
                if database_filter and database.name != database_filter:
                    continue

                schema = database.schema
                result = _execute_create_on_db(
                    server_host=server.host,
                    instance=instance,
                    database=database,
                    schema=schema,
                    table_name=table_name,
                    ddl_content=ddl_content,
                    config=config,
                    environment=environment,
                    dry_run=dry_run,
                    started_at=started_at,
                )
                summary.add_result(result)
                if result.status == OperationStatus.SUCCESS:
                    rollback_needed = True

                if fail_fast and result.status in (OperationStatus.FAILED, OperationStatus.CONN_FAILED):
                    logger.error("  --fail-fast triggered. Stopping execution.")
                    summary.audit_log_file = LOG_DIR / f"db2ddl_{started_at.strftime('%Y-%m-%d')}.log"
                    return summary

    if rollback_needed and not dry_run:
        rollback_path = generate_create_table_rollback(table_name, environment, started_at)
        summary.rollback_file = rollback_path

    summary.audit_log_file = LOG_DIR / f"db2ddl_{started_at.strftime('%Y-%m-%d')}.log"
    return summary


def _execute_create_on_db(
    server_host: str, instance, database, schema: str,
    table_name: str, ddl_content: str, config: dict,
    environment: str, dry_run: bool, started_at: datetime,
) -> DatabaseResult:
    """Execute CREATE TABLE on a single database with idempotency check."""
    db_start = time.monotonic()
    result = DatabaseResult(
        server=server_host,
        instance=instance.name,
        database=database.name,
        schema=schema,
    )

    # Substitute placeholders
    ddl = ddl_content.replace("{schema}", schema)
    ddl = ddl.replace("{database}", database.name)
    ddl = ddl.replace("{instance}", instance.name)
    ddl = ddl.replace("{server}", server_host)
    ddl = ddl.replace("{environment}", environment)

    if dry_run:
        logger.info(f"  [DRY RUN] Would execute on {database.name}@{server_host}:")
        logger.info(f"  {ddl.strip()}")
        result.status = OperationStatus.DRY_RUN
        result.sql_executed = ddl
        return result

    try:
        with db2_connection(server_host, instance.port, database.name, instance.name, config) as conn:
            # Idempotency check
            cursor = conn.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM SYSCAT.TABLES WHERE TABSCHEMA = ? AND TABNAME = ? AND TYPE = 'T'",
                (schema.upper(), table_name.upper()),
            )
            count = cursor.fetchone()[0]
            cursor.close()

            if count > 0:
                result.status = OperationStatus.SKIPPED
                result.skip_reason = f"Table {schema}.{table_name} already exists"
                logger.info(f"  SKIPPED: {database.name} -- table already exists")
            else:
                cursor = conn.cursor()
                cursor.execute(ddl)
                conn.commit()
                cursor.close()
                result.status = OperationStatus.SUCCESS
                result.sql_executed = ddl

                # Check reorg status post-creation
                reorg = check_reorg_status(conn, schema, table_name)
                result.reorg_status = "PENDING" if reorg.pending else "OK"
                logger.info(f"  SUCCESS: {database.name}@{server_host}")

    except ConnectionError as e:
        result.status = OperationStatus.CONN_FAILED
        result.error_message = str(e)
        logger.error(f"  CONN_FAILED: {database.name}@{server_host}: {e}")
    except Exception as e:
        result.status = OperationStatus.FAILED
        result.error_message = str(e)
        logger.error(f"  FAILED: {database.name}@{server_host}: {e}")

    result.duration_ms = int((time.monotonic() - db_start) * 1000)
    _write_audit(result, "create-table", environment, table_name, config, started_at)
    return result


def execute_add_columns(
    ddl_content: str,
    table_name: str,
    topology: list[DiscoveredServer],
    config: dict,
    environment: str,
    dry_run: bool = False,
    fail_fast: bool = False,
    auto_reorg: bool = False,
    instance_filter: Optional[str] = None,
    database_filter: Optional[str] = None,
) -> ExecutionSummary:
    """
    Execute ALTER TABLE ADD COLUMN across all discovered databases.

    Performs idempotency checks per-column, skipping columns that already exist.
    """
    started_at = datetime.now(tz=timezone.utc)
    summary = ExecutionSummary(
        command="add-columns",
        table=table_name,
        environment=environment,
        dry_run=dry_run,
        started_at=started_at,
    )

    # Parse columns from DDL
    all_columns = parse_alter_columns(ddl_content)
    if not all_columns:
        logger.error("No ADD COLUMN definitions found in DDL file")
        return summary

    rollback_needed = False

    for server in topology:
        if not server.reachable:
            logger.warning(f"Skipping unreachable server: {server.host}")
            continue

        for instance in server.instances:
            if instance_filter and instance.name != instance_filter:
                continue

            for database in instance.databases:
                if database_filter and database.name != database_filter:
                    continue

                schema = database.schema
                result = _execute_alter_on_db(
                    server_host=server.host,
                    instance=instance,
                    database=database,
                    schema=schema,
                    table_name=table_name,
                    all_columns=all_columns,
                    config=config,
                    environment=environment,
                    dry_run=dry_run,
                    auto_reorg=auto_reorg,
                    started_at=started_at,
                )
                summary.add_result(result)
                if result.status == OperationStatus.SUCCESS:
                    rollback_needed = True

                if fail_fast and result.status in (OperationStatus.FAILED, OperationStatus.CONN_FAILED):
                    logger.error("  --fail-fast triggered. Stopping execution.")
                    summary.audit_log_file = LOG_DIR / f"db2ddl_{started_at.strftime('%Y-%m-%d')}.log"
                    return summary

    if rollback_needed and not dry_run:
        added_col_names = [c["name"] for c in all_columns]
        rollback_path = generate_add_columns_rollback(table_name, added_col_names, environment, started_at)
        summary.rollback_file = rollback_path

    summary.audit_log_file = LOG_DIR / f"db2ddl_{started_at.strftime('%Y-%m-%d')}.log"
    return summary


def _execute_alter_on_db(
    server_host: str, instance, database, schema: str,
    table_name: str, all_columns: list[dict], config: dict,
    environment: str, dry_run: bool, auto_reorg: bool, started_at: datetime,
) -> DatabaseResult:
    """Execute ALTER TABLE ADD COLUMN on a single database with per-column idempotency."""
    db_start = time.monotonic()
    result = DatabaseResult(
        server=server_host,
        instance=instance.name,
        database=database.name,
        schema=schema,
    )

    if dry_run:
        col_defs = "\n  ".join(c["definition"] for c in all_columns)
        dry_sql = f"ALTER TABLE {schema}.{table_name}\n  {col_defs};"
        logger.info(f"  [DRY RUN] Would execute on {database.name}@{server_host}:")
        logger.info(f"  {dry_sql}")
        result.status = OperationStatus.DRY_RUN
        result.sql_executed = dry_sql
        return result

    try:
        with db2_connection(server_host, instance.port, database.name, instance.name, config) as conn:
            cursor = conn.cursor()

            # Step 1: Verify table exists
            cursor.execute(
                "SELECT COUNT(*) FROM SYSCAT.TABLES WHERE TABSCHEMA = ? AND TABNAME = ? AND TYPE = 'T'",
                (schema.upper(), table_name.upper()),
            )
            table_count = cursor.fetchone()[0]
            if table_count == 0:
                cursor.close()
                result.status = OperationStatus.SKIPPED
                result.skip_reason = f"Table {schema}.{table_name} not found"
                logger.info(f"  SKIPPED: {database.name} -- table not found")
                return result

            # Step 2: Check which columns already exist
            columns_to_add = []
            columns_skipped = []
            for col in all_columns:
                cursor.execute(
                    "SELECT COLNAME FROM SYSCAT.COLUMNS WHERE TABSCHEMA = ? AND TABNAME = ? AND COLNAME = ?",
                    (schema.upper(), table_name.upper(), col["name"].upper()),
                )
                if cursor.fetchone():
                    columns_skipped.append(col["name"])
                else:
                    columns_to_add.append(col)

            cursor.close()

            if not columns_to_add:
                result.status = OperationStatus.SKIPPED
                result.skip_reason = f"ALL COLUMNS EXIST ({', '.join(columns_skipped)})"
                logger.info(f"  SKIPPED: {database.name} -- all columns already exist")
                return result

            if columns_skipped:
                logger.info(
                    f"  {database.name}: skipping existing columns: {', '.join(columns_skipped)}"
                )

            # Step 3: Execute ALTER TABLE with only new columns
            col_defs = "\n  ".join(c["definition"] for c in columns_to_add)
            alter_sql = f"ALTER TABLE {schema}.{table_name}\n  {col_defs};"

            cursor = conn.cursor()
            cursor.execute(alter_sql)
            conn.commit()
            cursor.close()
            result.status = OperationStatus.SUCCESS
            result.sql_executed = alter_sql
            logger.info(f"  SUCCESS: {database.name}@{server_host} -- added {len(columns_to_add)} column(s)")

            # Step 4: Check reorg status
            reorg = check_reorg_status(conn, schema, table_name)
            result.reorg_status = "PENDING" if reorg.pending else "OK"

            # Step 5: Auto-reorg if requested and pending
            if auto_reorg and reorg.pending:
                reorg_ok = run_reorg(conn, schema, table_name)
                if reorg_ok:
                    result.reorg_executed = True
                    run_runstats(conn, schema, table_name)
                    result.runstats_executed = True
                    result.reorg_status = "OK"

    except ConnectionError as e:
        result.status = OperationStatus.CONN_FAILED
        result.error_message = str(e)
        logger.error(f"  CONN_FAILED: {database.name}@{server_host}: {e}")
    except Exception as e:
        result.status = OperationStatus.FAILED
        result.error_message = str(e)
        logger.error(f"  FAILED: {database.name}@{server_host}: {e}")

    result.duration_ms = int((time.monotonic() - db_start) * 1000)
    _write_audit(result, "add-columns", environment, table_name, config, started_at)
    return result


def _write_audit(
    result: DatabaseResult,
    command: str,
    environment: str,
    table_name: str,
    config: dict,
    started_at: datetime,
) -> None:
    """Write a structured audit log entry for a single database operation."""
    entry = {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "command": command,
        "environment": environment,
        "server": result.server,
        "instance": result.instance,
        "database": result.database,
        "schema": result.schema,
        "table": table_name,
        "sql_executed": result.sql_executed,
        "status": result.status.value if result.status else None,
        "reorg_pending": result.reorg_status == "PENDING",
        "reorg_executed": result.reorg_executed,
        "runstats_executed": result.runstats_executed,
        "duration_ms": result.duration_ms,
        "dry_run": False,
        "os_user": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        "db2_user": result.instance,
        "error_message": result.error_message,
        "execution_mode": config.get("execution_mode", "bastion"),
    }
    write_audit_entry(entry)
