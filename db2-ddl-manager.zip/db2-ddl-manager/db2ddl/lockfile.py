"""
Per-environment lock file management for db2-ddl-manager.

Prevents concurrent DDL runs against the same environment by two DBAs.
Lock file location: /tmp/db2ddl_<env>.lock
"""

import atexit
import getpass
import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("db2ddl.lockfile")

LOCK_DIR = Path("/tmp")


class LockConflictError(Exception):
    """Raised when the environment lock is held by another process."""


class EnvironmentLock:
    """
    Context manager that acquires and releases a per-environment lock file.

    Usage:
        with EnvironmentLock("prod", "add-columns --table CUSTOMER_ORDERS") as lock:
            # safe to run
    """

    def __init__(self, env: str, command_desc: str):
        self.env = env
        self.command_desc = command_desc
        self.lock_path = LOCK_DIR / f"db2ddl_{env}.lock"
        self._acquired = False

    def acquire(self) -> None:
        """Attempt to acquire the lock. Raises LockConflictError if held."""
        if self.lock_path.exists():
            self._handle_existing_lock()

        lock_data = {
            "pid": os.getpid(),
            "user": _get_username(),
            "command": self.command_desc,
            "started_at": datetime.now(tz=timezone.utc).isoformat(),
            "env": self.env,
        }
        try:
            self.lock_path.write_text(json.dumps(lock_data, indent=2), encoding="utf-8")
            self._acquired = True
            atexit.register(self.release)
            logger.debug(f"Lock acquired: {self.lock_path}")
        except OSError as e:
            raise LockConflictError(f"Cannot create lock file {self.lock_path}: {e}") from e

    def release(self) -> None:
        """Release the lock (delete lock file)."""
        if self._acquired and self.lock_path.exists():
            try:
                self.lock_path.unlink()
                self._acquired = False
                logger.debug(f"Lock released: {self.lock_path}")
            except OSError as e:
                logger.warning(f"Failed to remove lock file {self.lock_path}: {e}")

    def _handle_existing_lock(self) -> None:
        """Check if the existing lock is stale (process dead) or live (conflict)."""
        try:
            data = json.loads(self.lock_path.read_text(encoding="utf-8"))
        except Exception:
            # Unreadable lock file -- treat as stale
            logger.warning(f"Removing unreadable lock file: {self.lock_path}")
            self.lock_path.unlink(missing_ok=True)
            return

        pid = data.get("pid")
        if pid and _is_process_alive(pid):
            user = data.get("user", "unknown")
            command = data.get("command", "unknown")
            started_at = data.get("started_at", "unknown")
            raise LockConflictError(
                f"\nEnvironment '{self.env}' is locked by user '{user}' (PID {pid})\n"
                f"   Running: {command}\n"
                f"   Since: {started_at}\n"
                f"   Cannot proceed. Wait for the operation to complete or manually remove:\n"
                f"   {self.lock_path}\n"
            )
        else:
            logger.warning(f"Removing stale lock file (PID {pid} is no longer alive): {self.lock_path}")
            self.lock_path.unlink(missing_ok=True)

    def __enter__(self) -> "EnvironmentLock":
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.release()


def _is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is currently running."""
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but we can't signal it -- it's alive
        return True
    except Exception:
        return False


def _get_username() -> str:
    """Get the current OS username safely."""
    try:
        return getpass.getuser()
    except Exception:
        return os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
