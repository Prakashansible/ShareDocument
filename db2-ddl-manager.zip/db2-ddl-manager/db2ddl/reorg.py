"""Table REORG status checking and REORG/RUNSTATS execution."""

import logging
from typing import Optional

logger = logging.getLogger("db2ddl.reorg")


class ReorgStatus:
    """Result of a reorg pending check."""
    def __init__(self, pending: bool, inplace_status: Optional[str] = None,
                 row_count: Optional[int] = None, last_stats: Optional[str] = None,
                 error: Optional[str] = None):
        self.pending = pending
        self.inplace_status = inplace_status
        self.row_count = row_count
        self.last_stats = last_stats
        self.error = error

    def __str__(self) -> str:
        if self.error:
            return f"ERROR: {self.error}"
        return "PENDING" if self.pending else "OK"


def check_reorg_status(conn, schema: str, table: str) -> ReorgStatus:
    """
    Check whether a table has reorg pending status.

    Args:
        conn: DB-API 2.0 DB2 connection.
        schema: Table schema name (e.g., 'ZPSDEVDB1').
        table: Table name (e.g., 'CUSTOMER_ORDERS').

    Returns:
        ReorgStatus object.
    """
    try:
        cursor = conn.cursor()
        # Check SYSCAT.TABLES for basic info
        cursor.execute(
            """
            SELECT CARD, STATS_TIME, NUM_REORG_REC_ALTERS
            FROM SYSCAT.TABLES
            WHERE TABSCHEMA = ? AND TABNAME = ?
            """,
            (schema.upper(), table.upper()),
        )
        row = cursor.fetchone()
        if not row:
            return ReorgStatus(pending=False, error=f"Table {schema}.{table} not found in SYSCAT.TABLES")

        card, stats_time, num_reorg = row
        stats_str = str(stats_time) if stats_time else None

        # Check ADMIN_GET_TAB_INFO for reorg pending flag
        try:
            cursor.execute(
                """
                SELECT REORG_PENDING, INPLACE_REORG_STATUS
                FROM TABLE(SYSPROC.ADMIN_GET_TAB_INFO(?, ?))
                """,
                (schema.upper(), table.upper()),
            )
            info_row = cursor.fetchone()
            if info_row:
                reorg_pending_flag, inplace_status = info_row
                pending = (reorg_pending_flag == "Y") or (num_reorg and num_reorg > 0)
                return ReorgStatus(
                    pending=bool(pending),
                    inplace_status=inplace_status,
                    row_count=card,
                    last_stats=stats_str,
                )
        except Exception as info_err:
            logger.debug(f"ADMIN_GET_TAB_INFO not available: {info_err}")
            # Fall back to NUM_REORG_REC_ALTERS
            pending = bool(num_reorg and num_reorg > 0)
            return ReorgStatus(pending=pending, row_count=card, last_stats=stats_str)

    except Exception as e:
        logger.error(f"Failed to check reorg status for {schema}.{table}: {e}")
        return ReorgStatus(pending=False, error=str(e))
    finally:
        try:
            cursor.close()
        except Exception:
            pass

    return ReorgStatus(pending=False)


def run_reorg(conn, schema: str, table: str) -> bool:
    """
    Run REORG on a table using SYSPROC.ADMIN_CMD.

    Args:
        conn: DB-API 2.0 DB2 connection.
        schema: Table schema name.
        table: Table name.

    Returns:
        True on success, False on failure.
    """
    reorg_sql = f"CALL SYSPROC.ADMIN_CMD('REORG TABLE {schema}.{table}')"
    logger.info(f"  Running REORG TABLE {schema}.{table}")
    try:
        cursor = conn.cursor()
        cursor.execute(reorg_sql)
        conn.commit()
        cursor.close()
        logger.info(f"  REORG completed for {schema}.{table}")
        return True
    except Exception as e:
        logger.error(f"  REORG failed for {schema}.{table}: {e}")
        return False


def run_runstats(conn, schema: str, table: str) -> bool:
    """
    Run RUNSTATS on a table using SYSPROC.ADMIN_CMD.

    Args:
        conn: DB-API 2.0 DB2 connection.
        schema: Table schema name.
        table: Table name.

    Returns:
        True on success, False on failure.
    """
    runstats_sql = (
        f"CALL SYSPROC.ADMIN_CMD("
        f"'RUNSTATS ON TABLE {schema}.{table} "
        f"WITH DISTRIBUTION AND DETAILED INDEXES ALL')"
    )
    logger.info(f"  Running RUNSTATS ON TABLE {schema}.{table}")
    try:
        cursor = conn.cursor()
        cursor.execute(runstats_sql)
        conn.commit()
        cursor.close()
        logger.info(f"  RUNSTATS completed for {schema}.{table}")
        return True
    except Exception as e:
        logger.error(f"  RUNSTATS failed for {schema}.{table}: {e}")
        return False
