"""db2-ddl-manager: Production-grade CLI for DB2 DDL management across multiple servers."""

__version__ = "1.0.0"
__author__ = "DBA Team"

import platform
import logging

logger = logging.getLogger(__name__)

_EXPECTED_OS = {"AIX", "Linux"}
_current_os = platform.system()

if _current_os not in _EXPECTED_OS:
    logger.warning(
        f"Running on {_current_os} — this tool is designed for AIX/Linux bastion hosts. "
        f"If you are on a laptop/workstation, ensure execution_mode=laptop in your inventory.yaml."
    )
